#include "hybrid_a_star/hybrid_a_star.h"
#include "hybrid_a_star/display_tools.h"
#include "hybrid_a_star/timer.h"
#include "hybrid_a_star/trajectory_optimizer.h"

#include <iostream>

HybridAStar::HybridAStar(double steering_angle, int steering_angle_discrete_num, double segment_length,
                         int segment_length_discrete_num, double wheel_base, double steering_penalty,
                         double reversing_penalty, double steering_change_penalty, double shot_distance,
                         int grid_size_phi) {
    wheel_base_ = wheel_base;
    segment_length_ = segment_length;  //<!-- 搜索路径长度 -->
    steering_radian_ = steering_angle * M_PI / 180.0; 
    steering_discrete_num_ = steering_angle_discrete_num;   
    steering_radian_step_size_ = steering_radian_ / steering_discrete_num_;  //角度步进长度 
    move_step_size_ = segment_length / segment_length_discrete_num;
    segment_length_discrete_num_ = static_cast<int>(segment_length_discrete_num);    
    steering_penalty_ = steering_penalty;
    steering_change_penalty_ = steering_change_penalty;
    reversing_penalty_ = reversing_penalty;
    shot_distance_ = shot_distance;

    CHECK_EQ(static_cast<float>(segment_length_discrete_num_ * move_step_size_), static_cast<float>(segment_length_))
        << "The segment length must be divisible by the step size. segment_length: "
        << segment_length_ << " | step_size: " << move_step_size_;

    rs_path_ptr_ = std::make_shared<RSPath>(wheel_base_ / std::tan(steering_radian_));
    tie_breaker_ = 1.0 + 1e-3;

    STATE_GRID_SIZE_PHI_ = grid_size_phi;   //72
    ANGULAR_RESOLUTION_ = 360.0 / STATE_GRID_SIZE_PHI_ * M_PI / 180.0;
}

HybridAStar::~HybridAStar() {
    ReleaseMemory();
}

//参数初始化，设置车辆离散，节点地图指针初始化
void HybridAStar::Init(double x_lower, double x_upper, double y_lower, double y_upper,
                       double state_grid_resolution, double map_grid_resolution) {
    SetVehicleShape(1.0, 0.8, 0.5);    //此处源代码是车辆到后轴的距离，但小车是中心定位而非后轴定位

    map_x_lower_ = x_lower;
    map_x_upper_ = x_upper;
    map_y_lower_ = y_lower;
    map_y_upper_ = y_upper;
    STATE_GRID_RESOLUTION_ = state_grid_resolution;
    MAP_GRID_RESOLUTION_ = map_grid_resolution;

    STATE_GRID_SIZE_X_ = std::floor((map_x_upper_ - map_x_lower_) / STATE_GRID_RESOLUTION_);  //状态地图栅格
    STATE_GRID_SIZE_Y_ = std::floor((map_y_upper_ - map_y_lower_) / STATE_GRID_RESOLUTION_);

    MAP_GRID_SIZE_X_ = std::floor((map_x_upper_ - map_x_lower_) / MAP_GRID_RESOLUTION_);  //像素地图栅格
    MAP_GRID_SIZE_Y_ = std::floor((map_y_upper_ - map_y_lower_) / MAP_GRID_RESOLUTION_);

    if (map_data_) {
        delete[] map_data_;
        map_data_ = nullptr;
    }

    map_data_ = new uint8_t[MAP_GRID_SIZE_X_ * MAP_GRID_SIZE_Y_];

    if (state_node_map_) {
        for (int i = 0; i < STATE_GRID_SIZE_X_; ++i) {   //判断是否为空

            if (state_node_map_[i] == nullptr)
                continue;

            for (int j = 0; j < STATE_GRID_SIZE_Y_; ++j) {
                if (state_node_map_[i][j] == nullptr)
                    continue;

                for (int k = 0; k < STATE_GRID_SIZE_PHI_; ++k) {   //第三层才是存储数据的地方
                    if (state_node_map_[i][j][k] != nullptr) {
                        delete state_node_map_[i][j][k];
                        state_node_map_[i][j][k] = nullptr;
                    }
                }
                delete[] state_node_map_[i][j];
                state_node_map_[i][j] = nullptr;
            }
            delete[] state_node_map_[i];
            state_node_map_[i] = nullptr;
        }

        delete[] state_node_map_;
        state_node_map_ = nullptr;
    }

    state_node_map_ = new StateNode::Ptr **[STATE_GRID_SIZE_X_];
    for (int i = 0; i < STATE_GRID_SIZE_X_; ++i) {
        state_node_map_[i] = new StateNode::Ptr *[STATE_GRID_SIZE_Y_];
        for (int j = 0; j < STATE_GRID_SIZE_Y_; ++j) {
            state_node_map_[i][j] = new StateNode::Ptr[STATE_GRID_SIZE_PHI_];
            for (int k = 0; k < STATE_GRID_SIZE_PHI_; ++k) {
                state_node_map_[i][j][k] = nullptr;
            }
        }
    }
}


//Bresenham直线算法 
inline bool HybridAStar::LineCheck(double x0, double y0, double x1, double y1) {  //这里的xy都是栅格点的坐标
    bool steep = (std::abs(y1 - y0) > std::abs(x1 - x0));

    if (steep) {
        std::swap(x0, y0);
        std::swap(y1, x1);
    }

    if (x0 > x1) {
        std::swap(x0, x1);
        std::swap(y0, y1);
    }

    auto delta_x = x1 - x0;
    auto delta_y = std::abs(y1 - y0);
    auto delta_error = delta_y / delta_x;
    decltype(delta_x) error = 0;   //表示与delta_x相同的数据类型
    decltype(delta_x) y_step; //表示与delta_x相同的数据类型
    auto yk = y0;

    if (y0 < y1) {
        y_step = 1;
    } else {
        y_step = -1;
    }

    auto N = static_cast<unsigned int>(x1 - x0);  //3 到 4
    // std::cout<<"x1 x0:"<< x1<<","<<x0<<" N:"<<N<<std::endl;
    for (unsigned int i = 0; i < N; ++i) {
        if (steep) {
            if (HasObstacle(Vec2i(yk, x0 + i * 1.0))
                || BeyondBoundary(Vec2d(yk * MAP_GRID_RESOLUTION_,
                                        (x0 + i) * MAP_GRID_RESOLUTION_))
                    ) {
                return false;
            }
        } else {
            if (HasObstacle(Vec2i(x0 + i * 1.0, yk))
                || BeyondBoundary(Vec2d((x0 + i) * MAP_GRID_RESOLUTION_,
                                        yk * MAP_GRID_RESOLUTION_))
                    ) {
                return false;
            }
        }

        error += delta_error;  //k斜率
        if (error >= 0.5) {
            yk += y_step;
            error = error - 1.0;
        }
    }

    return true;
}

//判断是否发生碰撞，先将车辆转移到全局坐标系
bool HybridAStar::CheckCollision(const double &x, const double &y, const double &theta) {
    Timer timer;
    Mat2d R;
    R << std::cos(theta), -std::sin(theta),
            std::sin(theta), std::cos(theta);

    MatXd transformed_vehicle_shape;
    transformed_vehicle_shape.resize(8, 1);
    for (unsigned int i = 0; i < 4u; ++i) {
        transformed_vehicle_shape.block<2, 1>(i * 2, 0)
                = R * vehicle_shape_.block<2, 1>(i * 2, 0) + Vec2d(x, y);
    }

    Vec2i transformed_pt_index_0 = Coordinate2MapGridIndex(
            transformed_vehicle_shape.block<2, 1>(0, 0)
    );
    Vec2i transformed_pt_index_1 = Coordinate2MapGridIndex(
            transformed_vehicle_shape.block<2, 1>(2, 0)
    );

    Vec2i transformed_pt_index_2 = Coordinate2MapGridIndex(
            transformed_vehicle_shape.block<2, 1>(4, 0)
    );

    Vec2i transformed_pt_index_3 = Coordinate2MapGridIndex(
            transformed_vehicle_shape.block<2, 1>(6, 0)
    );

    double y1, y0, x1, x0;
    // pt1 -> pt0
    x0 = static_cast<double>(transformed_pt_index_0.x());
    y0 = static_cast<double>(transformed_pt_index_0.y());
    x1 = static_cast<double>(transformed_pt_index_1.x());
    y1 = static_cast<double>(transformed_pt_index_1.y());

    if (!LineCheck(x1, y1, x0, y0)) {
        return false;
    }

    // pt2 -> pt1
    x0 = static_cast<double>(transformed_pt_index_1.x());
    y0 = static_cast<double>(transformed_pt_index_1.y());
    x1 = static_cast<double>(transformed_pt_index_2.x());
    y1 = static_cast<double>(transformed_pt_index_2.y());

    if (!LineCheck(x1, y1, x0, y0)) {
        return false;
    }

    // pt3 -> pt2
    x0 = static_cast<double>(transformed_pt_index_2.x());
    y0 = static_cast<double>(transformed_pt_index_2.y());
    x1 = static_cast<double>(transformed_pt_index_3.x());
    y1 = static_cast<double>(transformed_pt_index_3.y());

    if (!LineCheck(x1, y1, x0, y0)) {
        return false;
    }

    // pt0 -> pt3
    x0 = static_cast<double>(transformed_pt_index_0.x());  //将int转化为double  小数位后添加.0
    y0 = static_cast<double>(transformed_pt_index_0.y());
    x1 = static_cast<double>(transformed_pt_index_3.x());
    y1 = static_cast<double>(transformed_pt_index_3.y());

    if (!LineCheck(x0, y0, x1, y1)) {
        return false;
    }

    check_collision_use_time += timer.End();
    num_check_collision++;
    return true;
}

bool HybridAStar::HasObstacle(const int grid_index_x, const int grid_index_y) const {
    return (grid_index_x >= 0 && grid_index_x < MAP_GRID_SIZE_X_
            && grid_index_y >= 0 && grid_index_y < MAP_GRID_SIZE_Y_
            && (map_data_[grid_index_y * MAP_GRID_SIZE_X_ + grid_index_x] == 1));
}

bool HybridAStar::HasObstacle(const Vec2i &grid_index) const {
    int grid_index_x = grid_index[0];
    int grid_index_y = grid_index[1];

    return (grid_index_x >= 0 && grid_index_x < MAP_GRID_SIZE_X_
            && grid_index_y >= 0 && grid_index_y < MAP_GRID_SIZE_Y_
            && (map_data_[grid_index_y * MAP_GRID_SIZE_X_ + grid_index_x] == 1));
}

//设置障碍物
void HybridAStar::SetObstacle(unsigned int x, unsigned int y) {
    if (x > static_cast<unsigned int>(MAP_GRID_SIZE_X_)
        || y > static_cast<unsigned int>(MAP_GRID_SIZE_Y_)) {
        return;
    }

    map_data_[x + y * MAP_GRID_SIZE_X_] = 1;
}

void HybridAStar::SetObstacle(const double pt_x, const double pt_y) {
    if (pt_x < map_x_lower_ || pt_x > map_x_upper_ ||
        pt_y < map_y_lower_ || pt_y > map_y_upper_) {
        return;
    }

    int grid_index_x = static_cast<int>((pt_x - map_x_lower_) / MAP_GRID_RESOLUTION_);
    int grid_index_y = static_cast<int>((pt_y - map_y_lower_) / MAP_GRID_RESOLUTION_);

    map_data_[grid_index_x + grid_index_y * MAP_GRID_SIZE_X_] = 1;
}

//离散化求出车辆轮廓点，采用向量
void HybridAStar::SetVehicleShape(double length, double width, double rear_axle_dist) { //rear_axle_dist 
    vehicle_shape_.resize(8);
    vehicle_shape_.block<2, 1>(0, 0) = Vec2d(-rear_axle_dist, width / 2);           //右后
    vehicle_shape_.block<2, 1>(2, 0) = Vec2d(length - rear_axle_dist, width / 2);   //右前
    vehicle_shape_.block<2, 1>(4, 0) = Vec2d(length - rear_axle_dist, -width / 2);  //左前
    vehicle_shape_.block<2, 1>(6, 0) = Vec2d(-rear_axle_dist, -width / 2);          //左后

    const double step_size = move_step_size_;
    const auto N_length = static_cast<unsigned int>(length / step_size);  //1.0/0.2=5
    const auto N_width = static_cast<unsigned int> (width / step_size);   //0.8/0.2=4
    vehicle_shape_discrete_.resize(2, (N_length + N_width) * 2u);         //2*18

    const Vec2d edge_0_normalized = (vehicle_shape_.block<2, 1>(2, 0)
                                     - vehicle_shape_.block<2, 1>(0, 0)).normalized();  //车长方向单位向量
    for (unsigned int i = 0; i < N_length; ++i) {
        vehicle_shape_discrete_.block<2, 1>(0, i + N_length)
                = vehicle_shape_.block<2, 1>(4, 0) - edge_0_normalized * i * step_size;
        vehicle_shape_discrete_.block<2, 1>(0, i)
                = vehicle_shape_.block<2, 1>(0, 0) + edge_0_normalized * i * step_size;
    }

    const Vec2d edge_1_normalized = (vehicle_shape_.block<2, 1>(4, 0)
                                     - vehicle_shape_.block<2, 1>(2, 0)).normalized();  //车宽方向单位向量
    for (unsigned int i = 0; i < N_width; ++i) {
        vehicle_shape_discrete_.block<2, 1>(0, (2 * N_length) + i)
                = vehicle_shape_.block<2, 1>(2, 0) + edge_1_normalized * i * step_size;
        vehicle_shape_discrete_.block<2, 1>(0, (2 * N_length) + i + N_width)
                = vehicle_shape_.block<2, 1>(6, 0) - edge_1_normalized * i * step_size;
    }
}

__attribute__((unused)) Vec2d HybridAStar::CoordinateRounding(const Vec2d &pt) const {
    return MapGridIndex2Coordinate(Coordinate2MapGridIndex(pt));
}

Vec2d HybridAStar::MapGridIndex2Coordinate(const Vec2i &grid_index) const {
    Vec2d pt;
    pt.x() = ((double) grid_index[0] + 0.5) * MAP_GRID_RESOLUTION_ + map_x_lower_;
    pt.y() = ((double) grid_index[1] + 0.5) * MAP_GRID_RESOLUTION_ + map_y_lower_;

    return pt;
}

//
Vec3i HybridAStar::State2Index(const Vec3d &state) const {
    Vec3i index;

    index[0] = std::min(std::max(int((state[0] - map_x_lower_) / STATE_GRID_RESOLUTION_), 0), STATE_GRID_SIZE_X_ - 1);
    index[1] = std::min(std::max(int((state[1] - map_y_lower_) / STATE_GRID_RESOLUTION_), 0), STATE_GRID_SIZE_Y_ - 1);
    index[2] = std::min(std::max(int((state[2] - (-M_PI)) / ANGULAR_RESOLUTION_), 0), STATE_GRID_SIZE_PHI_ - 1);

    return index;
}

Vec3i HybridAStar::State2Index(const Vec4d &state) const {
    Vec3i index;

    index[0] = std::min(std::max(int((state[0] - map_x_lower_) / STATE_GRID_RESOLUTION_), 0), STATE_GRID_SIZE_X_ - 1);
    index[1] = std::min(std::max(int((state[1] - map_y_lower_) / STATE_GRID_RESOLUTION_), 0), STATE_GRID_SIZE_Y_ - 1);
    index[2] = std::min(std::max(int((state[2] - (-M_PI)) / ANGULAR_RESOLUTION_), 0), STATE_GRID_SIZE_PHI_ - 1);

    return index;
}

Vec2i HybridAStar::Coordinate2MapGridIndex(const Vec2d &pt) const {
    Vec2i grid_index;

    grid_index[0] = int((pt[0] - map_x_lower_) / MAP_GRID_RESOLUTION_);
    grid_index[1] = int((pt[1] - map_y_lower_) / MAP_GRID_RESOLUTION_);
    return grid_index;
}

//主要计算先是前向计算角度搜索，再离散计算车辆轨迹，加入邻居节点；后向同理
void HybridAStar::GetNeighborNodes(const StateNode::Ptr &curr_node_ptr,
                                   std::vector<StateNode::Ptr> &neighbor_nodes) {
    neighbor_nodes.clear();

    //角度分支搜索 比如 -3 至 3 共 6 个
    for (int i = -steering_discrete_num_; i <= steering_discrete_num_; ++i) {
        VectorVec4d intermediate_state;
        bool has_obstacle = false;

        double x = curr_node_ptr->state_.x();
        double y = curr_node_ptr->state_.y();
        double theta = curr_node_ptr->state_.z();

        const double phi = i * steering_radian_step_size_;  

        // forward
        //此循环是为了离散化车辆运动学采样，越小则越准确，但时间消耗较大
        for (int j = 1; j <= segment_length_discrete_num_; j++) {
            DynamicModel(move_step_size_, phi, x, y, theta);  //车辆运动学模型
            intermediate_state.emplace_back(Vec4d(x, y, theta,1));

            if (!CheckCollision(x, y, theta)) {
                has_obstacle = true;
                break;
            }
        }

        Vec3i grid_index = State2Index(intermediate_state.back());
        if (!BeyondBoundary(intermediate_state.back().head(2)) && !has_obstacle) {
            auto neighbor_forward_node_ptr = new StateNode(grid_index);
            neighbor_forward_node_ptr->intermediate_states_ = intermediate_state;
            neighbor_forward_node_ptr->state_ = intermediate_state.back();
            neighbor_forward_node_ptr->steering_grade_ = i;
            neighbor_forward_node_ptr->direction_ = StateNode::FORWARD;
            neighbor_nodes.push_back(neighbor_forward_node_ptr);
        }

        // backward
        //此循环是为了离散化车辆运动学采样，越小则越准确，但时间消耗较大
        has_obstacle = false;
        intermediate_state.clear();
        x = curr_node_ptr->state_.x();
        y = curr_node_ptr->state_.y();
        theta = curr_node_ptr->state_.z();
        for (int j = 1; j <= segment_length_discrete_num_; j++) {
            DynamicModel(-move_step_size_, phi, x, y, theta);
            intermediate_state.emplace_back(Vec4d(x, y, theta,-1));

            if (!CheckCollision(x, y, theta)) {
                has_obstacle = true;
                break;
            }
        }

        if (!BeyondBoundary(intermediate_state.back().head(2)) && !has_obstacle) {
            grid_index = State2Index(intermediate_state.back());
            auto neighbor_backward_node_ptr = new StateNode(grid_index);
            neighbor_backward_node_ptr->intermediate_states_ = intermediate_state;
            neighbor_backward_node_ptr->state_ = intermediate_state.back();
            neighbor_backward_node_ptr->steering_grade_ = i;
            neighbor_backward_node_ptr->direction_ = StateNode::BACKWARD;
            neighbor_nodes.push_back(neighbor_backward_node_ptr);
        }
    }
}

//运动学模型
void HybridAStar::DynamicModel(const double &step_size, const double &phi,
                               double &x, double &y, double &theta) const {
    x = x + step_size * std::cos(theta);
    y = y + step_size * std::sin(theta);
    theta = Mod2Pi(theta + step_size / wheel_base_ * std::tan(phi));  //角度变换，theta+变化量
}

double HybridAStar::Mod2Pi(const double &x) {
    double v = fmod(x, 2 * M_PI);

    if (v < -M_PI) {
        v += 2.0 * M_PI;
    } else if (v > M_PI) {
        v -= 2.0 * M_PI;
    }

    return v;
}

bool HybridAStar::BeyondBoundary(const Vec2d &pt) const {
    return pt.x() < map_x_lower_ || pt.x() > map_x_upper_ || pt.y() < map_y_lower_ || pt.y() > map_y_upper_;
}

double HybridAStar::ComputeH(const StateNode::Ptr &current_node_ptr,
                             const StateNode::Ptr &terminal_node_ptr) {
    double h;
    // L2
    h = (current_node_ptr->state_.head(2) - terminal_node_ptr->state_.head(2)).norm();  //head(2)是指前两位  .norm二范数

    // L1
    // h = (current_node_ptr->state_.head(2) - terminal_node_ptr->state_.head(2)).lpNorm<1>();   //.lpnorm 一范数

    if (h < 3.0 * shot_distance_) {
        h = rs_path_ptr_->Distance(current_node_ptr->state_.x(), current_node_ptr->state_.y(),
                                   current_node_ptr->state_.z(),
                                   terminal_node_ptr->state_.x(), terminal_node_ptr->state_.y(),
                                   terminal_node_ptr->state_.z());
    }

    return h;
}

//计算路径的G值，
double HybridAStar::ComputeG(const StateNode::Ptr &current_node_ptr,
                             const StateNode::Ptr &neighbor_node_ptr) const {
    double g;
    if (neighbor_node_ptr->direction_ == StateNode::FORWARD) {  //前向
        if (neighbor_node_ptr->steering_grade_ != current_node_ptr->steering_grade_) {
            if (neighbor_node_ptr->steering_grade_ == 0) {
                g = segment_length_ * steering_change_penalty_;
            } else {
                g = segment_length_ * steering_change_penalty_ * steering_penalty_;
            }
        } else {
            if (neighbor_node_ptr->steering_grade_ == 0) {
                g = segment_length_;
            } else {
                g = segment_length_ * steering_penalty_;
            }
        }
    } else {
        if (neighbor_node_ptr->steering_grade_ != current_node_ptr->steering_grade_) {
            if (neighbor_node_ptr->steering_grade_ == 0) {
                g = segment_length_ * steering_change_penalty_ * reversing_penalty_;
            } else {
                g = segment_length_ * steering_change_penalty_ * steering_penalty_ * reversing_penalty_;
            }
        } else {
            if (neighbor_node_ptr->steering_grade_ == 0) {
                g = segment_length_ * reversing_penalty_;
            } else {
                g = segment_length_ * steering_penalty_ * reversing_penalty_;
            }
        }
    }

    return g;
}

//搜索路径
bool HybridAStar::Search(const Vec4d &start_state, const Vec4d &goal_state) {
    Timer search_used_time;  //计时开始

    double neighbor_time = 0.0, compute_h_time = 0.0, compute_g_time = 0.0;

    const Vec3i start_grid_index = State2Index(start_state);
    const Vec3i goal_grid_index = State2Index(goal_state);

    auto goal_node_ptr = new StateNode(goal_grid_index);
    goal_node_ptr->state_ = goal_state;
    goal_node_ptr->direction_ = StateNode::NO;
    goal_node_ptr->steering_grade_ = 0;

    auto start_node_ptr = new StateNode(start_grid_index);
    start_node_ptr->state_ = start_state;
    start_node_ptr->steering_grade_ = 0;
    start_node_ptr->direction_ = StateNode::NO;
    start_node_ptr->node_status_ = StateNode::IN_OPENSET;
    Vec4d start_state_4v;
    start_state_4v << start_state,0.0;
    start_node_ptr->intermediate_states_.emplace_back(start_state_4v);  //中间节点，暂时不清楚原理
    start_node_ptr->g_cost_ = 0.0;
    start_node_ptr->f_cost_ = ComputeH(start_node_ptr, goal_node_ptr);

    state_node_map_[start_grid_index.x()][start_grid_index.y()][start_grid_index.z()] = start_node_ptr;  //写入开始目标点的节点
    state_node_map_[goal_grid_index.x()][goal_grid_index.y()][goal_grid_index.z()] = goal_node_ptr;

    openset_.clear();
    openset_.insert(std::make_pair(0, start_node_ptr)); 

    std::vector<StateNode::Ptr> neighbor_nodes_ptr;
    StateNode::Ptr current_node_ptr;
    StateNode::Ptr neighbor_node_ptr;

    int count = 0;
    while (!openset_.empty()) {
        current_node_ptr = openset_.begin()->second; 
        current_node_ptr->node_status_ = StateNode::IN_CLOSESET; 
        openset_.erase(openset_.begin());  //移除第一个点，加入close列表
        double DistanceToEnd=(current_node_ptr->state_.head(2) - goal_node_ptr->state_.head(2)).norm();
        double rs_shot_p;
        double random_value = dis(gen);  //随机数
        if (DistanceToEnd <= 5.0) 
            rs_shot_p = 1.0;
        else if (DistanceToEnd > 5.0 && DistanceToEnd < 30.0) 
            rs_shot_p = 1.0 - ((DistanceToEnd - 5.0) / 25.0) * (1.0 - 0.02);
        else 
            rs_shot_p = 0.02;
        
        cout<<"random_value:"<<random_value<<" rs_shot_p:"<<rs_shot_p<<endl;
        if ( random_value<= rs_shot_p) {   //距离小于shot 则尝试使用rs链接
        cout<<"DistanceToEnd："<<DistanceToEnd<<" 尝试rs连接"<<endl;
            double rs_length = 0.0;
            if (AnalyticExpansions(current_node_ptr, goal_node_ptr, rs_length)) {
                terminal_node_ptr_ = goal_node_ptr;

                StateNode::Ptr grid_node_ptr = terminal_node_ptr_->parent_node_;
                while (grid_node_ptr != nullptr) {
                    grid_node_ptr = grid_node_ptr->parent_node_;
                    path_length_ = path_length_ + segment_length_;
                }
                path_length_ = path_length_ - segment_length_ + rs_length;

                std::cout << "ComputeH use time(ms): " << compute_h_time << std::endl;
                std::cout << "check collision use time(ms): " << check_collision_use_time << std::endl;
                std::cout << "GetNeighborNodes use time(ms): " << neighbor_time << std::endl;
                std::cout << "average time of check collision(ms): "
                          << check_collision_use_time / num_check_collision
                          << std::endl;
                ROS_INFO("\033[1;32m --> Time in Hybrid A star is %f ms, path length: %f  \033[0m\n",
                         search_used_time.End(), path_length_);

                check_collision_use_time = 0.0;
                num_check_collision = 0.0;
                return true;
            }
        }

        Timer timer_get_neighbor;
        GetNeighborNodes(current_node_ptr, neighbor_nodes_ptr);
        neighbor_time = neighbor_time + timer_get_neighbor.End();

        for (unsigned int i = 0; i < neighbor_nodes_ptr.size(); ++i) {
            neighbor_node_ptr = neighbor_nodes_ptr[i];

            //计算G值，仅仅计算长度，加上一些转向和倒车的惩罚
            Timer timer_compute_g;
            const double neighbor_edge_cost = ComputeG(current_node_ptr, neighbor_node_ptr);
            compute_g_time = compute_g_time + timer_get_neighbor.End();

            Timer timer_compute_h;
            //TODO:计算H值，使用的是二范数,后期可以改进
            const double current_h = ComputeH(current_node_ptr, goal_node_ptr) * tie_breaker_;
            compute_h_time = compute_h_time + timer_compute_h.End();

            const Vec3i &index = neighbor_node_ptr->grid_index_;
            if (state_node_map_[index.x()][index.y()][index.z()] == nullptr) {  //未探索节点，加入list中
                neighbor_node_ptr->g_cost_ = current_node_ptr->g_cost_ + neighbor_edge_cost;
                neighbor_node_ptr->parent_node_ = current_node_ptr;
                neighbor_node_ptr->node_status_ = StateNode::IN_OPENSET;
                neighbor_node_ptr->f_cost_ = neighbor_node_ptr->g_cost_ + current_h;
                openset_.insert(std::make_pair(neighbor_node_ptr->f_cost_, neighbor_node_ptr));
                state_node_map_[index.x()][index.y()][index.z()] = neighbor_node_ptr;
                continue;
            } else if (state_node_map_[index.x()][index.y()][index.z()]->node_status_ == StateNode::IN_OPENSET) {  //开放列表节点，若代价较小则替换，反之则删除
                double g_cost_temp = current_node_ptr->g_cost_ + neighbor_edge_cost;

                if (state_node_map_[index.x()][index.y()][index.z()]->g_cost_ > g_cost_temp) {
                    neighbor_node_ptr->g_cost_ = g_cost_temp;
                    neighbor_node_ptr->f_cost_ = g_cost_temp + current_h;
                    neighbor_node_ptr->parent_node_ = current_node_ptr;
                    neighbor_node_ptr->node_status_ = StateNode::IN_OPENSET;

                    /// TODO: This will cause a memory leak
                    //delete state_node_map_[index.x()][index.y()][index.z()];
                    state_node_map_[index.x()][index.y()][index.z()] = neighbor_node_ptr;
                } else {
                    delete neighbor_node_ptr;
                }
                continue;
            } else if (state_node_map_[index.x()][index.y()][index.z()]->node_status_ == StateNode::IN_CLOSESET) {  //在关闭列表节点，则直接删除
                delete neighbor_node_ptr;
                continue;
            }
        }

        count++;
        if (count > 100000) {  //最大迭代次数，超过最大迭代次数直接结束
            ROS_WARN("Exceeded the number of iterations, the search failed");
            return false;
        }
    }

    return false;
}

VectorVec4d HybridAStar::GetSearchedTree() {
    VectorVec4d tree;
    Vec4d point_pair;

    visited_node_number_ = 0;
    for (int i = 0; i < STATE_GRID_SIZE_X_; ++i) {
        for (int j = 0; j < STATE_GRID_SIZE_Y_; ++j) {
            for (int k = 0; k < STATE_GRID_SIZE_PHI_; ++k) {
                if (state_node_map_[i][j][k] == nullptr || state_node_map_[i][j][k]->parent_node_ == nullptr) {
                    continue;
                }

                const unsigned int number_states = state_node_map_[i][j][k]->intermediate_states_.size() - 1;
                for (unsigned int l = 0; l < number_states; ++l) {
                    point_pair.head(2) = state_node_map_[i][j][k]->intermediate_states_[l].head(2);
                    point_pair.tail(2) = state_node_map_[i][j][k]->intermediate_states_[l + 1].head(2);

                    tree.emplace_back(point_pair);
                }

                point_pair.head(2) = state_node_map_[i][j][k]->intermediate_states_[0].head(2);
                point_pair.tail(2) = state_node_map_[i][j][k]->parent_node_->state_.head(2);
                tree.emplace_back(point_pair);
                visited_node_number_++;
            }
        }
    }

    return tree;
}

void HybridAStar::ReleaseMemory() {
    if (map_data_ != nullptr) {
        delete[] map_data_;
        map_data_ = nullptr;
    }

    if (state_node_map_) {
        for (int i = 0; i < STATE_GRID_SIZE_X_; ++i) {
            if (state_node_map_[i] == nullptr)
                continue;

            for (int j = 0; j < STATE_GRID_SIZE_Y_; ++j) {
                if (state_node_map_[i][j] == nullptr)
                    continue;

                for (int k = 0; k < STATE_GRID_SIZE_PHI_; ++k) {
                    if (state_node_map_[i][j][k] != nullptr) {
                        delete state_node_map_[i][j][k];
                        state_node_map_[i][j][k] = nullptr;
                    }
                }

                delete[] state_node_map_[i][j];
                state_node_map_[i][j] = nullptr;
            }

            delete[] state_node_map_[i];
            state_node_map_[i] = nullptr;
        }

        delete[] state_node_map_;
        state_node_map_ = nullptr;
    }

    terminal_node_ptr_ = nullptr;
}

__attribute__((unused)) double HybridAStar::GetPathLength() const {
    return path_length_;
}

VectorVec4d HybridAStar::GetPath(VectorVec4d &path_original)  {

    std::vector<StateNode::Ptr> temp_nodes;

    StateNode::Ptr state_grid_node_ptr = terminal_node_ptr_;
    while (state_grid_node_ptr != nullptr) {  //回溯节点
        temp_nodes.emplace_back(state_grid_node_ptr);
        state_grid_node_ptr = state_grid_node_ptr->parent_node_;
    }

    std::reverse(temp_nodes.begin(), temp_nodes.end());

    for (const auto &node: temp_nodes) {  //插入中间节点
        pcl::PointXYZI node_point_watch;
        node_point_watch.x=node->state_.x();
        node_point_watch.y=node->state_.y();
        // std::cout<<"node_x_y:"<<node_point_watch.x<<","<<node_point_watch.y<<","<<node->state_.z()<<","<<node->state_.w()<<std::endl;
        node_points_watch->points.push_back(node_point_watch);

        path_original.insert(path_original.end(), node->intermediate_states_.begin(),
                    node->intermediate_states_.end());
    }
    if (path_original.size()>1)  //第一个点方向赋值
    {
        path_original[0].w()=path_original[1].w();
    }

    VectorVec4d path_smoothed=Smooth(path_original); //后端平滑优化

    return path_smoothed;
}

void HybridAStar::Reset() {
    if (state_node_map_) {
        for (int i = 0; i < STATE_GRID_SIZE_X_; ++i) {
            if (state_node_map_[i] == nullptr)
                continue;

            for (int j = 0; j < STATE_GRID_SIZE_Y_; ++j) {
                if (state_node_map_[i][j] == nullptr)
                    continue;

                for (int k = 0; k < STATE_GRID_SIZE_PHI_; ++k) {
                    if (state_node_map_[i][j][k] != nullptr) {
                        delete state_node_map_[i][j][k];
                        state_node_map_[i][j][k] = nullptr;
                    }
                }
            }
        }
    }

    path_length_ = 0.0;
    terminal_node_ptr_ = nullptr;
}

//判断路径是否超越范围及碰撞，使用RS曲线链接，保存路径
bool HybridAStar::AnalyticExpansions(const StateNode::Ptr &current_node_ptr,
                                     const StateNode::Ptr &goal_node_ptr, double &length) {
    VectorVec4d rs_path_poses = rs_path_ptr_->GetRSPath(current_node_ptr->state_,
                                                        goal_node_ptr->state_,
                                                        move_step_size_, length);

    for (const auto &pose: rs_path_poses)
        if (BeyondBoundary(pose.head(2)) || !CheckCollision(pose.x(), pose.y(), pose.z())) {
            return false;
        };

    goal_node_ptr->intermediate_states_ = rs_path_poses;
    
    goal_node_ptr->parent_node_ = current_node_ptr;

    auto begin = goal_node_ptr->intermediate_states_.begin();
    goal_node_ptr->intermediate_states_.erase(begin);

    return true;
}


VectorVec4d HybridAStar::Smooth(VectorVec4d &path)
{
    clock_t time_start = clock();
    std::vector<VectorVec4d> RawPath=PathSegmentsByDirection(path);
    std::vector<VectorVec4d> smoothed_paths;  //总路径
    int solver_num=0;  //求解总次数
    for (size_t pathNumber = 0;pathNumber < RawPath.size(); pathNumber++)
    {
        VectorVec4d smoothed_path;  //分段路径
        std::cout<<"优化第 "<<pathNumber+1<<" / "<<RawPath.size()<<" 段开始"<<std::endl;
        if (RawPath[pathNumber].size()<6)   //若路径点不足六个，则不优化路线
        {
            for (size_t i = 0; i < RawPath[pathNumber].size(); i++)
            {
                smoothed_paths.push_back(RawPath[pathNumber]);
            }
            std::cout<<"小于6个，直接返回"<<std::endl;
            continue;
        }
        
        int PathPointsNum=RawPath[pathNumber].size();
        float x_lb = -1; // x限制值
        float x_ub = 1;
        float y_ub = 1;
        float y_lb = -1;

        float w_smooth = 3e4;
        float w_length = 10;
        float w_ref = 1;

        // std::cout<<"num:"<<PathPointsNum<<std::endl;
        Eigen::VectorXd referenceline = Eigen::VectorXd::Zero(2*PathPointsNum);
        Eigen::VectorXd referenceline_x = Eigen::VectorXd::Zero(PathPointsNum);
        Eigen::VectorXd referenceline_y = Eigen::VectorXd::Zero(PathPointsNum);
        for (int i = 0; i < PathPointsNum; i++)
        {
            referenceline_x(i) = RawPath[pathNumber][i][0];
            referenceline_y(i) = RawPath[pathNumber][i][1];
            referenceline(2*i) =RawPath[pathNumber][i][0];
            referenceline(2*i+1) =RawPath[pathNumber][i][1];
            // std::cout<<"ref_xy:"<<referenceline_x(i)<<","<<referenceline_y(i)<<std::endl;
        }

        std::cout<<" -- 参数加载中 --"<<std::endl;
        Eigen::SparseMatrix<double> A1(2 * PathPointsNum - 4, 2 * PathPointsNum);
        Eigen::SparseMatrix<double> A2(2 * PathPointsNum - 2, 2 * PathPointsNum);
        // 创建稀疏矩阵对象
        Eigen::SparseMatrix<double> A3(2 * PathPointsNum, 2 * PathPointsNum);
        // 遍历对角线上的元素，设置为1

        for (int i = 0; i < 2 * PathPointsNum; ++i)
        {
            A3.insert(i, i) = 1.0; // 在(i, i)位置插入1.0
        }
        // 将所有元素插入矩阵中
        A3.makeCompressed();
        
        Eigen::MatrixXd A_cons_ = Eigen::MatrixXd::Identity(2 * PathPointsNum , 2 * PathPointsNum);  //增加首尾位置限制
        Eigen::MatrixXd A_cons = Eigen::MatrixXd::Zero(2 * PathPointsNum + 12 , 2 * PathPointsNum);  //增加首尾位置限制
        A_cons.block(0, 0, 2 * PathPointsNum, 2 * PathPointsNum) = A_cons_;
        

        Eigen::MatrixXd H = Eigen::MatrixXd::Zero(2 * PathPointsNum, 2 * PathPointsNum);
        Eigen::VectorXd f = Eigen::VectorXd::Zero(2 * PathPointsNum);
        
        Eigen::VectorXd lb = Eigen::VectorXd::Zero(2 * PathPointsNum +12);
        Eigen::VectorXd ub = Eigen::VectorXd::Zero(2 * PathPointsNum +12);

        Eigen::VectorXd dynamic_lb = Eigen::VectorXd::Constant(2 * PathPointsNum, x_lb);  //这里是区别与上述lb、ub，这里是正方形xy限制范围，是动态调整的
        Eigen::VectorXd dynamic_ub = Eigen::VectorXd::Constant(2 * PathPointsNum, x_ub);  //因为初始xy限制都是一样的，故都设置为x的范围

        std::cout<<" -- 条件赋值中 -- "<<std::endl;

        for (int i = 0; i < PathPointsNum; i++)
        {
            f(2 * i) = referenceline_x(i);
            f(2 * i + 1) = referenceline_y(i);
            lb(2 * i) = f(2 * i) + x_lb;
            ub(2 * i) = f(2 * i) + x_ub;
            lb(2 * i + 1) = f(2 * i + 1) + y_lb;
            ub(2 * i + 1) = f(2 * i + 1) + y_ub;
        }
        for (int i = 0; i < 2 * PathPointsNum - 4; i++)
        {
            A1.coeffRef(i, i) = 1;
            A1.coeffRef(i, i + 2) = -2;
            A1.coeffRef(i, i + 4) = 1;
        }
        // A2赋值
        for (int i = 0; i < 2 * PathPointsNum - 2; i++)
        {
            A2.coeffRef(i, i) = 1;
            A2.coeffRef(i, i + 2) = -1;
        }

        // 限制条件赋值
        for (int i = 0; i < 6; i=i+2)  //添加首尾点航向3个点的限制
        {
            A_cons(2 * PathPointsNum + i , i ) = 1;   //start_x
            A_cons(2 * PathPointsNum + i+1 , i+1 ) = 1;  //start_y
            
            lb(2 * PathPointsNum + i)=referenceline_x(i); ub(2 * PathPointsNum+ i)=referenceline_x(i);  //最大限制xy
            lb(2 * PathPointsNum + i + 1)=referenceline_y(i); ub(2 * PathPointsNum + i + 1)=referenceline_y(i);  //
            // lb(2 * PathPointsNum + i)=i; ub(2 * PathPointsNum+ i)=i;  //最大限制xy
            // lb(2 * PathPointsNum + i + 1)=i; ub(2 * PathPointsNum + i + 1)=i;  //
            
            A_cons(2 * PathPointsNum + i +6 , 2 * PathPointsNum +i-6) = 1;   //end_x
            A_cons(2 * PathPointsNum + i +7 , 2 * PathPointsNum +i-5) = 1;  //end_y

            lb(2 * PathPointsNum + i +6)=referenceline_x(PathPointsNum +i-6); ub(2 * PathPointsNum + i +6)=referenceline_x(PathPointsNum +i-6);  //最大限制xy
            lb(2 * PathPointsNum + i +7)=referenceline_y(PathPointsNum +i-5); ub(2 * PathPointsNum + i +7)=referenceline_y(PathPointsNum +i-5);  //
            // std::cout<<"num:"<<2 * PathPointsNum +i-6<<" value:"<<referenceline_x(2 * PathPointsNum +i-6)<<std::endl;
        }
        // std::cout<<"A_CONS:"<<A_cons<<std::endl;

        std::cout<<" -- 求解中 -- "<<std::endl;
        H = 2 * (w_smooth * A1.transpose() * A1 + w_length * A2.transpose() * A2 + w_ref * A3);
        f = -2 * w_ref * f;
        // osqp求解
        
        int NumberOfVariables = 2 * PathPointsNum;   // A矩阵的列数
        int NumberOfConstraints = 2 * PathPointsNum+12; // A矩阵的行数

        bool no_collsion=false;
        
        while (!no_collsion)
        {
            solver_num++;
            // 求解部分
            OsqpEigen::Solver solver;
            Eigen::SparseMatrix<double> H_osqp = H.sparseView(); // 密集矩阵转换为稀疏矩阵
            H_osqp.makeCompressed();                             // 压缩稀疏行 (CSR) 格式
            H_osqp.reserve(H.nonZeros());                        // 预分配非零元素数量
            std::cout<<" -- 求解"<<solver_num<<" 次中  -- "<<std::endl;
            Eigen::SparseMatrix<double> linearMatrix = A_cons.sparseView();
            linearMatrix.makeCompressed();                 // 压缩稀疏行 (CSR) 格式
            linearMatrix.reserve(linearMatrix.nonZeros()); // 预分配非零元素数量

            solver.settings()->setVerbosity(false); // 求解器信息输出控制
            solver.settings()->setWarmStart(true);
            solver.data()->setNumberOfVariables(NumberOfVariables);     // 设置A矩阵的列数，即n
            solver.data()->setNumberOfConstraints(NumberOfConstraints); // 设置A矩阵的行数，即m
            // std::cout<<" -- 求解kaishi  -- "<<std::endl;
            if (!solver.data()->setHessianMatrix(H_osqp))
                // return 1; //设置P矩阵
                std::cout << "error1" << std::endl;
            if (!solver.data()->setGradient(f))
                // return 1; //设置q or f矩阵。当没有时设置为全0向量
                std::cout << "error2" << std::endl;
            if (!solver.data()->setLinearConstraintsMatrix(linearMatrix))
                // return 1; //设置线性约束的A矩阵
                std::cout << "error3" << std::endl;
            if (!solver.data()->setLowerBound(lb))
            { // return 1; //设置下边界
                std::cout << "error4" << std::endl;
            }
            if (!solver.data()->setUpperBound(ub))
            { // return 1; //设置上边界
                std::cout << "error5" << std::endl;
            }
            solver.setPrimalVariable(referenceline);
            // instantiate the solver
            if (!solver.initSolver())
                // return 1;
                std::cout << "error6" << std::endl;
            // Eigen::VectorXd QPSolution;

            // solve the QP problem

            // if (solver.solveProblem() != Eigen::Success)
            // {
            //     std::cout << "error_slove" << std::endl;
            // }

            OsqpEigen::ErrorExitFlag result = solver.solveProblem();
            // std::cout<<" -- 求解jieshu 1  -- "<<std::endl;
            Eigen::VectorXd QPSolution;
            QPSolution = solver.getSolution();
            std::cout<<" -- 求解第 "<<solver_num<<" 次完成  -- "<<std::endl;

            for (int i = 0; i < QPSolution.size(); i=i+2)
            {
                Vec4d temp_point;
                temp_point(0)=QPSolution(i);
                temp_point(1)=QPSolution(i+1);
                temp_point(2)=0;  //航向角暂时设置为0
                temp_point(3)=RawPath[pathNumber][0][3];
                smoothed_path.emplace_back(temp_point);
            }
            GetPathYaw(smoothed_path);

            float boundary_penalty_raw=1.5;
            bool Flag_Collision=true;
            for (int i = 1; i < smoothed_path.size()-1; i++)
            {   
                if(!CheckCollision(smoothed_path[i][0], smoothed_path[i][1], smoothed_path[i][2])) //碰撞
                {   
                    Flag_Collision=false;
                    std::cout<<"第"<<i<<"个点碰撞！！！"<<"共"<<smoothed_path.size()<<"个点"<<std::endl;
                    int now_number=2*i;
                    if(smoothed_path[i][0]<=referenceline_x(i))  //x
                    {
                        dynamic_lb(now_number)   /= boundary_penalty_raw;
                        dynamic_lb(now_number-2) /= boundary_penalty_raw;
                        dynamic_lb(now_number+2) /= boundary_penalty_raw;

                        lb(now_number)   = referenceline_x(i)   + dynamic_lb(now_number); 
                        lb(now_number-2) = referenceline_x(i-1) + dynamic_lb(now_number-2);
                        lb(now_number+2) = referenceline_x(i+1) + dynamic_lb(now_number+2);
                        std::cout<<"x_lb改变为:"<<dynamic_lb(now_number)<<std::endl;
                    }
                    else
                    {
                        dynamic_ub(now_number)   /= boundary_penalty_raw;
                        dynamic_ub(now_number-2) /= boundary_penalty_raw;
                        dynamic_ub(now_number+2) /= boundary_penalty_raw;

                        ub(now_number)   = referenceline_x(i)   + dynamic_ub(now_number);
                        ub(now_number-2) = referenceline_x(i-1) + dynamic_ub(now_number-2);
                        ub(now_number+2) = referenceline_x(i+1) + dynamic_ub(now_number+2);
                        std::cout<<"x_ub改变为:"<<dynamic_ub(now_number)<<std::endl;
                    }

                    if(smoothed_path[i][1]<=referenceline_y(i))  //y
                    {
                        dynamic_lb(now_number+1) /= boundary_penalty_raw;
                        dynamic_lb(now_number-1) /= boundary_penalty_raw;
                        dynamic_lb(now_number+3) /= boundary_penalty_raw;

                        lb(now_number+1) = referenceline_y(i) + dynamic_lb(now_number+1);
                        lb(now_number-1) = referenceline_y(i-1) + dynamic_lb(now_number-1);
                        lb(now_number+3) = referenceline_y(i+1) + dynamic_lb(now_number+3);
                        std::cout<<"y_lb改变为:"<<dynamic_lb(now_number+1)<<std::endl;
                    }
                    else
                    {
                        dynamic_ub(now_number+1) /= boundary_penalty_raw;
                        dynamic_ub(now_number-1) /= boundary_penalty_raw;
                        dynamic_ub(now_number+3) /= boundary_penalty_raw;

                        ub(now_number+1) = referenceline_y(i) + dynamic_ub(now_number+1);
                        ub(now_number-1) = referenceline_y(i-1) + dynamic_ub(now_number-1);
                        ub(now_number+3) = referenceline_y(i+1) + dynamic_ub(now_number+3);
                        std::cout<<"y_ub改变为:"<<dynamic_ub(now_number+1)<<std::endl;
                    }
                    // dynamic_lb(now_number)   /= boundary_penalty_raw; dynamic_ub(now_number)   /= boundary_penalty_raw;
                    // dynamic_lb(now_number+1) /= boundary_penalty_raw; dynamic_ub(now_number+1) /= boundary_penalty_raw;
                    // dynamic_lb(now_number-2) /= boundary_penalty_raw; dynamic_ub(now_number-2) /= boundary_penalty_raw;
                    // dynamic_lb(now_number-1) /= boundary_penalty_raw; dynamic_ub(now_number-1) /= boundary_penalty_raw;
                    // dynamic_lb(now_number+2) /= boundary_penalty_raw; dynamic_ub(now_number+2) /= boundary_penalty_raw;
                    // dynamic_lb(now_number+3) /= boundary_penalty_raw; dynamic_ub(now_number+3) /= boundary_penalty_raw;
                   
                    // std::cout<<"y_lb ub改变为:"<<dynamic_lb(now_number+1)<<","<<dynamic_ub(now_number+1)<<std::endl;

                    // lb(now_number)   = referenceline_x(i) + dynamic_lb(now_number);       ub(now_number)   = referenceline_x(i) + dynamic_ub(now_number);
                    // lb(now_number+1) = referenceline_y(i) + dynamic_lb(now_number+1);     ub(now_number+1) = referenceline_y(i) + dynamic_ub(now_number+1);
 
                    // lb(now_number-2) = referenceline_x(i-1) + dynamic_lb(now_number-2);   ub(now_number-2) = referenceline_x(i-1) + dynamic_ub(now_number-2);
                    // lb(now_number-1) = referenceline_y(i-1) + dynamic_lb(now_number-1);   ub(now_number-1) = referenceline_y(i-1) + dynamic_ub(now_number-1);

                    // lb(now_number+2) = referenceline_x(i+1) + dynamic_lb(now_number+2);   ub(now_number+2) = referenceline_x(i+1) + dynamic_ub(now_number+2);
                    // lb(now_number+3) = referenceline_y(i+1) + dynamic_lb(now_number+3);   ub(now_number+3) = referenceline_y(i+1) + dynamic_ub(now_number+3);
                    // smoothed_path.clear();
                    // break;
                }
            }
            if(Flag_Collision)  //无碰撞
            {
                no_collsion=Flag_Collision;
            }
            else
            {
                smoothed_path.clear();
            }
            
        }
        smoothed_paths.push_back(smoothed_path);
        
        std::cout << "Path optimization progress --100% " <<std::endl;
       
    }
    std::cout<<"END!!!"<<std::endl;
    // GetPathYaw(smoothed_paths);
    VectorVec4d return_smoothed_path; 
    for (size_t i = 0; i < smoothed_paths.size(); i++)
    {
        for (size_t j = 0; j < smoothed_paths[i].size(); j++)
        {
            return_smoothed_path.emplace_back(smoothed_paths[i][j]);
        }
    }
    
    std::cout<<"求解 "<<solver_num<<" 次完成优化！！！"<<std::endl;
    clock_t time_end2 = clock();
    double time_diff2 = static_cast<double>(time_end2 - time_start) / CLOCKS_PER_SEC;
    std::cout << "QP程序运行时间: " << time_diff2 << " 秒" << std::endl;
    return return_smoothed_path;
}

void HybridAStar::GetPathYaw(std::vector<VectorVec4d> &RawPath) {
    clock_t time_start = clock();
    for (size_t i = 0; i < RawPath.size(); i++) { // 遍历不同路径段
        const int car_dir=RawPath[i][0][3]; 
        const int n=RawPath[i].size();
        // 判断行进方向：前进(1)或后退(-1)
        if (n<=6)
        {
            for (size_t j = 0; j < n - 1; j++) {
                // 判断当前点的前进方向
                if (RawPath[i][j][3] == 1) { // 前进方向
                    double yaw = atan2(RawPath[i][j + 1][1] - RawPath[i][j][1],
                                       RawPath[i][j + 1][0] - RawPath[i][j][0]);
                    RawPath[i][j][2] = yaw;
                } else if (RawPath[i][j][3] == -1) { // 后退方向
                    double yaw = atan2(RawPath[i][j][1] - RawPath[i][j + 1][1],
                                       RawPath[i][j][0] - RawPath[i][j + 1][0]);
                    RawPath[i][j][2] = yaw;
                }
            }
            // 计算最后一个点的航向角
            if (n > 1) {
                if (RawPath[i][n - 1][3] == 1) { // 前进方向
                    double yaw = atan2(RawPath[i][n - 1][1] - RawPath[i][n - 2][1],
                                       RawPath[i][n - 1][0] - RawPath[i][n - 2][0]);
                    RawPath[i][n - 1][2] = yaw;
                } else if (RawPath[i][n - 1][3] == -1) { // 后退方向
                    double yaw = atan2(RawPath[i][n - 2][1] - RawPath[i][n - 1][1],
                                       RawPath[i][n - 2][0] - RawPath[i][n - 1][0]);
                    RawPath[i][n - 1][2] = yaw;
                }
            }
        }
        else
        {
            for (size_t j = 2; j < RawPath[i].size() - 2; j++) { // 忽略开头和结尾的两个点
                if (car_dir == 1) { // 前进方向
                    // 计算平滑航向角
                    double yaw1 = atan2(RawPath[i][j][1] - RawPath[i][j - 2][1],
                                        RawPath[i][j][0] - RawPath[i][j - 2][0]);
                    double yaw2 = atan2(RawPath[i][j + 2][1] - RawPath[i][j][1],
                                        RawPath[i][j + 2][0] - RawPath[i][j][0]);

                    double smoothed_yaw = (yaw1 + yaw2 ) / 2.0;

                    RawPath[i][j][2] = smoothed_yaw;

                } else if (car_dir== -1) { // 后退方向
                    // 计算平滑航向角（方向相反，加 180° 或 π 修正）
                    double yaw1 = atan2(RawPath[i][j][1] - RawPath[i][j - 2][1],
                                        RawPath[i][j][0] - RawPath[i][j - 2][0]) + M_PI;
                    double yaw2 = atan2(RawPath[i][j+2][1] - RawPath[i][j][1],
                                        RawPath[i][j+2][0] - RawPath[i][j][0]) + M_PI;

                    // 保证角度在 [-π, π] 范围内
                    yaw1 = std::fmod(yaw1 + M_PI, 2 * M_PI) - M_PI;
                    yaw2 = std::fmod(yaw2 + M_PI, 2 * M_PI) - M_PI;

                    // 平均航向角，平滑结果
                    double smoothed_yaw = (yaw1 + yaw2) / 2.0;

                    // 更新 RawPath 的 yaw 值
                    RawPath[i][j][2] = smoothed_yaw;
                }
            }
            if (car_dir == 1)  //前进
            {
                RawPath[i][0][2] =atan2(RawPath[i][1][1] - RawPath[i][0][1],RawPath[i][1][0] - RawPath[i][0][0]);
                RawPath[i][1][2] =atan2(RawPath[i][2][1] - RawPath[i][1][1],RawPath[i][2][0] - RawPath[i][1][0]);
                
                RawPath[i][n-2][2] =atan2(RawPath[i][n-2][1] - RawPath[i][n-3][1],RawPath[i][n-2][0] - RawPath[i][n-3][0]);
                RawPath[i][n-1][2] =atan2(RawPath[i][n-1][1] - RawPath[i][n-2][1],RawPath[i][n-1][0] - RawPath[i][n-2][0]);
            }
            else    //倒车
            {
                RawPath[i][0][2] = atan2(RawPath[i][0][1] - RawPath[i][1][1],RawPath[i][0][0] - RawPath[i][1][0]);
                RawPath[i][1][2] = atan2(RawPath[i][1][1] - RawPath[i][2][1],RawPath[i][1][0] - RawPath[i][2][0]);
                RawPath[i][n - 2][2] = atan2(RawPath[i][n - 3][1] - RawPath[i][n - 2][1],RawPath[i][n - 3][0] - RawPath[i][n - 2][0]);
                RawPath[i][n - 1][2] = atan2(RawPath[i][n - 2][1] - RawPath[i][n - 1][1],RawPath[i][n - 2][0] - RawPath[i][n - 1][0]);
            }
        }
    }
    clock_t time_end2 = clock();
    double time_diff2 = static_cast<double>(time_end2 - time_start) / CLOCKS_PER_SEC;
    std::cout << "yaw程序运行时间: " << time_diff2 << " 秒" << std::endl;
}


void HybridAStar::GetPathYaw(VectorVec4d &RawPath) {
    clock_t time_start = clock();

        const int car_dir=RawPath[0][3]; 
        const int n=RawPath.size();
        // 判断行进方向：前进(1)或后退(-1)
        if (n<=6)
        {
            for (size_t j = 0; j < n - 1; j++) {
                // 判断当前点的前进方向
                if (RawPath[j][3] == 1) { // 前进方向
                    double yaw = atan2(RawPath[j + 1][1] - RawPath[j][1],
                                       RawPath[j + 1][0] - RawPath[j][0]);
                    RawPath[j][2] = yaw;
                } else if (RawPath[j][3] == -1) { // 后退方向
                    double yaw = atan2(RawPath[j][1] - RawPath[j + 1][1],
                                       RawPath[j][0] - RawPath[j + 1][0]);
                    RawPath[j][2] = yaw;
                }
            }
            // 计算最后一个点的航向角
            if (n > 1) {
                if (RawPath[n - 1][3] == 1) { // 前进方向
                    double yaw = atan2(RawPath[n - 1][1] - RawPath[n - 2][1],
                                       RawPath[n - 1][0] - RawPath[n - 2][0]);
                    RawPath[n - 1][2] = yaw;
                } else if (RawPath[n - 1][3] == -1) { // 后退方向
                    double yaw = atan2(RawPath[n - 2][1] - RawPath[n - 1][1],
                                       RawPath[n - 2][0] - RawPath[n - 1][0]);
                    RawPath[n - 1][2] = yaw;
                }
            }
        }
        else
        {
            for (size_t j = 2; j < RawPath.size() - 2; j++) { // 忽略开头和结尾的两个点
                if (car_dir == 1) { // 前进方向
                    // 计算平滑航向角
                    double yaw1 = atan2(RawPath[j][1] - RawPath[j - 2][1],
                                        RawPath[j][0] - RawPath[j - 2][0]);
                    double yaw2 = atan2(RawPath[j + 2][1] - RawPath[j][1],
                                        RawPath[j + 2][0] - RawPath[j][0]);

                    double smoothed_yaw = (yaw1 + yaw2 ) / 2.0;

                    RawPath[j][2] = smoothed_yaw;

                } else if (car_dir== -1) { // 后退方向
                    // 计算平滑航向角（方向相反，加 180° 或 π 修正）
                    double yaw1 = atan2(RawPath[j][1] - RawPath[j - 2][1],
                                        RawPath[j][0] - RawPath[j - 2][0]) + M_PI;
                    double yaw2 = atan2(RawPath[j+2][1] - RawPath[j][1],
                                        RawPath[j+2][0] - RawPath[j][0]) + M_PI;

                    // 保证角度在 [-π, π] 范围内
                    yaw1 = std::fmod(yaw1 + M_PI, 2 * M_PI) - M_PI;
                    yaw2 = std::fmod(yaw2 + M_PI, 2 * M_PI) - M_PI;

                    // 平均航向角，平滑结果
                    double smoothed_yaw = (yaw1 + yaw2) / 2.0;

                    // 更新 RawPath 的 yaw 值
                    RawPath[j][2] = smoothed_yaw;
                }
            }
            if (car_dir == 1)  //前进
            {
                RawPath[0][2] =atan2(RawPath[1][1] - RawPath[0][1],RawPath[1][0] - RawPath[0][0]);
                RawPath[1][2] =atan2(RawPath[2][1] - RawPath[1][1],RawPath[2][0] - RawPath[1][0]);
                
                RawPath[n-2][2] =atan2(RawPath[n-2][1] - RawPath[n-3][1],RawPath[n-2][0] - RawPath[n-3][0]);
                RawPath[n-1][2] =atan2(RawPath[n-1][1] - RawPath[n-2][1],RawPath[n-1][0] - RawPath[n-2][0]);
            }
            else    //倒车
            {
                RawPath[0][2] = atan2(RawPath[0][1] - RawPath[1][1],RawPath[0][0] - RawPath[1][0]);
                RawPath[1][2] = atan2(RawPath[1][1] - RawPath[2][1],RawPath[1][0] - RawPath[2][0]);
                RawPath[n - 2][2] = atan2(RawPath[n - 3][1] - RawPath[n - 2][1],RawPath[n - 3][0] - RawPath[n - 2][0]);
                RawPath[n - 1][2] = atan2(RawPath[n - 2][1] - RawPath[n - 1][1],RawPath[n - 2][0] - RawPath[n - 1][0]);
            }
        }
    
    clock_t time_end2 = clock();
    double time_diff2 = static_cast<double>(time_end2 - time_start) / CLOCKS_PER_SEC;
    std::cout << "yaw程序运行时间: " << time_diff2 << " 秒" << std::endl;
}

std::vector<VectorVec4d> HybridAStar::PathSegmentsByDirection(VectorVec4d& path) {
    std::vector<VectorVec4d> path_Segments;

    int direction=path[0][3];

    int i=0;
    while (i < path.size())
    {
        VectorVec4d path_Segment;
        for ( ; i < path.size(); i++)
        {
            if (direction!=path[i][3])
            {
                direction=path[i][3];
                break;
            }
            else
            {
                path_Segment.push_back(path[i]);
            }
        }
        path_Segments.push_back(path_Segment);
    }

    return path_Segments;
}

