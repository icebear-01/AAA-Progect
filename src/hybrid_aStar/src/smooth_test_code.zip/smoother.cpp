/*
 * @Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @Date: 2024-11-20 17:20:56
 * @LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @LastEditTime: 2024-12-16 20:43:21
 * @FilePath: /src/planning/src/hybrid_aStar/Hybrid_A_Star-main/src/smoother.cpp
 * @Description: 
 * 
 * Copyright (c) 2024 by ${git_name_email}, All Rights Reserved. 
 */

// TODO:针对小倒车，除了终点处的倒车，可以考虑直接舍弃，使用优化直接优化出去
// TODO: Implement this function
#include "HA_Smoother/smoother.h"

HA_Smoother::HA_Smoother(std::vector<VectorVec4d> &RawPath)
{
    PathLength=0;
    total_PathPointsNum=0;
    for (int i = 0; i < RawPath.size(); ++i)
    {
        for (int j = 1; j < RawPath[i].size(); ++j) {
            PathLength += std::sqrt((RawPath[i][j][0] - RawPath[i][j-1][0]) * (RawPath[i][j][0] - RawPath[i][j-1][0]) +
                                    (RawPath[i][j][1] - RawPath[i][j-1][1]) *(RawPath[i][j][1] - RawPath[i][j-1][1]));
            total_PathPointsNum++;
        }
    }
}

// Eigen::VectorXd HA_Smoother::Smooth()
std::vector<VectorVec4d> HA_Smoother::Smooth(std::vector<VectorVec4d> &RawPath)
{
    std::vector<VectorVec4d> smoothed_paths;  //总路径
    for (size_t pathNumber = 0;pathNumber < RawPath.size(); pathNumber++)
    {
        VectorVec4d smoothed_path;  //分段路径
        std::cout<<"优化第 "<<pathNumber+1<<" / "<<RawPath.size()<<" 段开始"<<std::endl;
        if (RawPath[pathNumber].size()<6)   //若路径点不足六个，则不优化路线
        {
            for (size_t i = 0; i < RawPath[pathNumber].size(); i++)
            {
                smoothed_paths.push_back(RawPath[pathNumber]);
            }
            std::cout<<"小于6个，直接返回"<<std::endl;
            continue;
        }
        
        int PathPointsNum=RawPath[pathNumber].size();
        float x_lb = -0.9; // x限制值
        float x_ub = 0.9;
        float y_ub = 0.9;
        float y_lb = -0.9;

        float w_smooth = 1e5;
        float w_length = 2;
        float w_ref = 1;

        // std::cout<<"num:"<<PathPointsNum<<std::endl;
        Eigen::VectorXd referenceline_x = Eigen::VectorXd::Zero(PathPointsNum);
        Eigen::VectorXd referenceline_y = Eigen::VectorXd::Zero(PathPointsNum);
        for (int i = 0; i < RawPath[pathNumber].size(); i++)
        {
            referenceline_x(i) = RawPath[pathNumber][i][0];
            referenceline_y(i) = RawPath[pathNumber][i][1];
            // std::cout<<"ref_xy:"<<referenceline_x(i)<<","<<referenceline_y(i)<<std::endl;
        }

        std::cout<<" -- 参数加载中 --"<<std::endl;
        Eigen::SparseMatrix<double> A1(2 * PathPointsNum - 4, 2 * PathPointsNum);
        Eigen::SparseMatrix<double> A2(2 * PathPointsNum - 2, 2 * PathPointsNum);
        // 创建稀疏矩阵对象
        Eigen::SparseMatrix<double> A3(2 * PathPointsNum, 2 * PathPointsNum);
        // 遍历对角线上的元素，设置为1

        for (int i = 0; i < 2 * PathPointsNum; ++i)
        {
            A3.insert(i, i) = 1.0; // 在(i, i)位置插入1.0
        }
        // 将所有元素插入矩阵中
        A3.makeCompressed();
        
        Eigen::MatrixXd A_cons_ = Eigen::MatrixXd::Identity(2 * PathPointsNum , 2 * PathPointsNum);  //增加首尾位置限制
        Eigen::MatrixXd A_cons = Eigen::MatrixXd::Zero(2 * PathPointsNum + 12 , 2 * PathPointsNum);  //增加首尾位置限制
        A_cons.block(0, 0, 2 * PathPointsNum, 2 * PathPointsNum) = A_cons_;
        

        Eigen::MatrixXd H = Eigen::MatrixXd::Zero(2 * PathPointsNum, 2 * PathPointsNum);
        Eigen::VectorXd f = Eigen::VectorXd::Zero(2 * PathPointsNum);
        
        Eigen::VectorXd lb = Eigen::VectorXd::Zero(2 * PathPointsNum +12);
        Eigen::VectorXd ub = Eigen::VectorXd::Zero(2 * PathPointsNum +12);

        std::cout<<" -- 条件赋值中 -- "<<std::endl;

        for (int i = 0; i < PathPointsNum; i++)
        {
            f(2 * i) = referenceline_x(i);
            f(2 * i + 1) = referenceline_y(i);
            lb(2 * i) = f(2 * i) + x_lb;
            ub(2 * i) = f(2 * i) + x_ub;
            lb(2 * i + 1) = f(2 * i + 1) + y_lb;
            ub(2 * i + 1) = f(2 * i + 1) + y_ub;
        }
        for (int i = 0; i < 2 * PathPointsNum - 4; i++)
        {
            A1.coeffRef(i, i) = 1;
            A1.coeffRef(i, i + 2) = -2;
            A1.coeffRef(i, i + 4) = 1;
        }
        // A2赋值
        for (int i = 0; i < 2 * PathPointsNum - 2; i++)
        {
            A2.coeffRef(i, i) = 1;
            A2.coeffRef(i, i + 2) = -1;
        }

        // 限制条件赋值
        for (int i = 0; i < 6; i=i+2)  //添加首尾点航向3个点的限制
        {
            A_cons(2 * PathPointsNum + i , i ) = 1;   //start_x
            A_cons(2 * PathPointsNum + i+1 , i+1 ) = 1;  //start_y
            
            lb(2 * PathPointsNum + i)=referenceline_x(i); ub(2 * PathPointsNum+ i)=referenceline_x(i);  //最大限制xy
            lb(2 * PathPointsNum + i + 1)=referenceline_y(i); ub(2 * PathPointsNum + i + 1)=referenceline_y(i);  //
            // lb(2 * PathPointsNum + i)=i; ub(2 * PathPointsNum+ i)=i;  //最大限制xy
            // lb(2 * PathPointsNum + i + 1)=i; ub(2 * PathPointsNum + i + 1)=i;  //
            
            A_cons(2 * PathPointsNum + i +6 , 2 * PathPointsNum +i-6) = 1;   //end_x
            A_cons(2 * PathPointsNum + i +7 , 2 * PathPointsNum +i-5) = 1;  //end_y

            lb(2 * PathPointsNum + i +6)=referenceline_x(PathPointsNum +i-6); ub(2 * PathPointsNum + i +6)=referenceline_x(PathPointsNum +i-6);  //最大限制xy
            lb(2 * PathPointsNum + i +7)=referenceline_y(PathPointsNum +i-5); ub(2 * PathPointsNum + i +7)=referenceline_y(PathPointsNum +i-5);  //
            // std::cout<<"num:"<<2 * PathPointsNum +i-6<<" value:"<<referenceline_x(2 * PathPointsNum +i-6)<<std::endl;
        }
        // std::cout<<"A_CONS:"<<A_cons<<std::endl;

        std::cout<<" -- 求解中 -- "<<std::endl;
        H = 2 * (w_smooth * A1.transpose() * A1 + w_length * A2.transpose() * A2 + w_ref * A3);
        f = -2 * w_ref * f;
        // osqp求解

        int NumberOfVariables = 2 * PathPointsNum;   // A矩阵的列数
        int NumberOfConstraints = 2 * PathPointsNum+12; // A矩阵的行数
        // 求解部分
        OsqpEigen::Solver solver;
        Eigen::SparseMatrix<double> H_osqp = H.sparseView(); // 密集矩阵转换为稀疏矩阵
        H_osqp.makeCompressed();                             // 压缩稀疏行 (CSR) 格式
        H_osqp.reserve(H.nonZeros());                        // 预分配非零元素数量
        std::cout<<" -- 求解中 H -- "<<std::endl;
        Eigen::SparseMatrix<double> linearMatrix = A_cons.sparseView();
        linearMatrix.makeCompressed();                 // 压缩稀疏行 (CSR) 格式
        linearMatrix.reserve(linearMatrix.nonZeros()); // 预分配非零元素数量

        solver.settings()->setVerbosity(false); // 求解器信息输出控制
        solver.data()->setNumberOfVariables(NumberOfVariables);     // 设置A矩阵的列数，即n
        solver.data()->setNumberOfConstraints(NumberOfConstraints); // 设置A矩阵的行数，即m
        std::cout<<" -- 求解kaishi  -- "<<std::endl;
        if (!solver.data()->setHessianMatrix(H_osqp))
            // return 1; //设置P矩阵
            std::cout << "error1" << std::endl;
        if (!solver.data()->setGradient(f))
            // return 1; //设置q or f矩阵。当没有时设置为全0向量
            std::cout << "error2" << std::endl;
        if (!solver.data()->setLinearConstraintsMatrix(linearMatrix))
            // return 1; //设置线性约束的A矩阵
            std::cout << "error3" << std::endl;
        if (!solver.data()->setLowerBound(lb))
        { // return 1; //设置下边界
            std::cout << "error4" << std::endl;
        }
        if (!solver.data()->setUpperBound(ub))
        { // return 1; //设置上边界
            std::cout << "error5" << std::endl;
        }

        // instantiate the solver
        if (!solver.initSolver())
            // return 1;
            std::cout << "error6" << std::endl;
        // Eigen::VectorXd QPSolution;

        // solve the QP problem

        // if (solver.solveProblem() != Eigen::Success)
        // {
        //     std::cout << "error_slove" << std::endl;
        // }

        OsqpEigen::ErrorExitFlag result = solver.solveProblem();
        std::cout<<" -- 求解jieshu 1  -- "<<std::endl;
        Eigen::VectorXd QPSolution;
        QPSolution = solver.getSolution();

        for (int i = 0; i < QPSolution.size(); i=i+2)
        {
            Vec4d temp_point;
            temp_point(0)=QPSolution(i);
            temp_point(1)=QPSolution(i+1);
            temp_point(2)=0;  //航向角暂时设置为0
            temp_point(3)=RawPath[pathNumber][0][3];
            smoothed_path.push_back(temp_point);
        }
        smoothed_paths.push_back(smoothed_path);
        
        std::cout << "Path optimization progress --100% " <<std::endl;
        std::cout<<"优化第 "<<pathNumber+1<<" 段结束！！！"<<std::endl;
    }
    std::cout<<"END!!!"<<std::endl;

    // for (size_t i = 0; i < *QPSolutionPtr.size(); i+=2)
    // {
    //     std::cout<<" opt:"<<QPSolution_1(i)<<" ,"<<QPSolution_1(i+1)<<std::endl;
    // }
    
    return smoothed_paths;
}

// std::vector<std::vector<double>> HA_Smoother::CalculateLinearizedCurvatureParams(   //个人认为是将曲率约束线性化，下面的有多个系数的式子是泰勒展开后的线性化中导数的计算
//     const VectorVec4d &RawPath) {

//     int RawPathSize=RawPath.size();
//     std::vector<std::vector<double>> lin_cache;
//     for (int i = 1; i < RawPathSize - 1; ++i) {
//         std::vector<double> Param_;
//         double x_f = RawPath[i - 1][0];
//         double x_m = RawPath[i][0];
//         double x_l = RawPath[i + 1][0];
//         double y_f = RawPath[i - 1][1];
//         double y_m = RawPath[i][1];
//         double y_l = RawPath[i + 1][1];

//         double linear_term_x_f = 2.0 * x_f - 4.0 * x_m + 2.0 * x_l; 
//         double linear_term_x_m = 8.0 * x_m - 4.0 * x_f - 4.0 * x_l;
//         double linear_term_x_l = 2.0 * x_l - 4.0 * x_m + 2.0 * x_f;
//         double linear_term_y_f = 2.0 * y_f - 4.0 * y_m + 2.0 * y_l;
//         double linear_term_y_m = 8.0 * y_m - 4.0 * y_f - 4.0 * y_l;
//         double linear_term_y_l = 2.0 * y_l - 4.0 * y_m + 2.0 * y_f;

//         //F(X)-F'(X)
//         double linear_approx = (-2.0 * x_m + x_f + x_l) * (-2.0 * x_m + x_f + x_l) +
//                                 (-2.0 * y_m + y_f + y_l) * (-2.0 * y_m + y_f + y_l) +
//                                 -x_f * linear_term_x_f + -x_m * linear_term_x_m +
//                                 -x_l * linear_term_x_l + -y_f * linear_term_y_f +
//                                 -y_m * linear_term_y_m + -y_l * linear_term_y_l;

//         Param_.push_back(linear_term_x_f);
//         Param_.push_back(linear_term_x_m);
//         Param_.push_back(linear_term_x_l);
//         Param_.push_back(linear_term_y_f);
//         Param_.push_back(linear_term_y_m);
//         Param_.push_back(linear_term_y_l);
//         Param_.push_back(linear_approx);
//         lin_cache.push_back(Param_);
//     }
//     return lin_cache;
// }