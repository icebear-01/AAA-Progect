/*
 * @Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @Date: 2024-10-08 11:16:16
 * @LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @LastEditTime: 2024-10-17 11:20:05
 * @FilePath: /src/planning/src/hybrid_aStar/Hybrid_A_Star-main/include/hybrid_a_star/hybrid_a_star_flow.h
 * @Description: 
 * 
 * Copyright (c) 2024 by ${git_name_email}, All Rights Reserved. 
 */
#ifndef HYBRID_A_STAR_HYBRID_A_STAR_FLOW_H
#define HYBRID_A_STAR_HYBRID_A_STAR_FLOW_H

#include "hybrid_a_star.h"
#include "costmap_subscriber.h"
#include "init_pose_subscriber.h"
#include "goal_pose_subscriber.h"

#include <ros/ros.h>

#include <planning_msgs/path_point.h>
#include <planning_msgs/point.h>
#include <planning_msgs/car_path.h>

#include <planning_msgs/hybrid_astar_paths.h>
#include <planning_msgs/hybrid_astar_path.h>
#include <planning_msgs/hybrid_astar_path_point.h>


class HybridAStarFlow {
public:
    HybridAStarFlow() = default;  //显式声明构造函数，但是是空，这样可以默认构造

    explicit HybridAStarFlow(ros::NodeHandle &nh);  //explicit 禁止隐式调用，只能显式调用

    void Run();

private:
    void InitPoseData();

    void ReadData();

    bool HasStartPose();

    bool HasGoalPose();

    void PublishPathToControl(const VectorVec4d &path);

    void PublishPath(const VectorVec4d &path);

    void PublishSearchedTree(const VectorVec4d &searched_tree);

    void PublishVehiclePath(const VectorVec4d &path, double width,
                            double length, unsigned int vehicle_interval);

    bool NextPlan(const VectorVec4d &path);

private:
    std::shared_ptr<HybridAStar> kinodynamic_astar_searcher_ptr_;
    std::shared_ptr<CostMapSubscriber> costmap_sub_ptr_;
    std::shared_ptr<InitPoseSubscriber2D> init_pose_sub_ptr_;
    std::shared_ptr<GoalPoseSubscriber2D> goal_pose_sub_ptr_;
    std::shared_ptr<InitPoseSubscriber2D> init_pose_car_position_sub_ptr_;

    ros::Publisher path_pub_;
    ros::Publisher path_pub_planning_path;  //自定义消息发布类型
    ros::Publisher searched_tree_pub_;
    ros::Publisher vehicle_path_pub_;
    ros::Publisher line_pub_local_path;  

    std::deque<geometry_msgs::PoseWithCovarianceStampedPtr> init_pose_deque_;
    std::deque<geometry_msgs::PoseStampedPtr> goal_pose_deque_;
    std::deque<nav_msgs::OccupancyGridPtr> costmap_deque_;

    geometry_msgs::PoseWithCovarianceStampedPtr current_init_pose_ptr_;  //初始化起始点
    geometry_msgs::PoseStampedPtr current_goal_pose_ptr_;       //起始化终点
    nav_msgs::OccupancyGridPtr current_costmap_ptr_;        //代价地图

    geometry_msgs::Pose2D::Ptr car_pose_flow_ptr;  //车辆位置信息

    bool next_plan=true;
    VectorVec4d pub_path;

    double path_end_x=0.0;
    double path_end_y=0.0;

    float plan_vel=0.4;

    ros::Time timestamp_;

    bool has_map_{};
    int path_type=0; //规划的第几个路线编号
};

#endif //HYBRID_A_STAR_HYBRID_A_STAR_FLOW_H
