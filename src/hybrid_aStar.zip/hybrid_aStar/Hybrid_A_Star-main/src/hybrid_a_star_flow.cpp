#include "hybrid_a_star/hybrid_a_star_flow.h"

#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

#include <nav_msgs/Path.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <planning_msgs/car_path.h>
#include <planning_msgs/car_info.h>

using namespace std;
__attribute__((unused)) double Mod2Pi(const double &x) {  // 这是一个 GCC 和 Clang 编译器的扩展属性，这个函数可能不会被使用，防止编译器发出未使用函数的警告。
    double v = fmod(x, 2 * M_PI);

    if (v < -M_PI) {
        v += 2.0 * M_PI;
    } else if (v > M_PI) {
        v -= 2.0 * M_PI;
    }

    return v;
}

HybridAStarFlow::HybridAStarFlow(ros::NodeHandle &nh) {
    // steering_angle：从ROS参数服务器获取转向角度，默认值为10度。
    // steering_angle_discrete_num：转向角度的离散化数量，默认值为1。
    // wheel_base：车辆的轮距，默认值为1.0米。
    // segment_length：每个路径段的长度，默认值为1.6米。
    // segment_length_discrete_num：路径段长度的离散化数量，默认值为8。
    // steering_penalty：转向操作的成本惩罚，默认值为1.05。
    // steering_change_penalty：改变转向方向的成本惩罚，默认值为1.5。
    // reversing_penalty：倒车操作的成本惩罚，默认值为2.0。
    // shot_distance：搜索过程中每次向前探索的距离，默认值为5.0米。

    // <param name="planner/steering_angle" value="15.0"/>
    // <param name="planner/steering_angle_discrete_num" value="1"/>
    // <param name="planner/wheel_base" value="0.8"/>
    // <param name="planner/segment_length" value="1.6"/>
    // <param name="planner/segment_length_discrete_num" value="8"/>
    // <param name="planner/steering_penalty" value="2.0"/>
    // <param name="planner/reversing_penalty" value="3.0"/>
    // <param name="planner/steering_change_penalty" value="2.0"/>
    // <param name="planner/shot_distance" value="5.0"/>

    double steering_angle = nh.param("planner/steering_angle", 10);  //从ROS参数服务器获取转向角度，默认值为10度。 launch 文件读取参数
    int steering_angle_discrete_num = nh.param("planner/steering_angle_discrete_num", 1);
    double wheel_base = nh.param("planner/wheel_base", 0.8);
    double segment_length = nh.param("planner/segment_length", 1.6);
    int segment_length_discrete_num = nh.param("planner/segment_length_discrete_num", 8);
    double steering_penalty = nh.param("planner/steering_penalty", 1.05);
    double steering_change_penalty = nh.param("planner/steering_change_penalty", 1.5);
    double reversing_penalty = nh.param("planner/reversing_penalty", 2.0);
    double shot_distance = nh.param("planner/shot_distance", 5.0);

    kinodynamic_astar_searcher_ptr_ = std::make_shared<HybridAStar>(
            steering_angle, steering_angle_discrete_num, segment_length, segment_length_discrete_num, wheel_base,
            steering_penalty, reversing_penalty, steering_change_penalty, shot_distance);

    // costmap_sub_ptr_ = std::make_shared<CostMapSubscriber>(nh, "/map", 1);
    // init_pose_sub_ptr_ = std::make_shared<InitPoseSubscriber2D>(nh, "/initialpose", 1);
    goal_pose_sub_ptr_ = std::make_shared<GoalPoseSubscriber2D>(nh, "/move_base_simple/goal", 1);
    init_pose_car_position_sub_ptr_ = std::make_shared<InitPoseSubscriber2D>(nh, "/car_pos", 1);
    cout<<"aaa"<<endl;
    sub_reGoal = nh.subscribe("/long_obstacleList",10, &HybridAStarFlow::reGoalcallback, this);

    path_pub_ = nh.advertise<nav_msgs::Path>("searched_path", 1);
    path_pub_planning_path = nh.advertise<planning_msgs::hybrid_astar_paths>("/QP_Path", 1);
    searched_tree_pub_ = nh.advertise<visualization_msgs::Marker>("searched_tree", 1);
    vehicle_path_pub_ = nh.advertise<visualization_msgs::MarkerArray>("vehicle_path", 1);
    line_pub_local_path = nh.advertise<sensor_msgs::PointCloud2>("hybrid_astar_path_watch", 100);
    cluster_map_pub = nh.advertise<sensor_msgs::PointCloud2> ("/map_output", 1);

    has_map_ = false;
}

void HybridAStarFlow::Run() {
    ReadData();
    // std::cout<<"RUN!!!"<<std::endl;
    if (!has_map_) {
        // if (costmap_deque_.empty()) {
        //     return;
        // }

        // current_costmap_ptr_ = costmap_deque_.front();
        // costmap_deque_.pop_front();

        // const double map_resolution = static_cast<float>(current_costmap_ptr_->info.resolution); //获得地图的分辨率
        // kinodynamic_astar_searcher_ptr_->Init(                  //给出地图的长宽
        //         current_costmap_ptr_->info.origin.position.x,
        //         1.0 * current_costmap_ptr_->info.width * current_costmap_ptr_->info.resolution,
        //         current_costmap_ptr_->info.origin.position.y,
        //         1.0 * current_costmap_ptr_->info.height * current_costmap_ptr_->info.resolution,
        //         1.0, map_resolution    //这里状态采样为1.0有疑问
        // );
        // std::cout<<"Init:"<<current_costmap_ptr_->info.origin.position.x<<","<<current_costmap_ptr_->info.origin.position.y<<","<<1.0 * current_costmap_ptr_->info.width * current_costmap_ptr_->info.resolution
        // <<","<<1.0 * current_costmap_ptr_->info.height * current_costmap_ptr_->info.resolution<<std::endl;

        // unsigned int map_w = std::floor(current_costmap_ptr_->info.width);
        // unsigned int map_h = std::floor(current_costmap_ptr_->info.height);
        // min_x_map = current_costmap_ptr_->info.origin.position.x/grid_size;
        // min_y_map = current_costmap_ptr_->info.origin.position.y/grid_size;
        // numGrid_x = map_w;
        // numGrid_y = map_h;
        // cout<<"map_w:"<<map_w<<" "<<"map_h:"<<map_h<<endl;
        // for (unsigned int w = 0; w < map_w; ++w) {
        //     for (unsigned int h = 0; h < map_h; ++h) {
        //         if (current_costmap_ptr_->data[h * current_costmap_ptr_->info.width + w]) {
        //             kinodynamic_astar_searcher_ptr_->SetObstacle(w, h);
        //         }
        //     }
        // }
        environment_modeling();
        has_map_ = true;
    }
    // costmap_deque_.clear();

        if (sqrt(pow(path_end_x-car_pose_flow_ptr->x,2)+pow(path_end_y-car_pose_flow_ptr->y,2)) < 1)   //超越多少距离才算到达终点
        {
            next_plan=true;
        }
        else
        {
            next_plan=false;
        }
    
    std::cout<<"next_plan:"<<next_plan<<" distance:"<<sqrt(pow(path_end_x-car_pose_flow_ptr->x,2)+pow(path_end_y-car_pose_flow_ptr->y,2)) <<std::endl;
    if (pub_path.size()>0)
    {
        PublishPathToControl(pub_path);
        std::cout<<"pub_path"<<std::endl;
    }
    pub_cloud(clusterCloud,cluster_map_pub);

    while (HasGoalPose()&&car_state == normal) { //只进一次
        InitPoseData();
        double start_yaw = car_pose_flow_ptr->theta;
        double goal_yaw = tf::getYaw(current_goal_pose_ptr_->pose.orientation);

        Vec4d start_state = Vec4d(
                car_pose_flow_ptr->x,
                car_pose_flow_ptr->y,
                start_yaw,0
        );
        Vec4d goal_state = Vec4d(
                current_goal_pose_ptr_->pose.position.x,
                current_goal_pose_ptr_->pose.position.y,
                goal_yaw,0
        );

        if (kinodynamic_astar_searcher_ptr_->Search(start_state, goal_state)) {
            auto path = kinodynamic_astar_searcher_ptr_->GetPath();
            if (path.size()>1)
            {
                path[0].w()=path[1].w();
            }

            sensor_msgs::PointCloud2 ss_local_path;
            pcl::toROSMsg(*kinodynamic_astar_searcher_ptr_->node_points_watch, ss_local_path);
            ss_local_path.header.frame_id = "velodyne";
            line_pub_local_path.publish(ss_local_path);
            kinodynamic_astar_searcher_ptr_->node_points_watch.reset(new pcl::PointCloud<pcl::PointXYZI>);
            // std::cout<<"path_size:"<< path.size()<<std::endl;
            next_plan=NextPlan(path);
            path_end_x=path.back().x();
            path_end_y=path.back().y();
            pub_path=path;
            path_type++;
            
            PublishPathToControl(path);
            PublishPath(path);  //发送PATH数据
            PublishVehiclePath(path, 2.0, 1.0, 5u);    //路线显示大小
            PublishSearchedTree(kinodynamic_astar_searcher_ptr_->GetSearchedTree());  //显示搜索树

            nav_msgs::Path path_ros;
            geometry_msgs::PoseStamped pose_stamped;

            for (const auto &pose: path) {
                pose_stamped.header.frame_id = "velodyne";
                pose_stamped.pose.position.x = pose.x();
                pose_stamped.pose.position.y = pose.y();
                pose_stamped.pose.position.z = 0.0;

                pose_stamped.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, 0, pose.z());    //这里的z可能是航向角

                path_ros.poses.emplace_back(pose_stamped);
            }

            path_ros.header.frame_id = "velodyne";
            path_ros.header.stamp = ros::Time::now();
            static tf::TransformBroadcaster transform_broadcaster;
            // for (const auto &pose: path_ros.poses) {
            //     std::cout<<"pose_size:"<<path_ros.poses.size()<<std::endl;
            //     tf::Transform transform;
            //     transform.setOrigin(tf::Vector3(pose.pose.position.x, pose.pose.position.y, 0.0));

            //     tf::Quaternion q;
            //     q.setX(pose.pose.orientation.x);
            //     q.setY(pose.pose.orientation.y);
            //     q.setZ(pose.pose.orientation.z);
            //     q.setW(pose.pose.orientation.w);
            //     transform.setRotation(q);

            //     transform_broadcaster.sendTransform(tf::StampedTransform(transform,
            //                                                              ros::Time::now(), "world",
            //                                                              "ground_link")
            //     );
            //     std::cout<<"sleep_start"<<std::endl;
            //     ros::Duration(0.05).sleep();
            //     std::cout<<"sleep_endl"<<std::endl;
            // }
        }

        // debug
//        std::cout << "visited nodes: " << kinodynamic_astar_searcher_ptr_->GetVisitedNodesNumber() << std::endl;
        kinodynamic_astar_searcher_ptr_->Reset();
    }
}

//读取起始点和目标点
void HybridAStarFlow::ReadData() {
    // costmap_sub_ptr_->ParseData(costmap_deque_);
    car_pose_flow_ptr.reset(new geometry_msgs::Pose2D());

    init_pose_car_position_sub_ptr_->ParseData(car_pose_flow_ptr);
    goal_pose_sub_ptr_->ParseData(goal_pose_deque_);
}

bool HybridAStarFlow::NextPlan(const VectorVec4d &path) {

    if(path.empty())
    {
        return true;
    }
    std::cout<<"path.back():"<<path.back().x()<<","<<path.back().y()<<" car_pose_flow_ptr:"<<car_pose_flow_ptr->x<<","<<car_pose_flow_ptr->y<<std::endl;
    if(sqrt(pow(path.back().x()-car_pose_flow_ptr->x,2)+pow(path.back().y()-car_pose_flow_ptr->y,2)) < 1)  //这里暂时设置到路线终点0.1则认为到达终点
    {
        return true;
    }
    return false;

}

//取出起始点和目标点
void HybridAStarFlow::InitPoseData() {
    // current_init_pose_ptr_ = init_pose_deque_.front();
    // init_pose_deque_.pop_front();

    current_goal_pose_ptr_ = goal_pose_deque_.front();
    goal_pose_deque_.pop_front();
}

bool HybridAStarFlow::HasGoalPose() {
    // std::cout<<"HasGoalPose"<<std::endl;
    return !goal_pose_deque_.empty();
}

bool HybridAStarFlow::HasStartPose() {
    // std::cout<<"HasStartPose"<<std::endl;
    return !init_pose_deque_.empty();
}

void HybridAStarFlow::PublishPath(const VectorVec4d &path) {
    nav_msgs::Path nav_path;

    planning_msgs::car_path carPath;
    geometry_msgs::PoseStamped pose_stamped;
    for (const auto &pose: path) {
        pose_stamped.header.frame_id = "velodyne";
        pose_stamped.pose.position.x = pose.x();
        pose_stamped.pose.position.y = pose.y();
        pose_stamped.pose.position.z = 0.0;
        pose_stamped.pose.orientation = tf::createQuaternionMsgFromYaw(pose.z());

        planning_msgs::path_point carPathPoint;
        
        carPathPoint.x = pose.x();
        carPathPoint.y = pose.y();
        carPathPoint.yaw = pose.z();
        carPath.points.push_back(carPathPoint);

        nav_path.poses.emplace_back(pose_stamped);
    }
    nav_path.header.frame_id = "velodyne";
    nav_path.header.stamp = timestamp_;
    // for (int i = 0; i < path.size(); i++)
    // {
    //     std::cout<<"x,y,yaw,dir:"<<path[i].x()<<","<<path[i].y()<<","<<path[i].z()<<","<<path[i].w()<<std::endl;
    // }
}

void HybridAStarFlow::PublishPathToControl(const VectorVec4d &path) {

    // planning_msgs::car_path::Ptr PubPathPoints(new planning_msgs::car_path); 
    // PubPathPoints->path_type=path_type;
    // pcl::PointCloud<pcl::PointXYZI>::Ptr local_path(new pcl::PointCloud<pcl::PointXYZI>);

    // for (int i = 0; i < path.size(); i++)
    // {
    //     planning_msgs::path_point PathPoint;
    //     pcl::PointXYZI xyv;
    //     PathPoint.x=path[i].x();
    //     PathPoint.y=path[i].y();
    //     PathPoint.yaw=path[i].z();
    //     PathPoint.vel=path[i].w()*plan_vel;  //速度设置为0.4
    //     xyv.x=PathPoint.x;xyv.y=PathPoint.y;xyv.intensity=PathPoint.vel;
    //     // if (xyv.intensity<0)
    //     // {
    //         local_path->points.push_back(xyv);
    //     // }
        
    //     PubPathPoints->points.push_back(PathPoint);
    //     std::cout<<"vel "<<i<<":"<<PathPoint.x<<","<<PathPoint.y<<","<<PathPoint.yaw<<","<<PathPoint.vel<<std::endl;
    // }
    // // if (path.size()>1.0)
    // // {
    // //     PubPathPoints->points[0].vel=path[1].w()*plan_vel;
    // // }
    // //终点停车判断
    // if (sqrt(pow(init_pose_car_position_sub_ptr_->car_position_ptr->x-PubPathPoints->points.back().x,2)+pow(init_pose_car_position_sub_ptr_->car_position_ptr->y-PubPathPoints->points.back().y,2))<0.5)
    // {
    //     PubPathPoints->ReachTarget=true;
    // }
    // else
    // {
    //     PubPathPoints->ReachTarget=false;
    // }

    //     // DeBug watch
    //     sensor_msgs::PointCloud2 ss_local_path;
    //     pcl::toROSMsg(*local_path, ss_local_path);
    //     ss_local_path.header.frame_id = "velodyne";
    //     line_pub_local_path.publish(ss_local_path);
    // std::cout<<"vel:"<<PubPathPoints->points[0].x<<","<<PubPathPoints->points[0].y<<","<<PubPathPoints->points[0].yaw<<","<<PubPathPoints->points[0].vel<<std::endl;
    // path_pub_planning_path.publish(PubPathPoints);

    planning_msgs::hybrid_astar_paths::Ptr PubPaths(new planning_msgs::hybrid_astar_paths); 
    PubPaths->path_type=path_type;
    pcl::PointCloud<pcl::PointXYZI>::Ptr local_path(new pcl::PointCloud<pcl::PointXYZI>);

    int change_path=0;
    int i = 0;

    while (i<path.size())
    {
        planning_msgs::hybrid_astar_path PubPath;
        change_path=path[i].w();
        if (path[i].w()>0)
        {
            PubPath.direct=1;
        }
        else
        {
            PubPath.direct=-1;
        }
        std::cout<<"!!!!!!!!PubPath.direct:"<<PubPath.direct <<"!!!!!!!!!"<<std::endl;
        for (; i < path.size(); i++)
        {
            if (path[i].w()!=change_path)
            {
                // PubPath.single_path.back().vel=0.0;  //每段路径的终点设置为0
                break;
            }
            
            planning_msgs::hybrid_astar_path_point PubPath_point;

            PubPath_point.x=path[i].x();
            PubPath_point.y=path[i].y();
            PubPath_point.yaw=path[i].z();
            PubPath_point.vel=path[i].w()*plan_vel;  //速度设置为0.4
            PubPath.single_path.push_back(PubPath_point);
            // std::cout<<"vel11:"<<PubPath_point.x<<","<<PubPath_point.y<<","<<PubPath_point.yaw<<","<<PubPath_point.vel<<std::endl;
        }
        std::cout<<std::endl;
        PubPaths->Path.push_back(PubPath);
    }

    //debug
    // for (int j = 0; j < PubPaths->Path.size(); j++)
    // {
    //     std::cout<<"!!!!!!!!:"<<PubPaths->Path[j].direct<<std::endl;
    //     for (int k = 0; k < PubPaths->Path[j].single_path.size(); k++)
    //     {
    //         std::cout<<"vel12:"<<PubPaths->Path[j].single_path[k].x<<","<<PubPaths->Path[j].single_path[k].y<<","<<PubPaths->Path[j].single_path[k].yaw<<","<<PubPaths->Path[j].single_path[k].vel<<std::endl;
    //     }
    // }
    
    //观测
    for (int i = 0; i < path.size(); i++)
    {
        pcl::PointXYZI xyv;
        xyv.x=path[i].x();xyv.y=path[i].y();
        local_path->points.push_back(xyv);
    }
    //终点停车判断
    if (sqrt(pow(init_pose_car_position_sub_ptr_->car_position_ptr->x-path.back().x(),2)+pow(init_pose_car_position_sub_ptr_->car_position_ptr->y-path.back().y(),2))<0.25)
    {
        PubPaths->ReachTarget=true;
    }
    else
    {
        PubPaths->ReachTarget=false;
    }

        // DeBug watch
        sensor_msgs::PointCloud2 ss_local_path;
        pcl::toROSMsg(*local_path, ss_local_path);
        ss_local_path.header.frame_id = "velodyne";
        line_pub_local_path.publish(ss_local_path);
    // std::cout<<"vel:"<<PubPathPoints->points[0].x<<","<<PubPathPoints->points[0].y<<","<<PubPathPoints->points[0].yaw<<","<<PubPathPoints->points[0].vel<<std::endl;
    path_pub_planning_path.publish(PubPaths);

}

void HybridAStarFlow::pub_cloud(pcl::PointCloud<pcl::PointXYZI>::Ptr in_cloud, ros::Publisher Publisher)
{
    cout<<"111111111111111111"<<endl;
    sensor_msgs::PointCloud2 ros_msgs;
    pcl::toROSMsg(*in_cloud, ros_msgs);
    ros_msgs.header.frame_id = "velodyne";
    ros_msgs.header.stamp = ros::Time::now();
    Publisher.publish(ros_msgs);
}
//发布车辆路线
void HybridAStarFlow::PublishVehiclePath(const VectorVec4d &path, double width,
                                         double length, unsigned int vehicle_interval = 5u) {
    visualization_msgs::MarkerArray vehicle_array;

    for (unsigned int i = 0; i < path.size(); i += vehicle_interval) {
        visualization_msgs::Marker vehicle;

        if (i == 0) {    //这段代码可以参考
            vehicle.action = 3;
        }

        vehicle.header.frame_id = "velodyne";
        vehicle.header.stamp = ros::Time::now();
        vehicle.type = visualization_msgs::Marker::CUBE;
        vehicle.id = static_cast<int>(i / vehicle_interval);
        vehicle.scale.x = width;
        vehicle.scale.y = length;
        vehicle.scale.z = 0.01;
        vehicle.color.a = 0.05;

        vehicle.color.r = 0.0;
        vehicle.color.b = 0.0;
        vehicle.color.g = 1.0;

        vehicle.pose.position.x = path[i].x();
        vehicle.pose.position.y = path[i].y();
        vehicle.pose.position.z = 0.0;

        vehicle.pose.orientation = tf::createQuaternionMsgFromYaw(path[i].z());
        vehicle_array.markers.emplace_back(vehicle);
    }

    vehicle_path_pub_.publish(vehicle_array);
}

void HybridAStarFlow::PublishSearchedTree(const VectorVec4d &searched_tree) {   //搜索树显示
    visualization_msgs::Marker tree_list;
    tree_list.header.frame_id = "velodyne";
    tree_list.header.stamp = ros::Time::now();
    tree_list.type = visualization_msgs::Marker::LINE_LIST;
    tree_list.action = visualization_msgs::Marker::ADD;
    tree_list.ns = "searched_tree";
    tree_list.scale.x = 0.02;

    tree_list.color.a = 1.0;
    tree_list.color.r = 0;
    tree_list.color.g = 0;
    tree_list.color.b = 0;

    tree_list.pose.orientation.w = 1.0;
    tree_list.pose.orientation.x = 0.0;
    tree_list.pose.orientation.y = 0.0;
    tree_list.pose.orientation.z = 0.0;

    geometry_msgs::Point point;
    for (const auto &i: searched_tree) {
        point.x = i.x();
        point.y = i.y();
        point.z = 0.0;
        tree_list.points.emplace_back(point);

        point.x = i.z();
        point.y = i.w();
        point.z = 0.0;
        tree_list.points.emplace_back(point);
    }

    searched_tree_pub_.publish(tree_list);
}


void HybridAStarFlow::reGoalcallback(const planning_msgs::ObstacleList::ConstPtr& long_obstacleList)
{
    cout<<"进入重规划模式！！"<<endl;
    car_state = replanning;
    pcl::PointCloud<pcl::PointXYZI>::Ptr newObstacle_to_map(new pcl::PointCloud<pcl::PointXYZI>);
    for (size_t i = 0; i < long_obstacleList->obstacles.size(); i++)
    {
      pcl::PointXYZI point_left_up;
      pcl::PointXYZI point_right_up;
      pcl::PointXYZI point_left_down;
      pcl::PointXYZI point_right_down;
      point_left_up.x = long_obstacleList->obstacles[i].bounding_boxs[0].x; //收集每个障碍物的四个角点
      point_left_up.y = long_obstacleList->obstacles[i].bounding_boxs[0].y;
      point_right_up.x = long_obstacleList->obstacles[i].bounding_boxs[1].x; 
      point_right_up.y = long_obstacleList->obstacles[i].bounding_boxs[1].y;
      point_left_down.x = long_obstacleList->obstacles[i].bounding_boxs[2].x; 
      point_left_down.y = long_obstacleList->obstacles[i].bounding_boxs[2].y;
      point_right_down.x = long_obstacleList->obstacles[i].bounding_boxs[3].x; 
      point_right_down.y = long_obstacleList->obstacles[i].bounding_boxs[3].y;
      insertPoints(point_left_up,point_right_up,0.1,newObstacle_to_map);
      insertPoints(point_right_up,point_right_down,0.1,newObstacle_to_map);
      insertPoints(point_right_down,point_left_down,0.1,newObstacle_to_map);
      insertPoints(point_left_down,point_left_up,0.1,newObstacle_to_map);
    }
    std::vector<std::vector<int>> cartesianData(numGrid_x, std::vector<int>(numGrid_y, 0));
    componentClustering(newObstacle_to_map, cartesianData);
    merge_Clustered(cartesianData);
    pcl::PointXYZI new_goal_point;
    new_goal_point.x = long_obstacleList->goal_point.x;
    new_goal_point.y = long_obstacleList->goal_point.y;
    new_goal_point.z = long_obstacleList->goal_point.theta;
        double start_yaw = car_pose_flow_ptr->theta;
        double goal_yaw = new_goal_point.z;

        Vec4d start_state = Vec4d(
                car_pose_flow_ptr->x,
                car_pose_flow_ptr->y,
                start_yaw,0
        );
        Vec4d goal_state = Vec4d(
                new_goal_point.x,
                new_goal_point.y,
                goal_yaw,0
        );

        if (kinodynamic_astar_searcher_ptr_->Search(start_state, goal_state)) {
            auto path = kinodynamic_astar_searcher_ptr_->GetPath();
            if (path.size()>1)
            {
                path[0].w()=path[1].w();
            }

            sensor_msgs::PointCloud2 ss_local_path;
            pcl::toROSMsg(*kinodynamic_astar_searcher_ptr_->node_points_watch, ss_local_path);
            ss_local_path.header.frame_id = "velodyne";
            line_pub_local_path.publish(ss_local_path);
            kinodynamic_astar_searcher_ptr_->node_points_watch.reset(new pcl::PointCloud<pcl::PointXYZI>);
            // std::cout<<"path_size:"<< path.size()<<std::endl;
            next_plan=NextPlan(path);
            path_end_x=path.back().x();
            path_end_y=path.back().y();
            pub_path=path;
            path_type++;
            
            PublishPathToControl(path);
            PublishPath(path);  //发送PATH数据
            PublishVehiclePath(path, 2.0, 1.0, 5u);    //路线显示大小
            PublishSearchedTree(kinodynamic_astar_searcher_ptr_->GetSearchedTree());  //显示搜索树

            nav_msgs::Path path_ros;
            geometry_msgs::PoseStamped pose_stamped;

            for (const auto &pose: path) {
                pose_stamped.header.frame_id = "velodyne";
                pose_stamped.pose.position.x = pose.x();
                pose_stamped.pose.position.y = pose.y();
                pose_stamped.pose.position.z = 0.0;

                pose_stamped.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, 0, pose.z());    //这里的z可能是航向角

                path_ros.poses.emplace_back(pose_stamped);
            }

            path_ros.header.frame_id = "velodyne";
            path_ros.header.stamp = ros::Time::now();
            static tf::TransformBroadcaster transform_broadcaster;
            // for (const auto &pose: path_ros.poses) {
            //     std::cout<<"pose_size:"<<path_ros.poses.size()<<std::endl;
            //     tf::Transform transform;
            //     transform.setOrigin(tf::Vector3(pose.pose.position.x, pose.pose.position.y, 0.0));

            //     tf::Quaternion q;
            //     q.setX(pose.pose.orientation.x);
            //     q.setY(pose.pose.orientation.y);
            //     q.setZ(pose.pose.orientation.z);
            //     q.setW(pose.pose.orientation.w);
            //     transform.setRotation(q);

            //     transform_broadcaster.sendTransform(tf::StampedTransform(transform,
            //                                                              ros::Time::now(), "world",
            //                                                              "ground_link")
            //     );
            //     std::cout<<"sleep_start"<<std::endl;
            //     ros::Duration(0.05).sleep();
            //     std::cout<<"sleep_endl"<<std::endl;
            // }
        }
        kinodynamic_astar_searcher_ptr_->SetNormal();
        // debug
//        std::cout << "visited nodes: " << kinodynamic_astar_searcher_ptr_->GetVisitedNodesNumber() << std::endl;
        kinodynamic_astar_searcher_ptr_->Reset();

    car_state = normal;
}


void HybridAStarFlow::environment_modeling()
{ 
  cout <<"地图初始化"<<endl;

    char current_absolute_path[100000];
    if (NULL == realpath("./", current_absolute_path))
    {
        printf("***Error***\n");
        exit(-1);
    }
    strcat(current_absolute_path, "/");
    printf("current absolute path:%s\n", current_absolute_path);
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    std::string ugv_path = ros::package::getPath("ugv_position");

    std::string yaml_path1 =ugv_path+"/config.yaml";
    YAML::Node config_path = YAML::LoadFile(yaml_path1);
        //加载地图
    std::string pcd_astar_path = ugv_path+"/"+config_path["ASTAR_PCD_PATH"].as<std::string>();

    pcl::io::loadPCDFile(pcd_astar_path, *map_Astar);
    float min_x = std::numeric_limits<float>::max();
    float min_y = std::numeric_limits<float>::max();
    float max_x = -std::numeric_limits<float>::max();
    float max_y = -std::numeric_limits<float>::max();

    for(int i=0; i<map_Astar->points.size(); i++)//i小于地图点云数量进行循环
    {
         if(map_Astar->points[i].x<min_x)//遍历出地图上点的最小x坐标
         {
            min_x=map_Astar->points[i].x;
         }
           if(map_Astar->points[i].y<min_y)//遍历出地图上点的最小y坐标
         {
            min_y=map_Astar->points[i].y;
         }
         if(map_Astar->points[i].x>max_x)//遍历出地图上点的最大x坐标
         {
           max_x=map_Astar->points[i].x;
         }
           if(map_Astar->points[i].y>max_y)//遍历出地图上点的最大y坐标
         {
           max_y=map_Astar->points[i].y;
         }
    }
    cout <<"map_range_min_x map_range_min_x map_range_min_x map_range_min_x:"
         <<min_x<<" "<<min_y<<" "<<max_x<<" "<<max_y<<endl;

     kinodynamic_astar_searcher_ptr_->Init(    
                min_x,
                max_x-min_x,
                min_y,
                max_y-min_y,
                1.0, grid_size    //这里状态采样为1.0有疑问
        );
    min_x_map = min_x/grid_size;
    min_y_map = min_y/grid_size;
    max_x_map = max_x/grid_size;
    max_y_map = max_y/grid_size;
  
    numGrid_x = max_x_map - min_x_map;
    numGrid_y = max_y_map - min_y_map;
    cout<<"numGrid_x:"<<numGrid_x<<" "<<"numGrid_y:"<<numGrid_y<<endl;
    
    std::vector<std::vector<int>> cartesianData(numGrid_x, std::vector<int>(numGrid_y, 0));
    componentClustering(map_Astar, cartesianData);
    

    for (unsigned int r = 0; r < numGrid_x; ++r) {
        for (unsigned int c = 0; c < numGrid_y; ++c) {
            if (cartesianData[r][c]) { 
                kinodynamic_astar_searcher_ptr_->SetObstacle(r, c);
            }

        }
    }

    // expansion_Clustered(cartesianData);
    makeClusteredCloud(cartesianData,clusterCloud);

    printf("obj_list_map is completed\n");  
    
     
}

void HybridAStarFlow::componentClustering(pcl::PointCloud<pcl::PointXYZI>::Ptr elevatedCloud,std::vector<std::vector<int>> &cartesianData)
{

    std::vector<std::vector<int>> gridNum(numGrid_x, std::vector<int>(numGrid_y, 0));
    // elevatedCloud 映射到笛卡尔坐标系 //并 统计落在这个grid的有多少个点！！！
    for(int i = 0; i < elevatedCloud->size(); i++){  // 遍历高点数
        float x = elevatedCloud->points[i].x;   // x(-15, -5),y(-50, 50)
        float y = elevatedCloud->points[i].y;
        float xC = x-min_x_map*grid_size;   // float roiM = 50;(0~50)
        float yC = y-min_y_map*grid_size; // (0~50)
        // exclude outside roi points  排除外部roi points  x,y属于(-25, 25)下面才继续执行
        if(xC < 0 || xC >= numGrid_x*grid_size || yC < 0 || yC >=numGrid_y*grid_size) continue; // continue后，下面不执行。gridNum[xI][yI] 值不变 限制范围（0，50）
        // int xI = floor(xC/grid_size);   //  xI .yI    const int numGrid = 250;    floor(x)返回的是小于或等于x的最大整数
        // int yI = floor(yC/grid_size);   // 50x50 映射到→250x250

        int xI = xC/grid_size;
        int yI = yC/grid_size;
        gridNum[xI][yI] +=  1;  // 统计落在这个grid的有多少个点！！！
    }

    for(int xI = 0; xI < numGrid_x; xI++){  //   const int numGrid = 250; 
        for(int yI = 0; yI < numGrid_y; yI++){
            if(gridNum[xI][yI] >1){  // 一个点的直接舍弃？
                cartesianData[xI][yI] = 1;   // 网格分配有2种初始状态，分别为空（0），已占用（-1）和已分配。随后，将x，y位置的单个单元格选作中心单元格，并且clusterID计数器加1
                // //下面为设置当前点的周围点数值为-1
                //hy_astar不需要膨胀
                // if(xI == 0)
                // {
                //     if(yI == 0)
                //     {
                //         cartesianData[xI+1][yI] = 1;  // 角相邻的3个相邻像元
                //         cartesianData[xI][yI+1] = 1;
                //         cartesianData[xI+1][yI+1] = 1;
                //     }
                //     else if(yI < numGrid_y - 1)
                //     {
                //         cartesianData[xI][yI-1] = 1;  // 边有5个相邻点
                //         cartesianData[xI][yI+1] = 1;
                //         cartesianData[xI+1][yI-1] = 1;
                //         cartesianData[xI+1][yI] = 1;
                //         cartesianData[xI+1][yI+1] = 1;
                //     }
                //     else if(yI == numGrid_y - 1)  // 角相邻的3个相邻像元
                //     {
                //         cartesianData[xI][yI-1] = 1; 
                //         cartesianData[xI+1][yI-1] = 1;
                //         cartesianData[xI+1][yI] = 1;    
                //     }
                // }
                // else if(xI < numGrid_x - 1)
                // {
                //     if(yI == 0)
                //     {
                //         cartesianData[xI-1][yI] = 1;
                //         cartesianData[xI-1][yI+1] = 1;
                //         cartesianData[xI][yI+1] = 1;
                //         cartesianData[xI+1][yI] = 1;
                //         cartesianData[xI+1][yI+1] = 1;                
                //     }
                //     else if(yI < numGrid_y - 1)  // 一般情况四周有8个相邻点
                //     {
                //         cartesianData[xI-1][yI-1] = 1;
                //         cartesianData[xI-1][yI] = 1;
                //         cartesianData[xI-1][yI+1] = 1;
                //         cartesianData[xI][yI-1] = 1;
                //         cartesianData[xI][yI+1] = 1;
                //         cartesianData[xI+1][yI-1] = 1;
                //         cartesianData[xI+1][yI] = 1;
                //         cartesianData[xI+1][yI+1] = 1;                  
                //     }
                //     else if(yI == numGrid_y - 1)
                //     {
                //         cartesianData[xI-1][yI-1] = 1;
                //         cartesianData[xI-1][yI] = 1;
                //         cartesianData[xI][yI-1] = 1;
                //         cartesianData[xI+1][yI-1] = 1;
                //         cartesianData[xI+1][yI] = 1;                 
                //     } 
                // }
                // else if(xI == numGrid_x - 1)
                // {
                //     if(yI == 0)
                //     {
                //         cartesianData[xI-1][yI] = 1;
                //         cartesianData[xI-1][yI+1] = 1;
                //         cartesianData[xI][yI+1] = 1;
                //     }
                //     else if(yI < numGrid_y - 1)
                //     {
                //         cartesianData[xI-1][yI-1] = 1;
                //         cartesianData[xI-1][yI] = 1;
                //         cartesianData[xI-1][yI+1] = 1;
                //         cartesianData[xI][yI-1] = 1;
                //         cartesianData[xI][yI+1] = 1;
                //     }
                //     else if(yI == numGrid_y - 1)
                //     {
                //         cartesianData[xI-1][yI-1] = 1;
                //         cartesianData[xI-1][yI] = 1;
                //         cartesianData[xI][yI-1] = 1;    
                //     }            
                // }

            }      
        }
    }
}

void HybridAStarFlow::merge_Clustered(std::vector<std::vector<int>> &cartesianData) 
{
  int rows = cartesianData.size();
    if (rows == 0) return;
    int cols = cartesianData[0].size();
    // 创建一个与原网格大小相同的结果网格，并初始化为0
    std::vector<std::vector<int>> result(rows, std::vector<int>(cols, 0));
    for (unsigned int r = 0; r < rows; ++r) {
        for (unsigned int c = 0; c < cols; ++c) {
            if (cartesianData[r][c]) { // 两个网络都没障碍物
                kinodynamic_astar_searcher_ptr_->SetObstacle_without_normal(r, c);
            }

        }
    }
    // 将结果复制回原网格
}

void HybridAStarFlow::makeClusteredCloud(std::vector<std::vector<int>> &cartesianData,
                        pcl::PointCloud<pcl::PointXYZI>::Ptr& clusterCloud){
    int rows = cartesianData.size();
    if (rows == 0) return;
    int cols = cartesianData[0].size();
     for (int xI = 0; xI < rows; ++xI) {
        for (int yI = 0; yI < cols; ++yI) {
            if (cartesianData[xI][yI])
            {
              pcl::PointXYZI o;
              o.x = grid_size*xI + min_x_map*grid_size ;  // 网格大小？？ roiM = 50  grid_size = (0.200000003F)
              o.y = grid_size*yI + min_y_map*grid_size ; // 转换成（-25  ~  25）范围
              o.z = -1;  // 高度统一设置为-1
              clusterCloud->push_back(o); // 
            }
            
        }
     }
}

void HybridAStarFlow::insertPoints(const pcl::PointXYZI& start, const pcl::PointXYZI& end, float step, pcl::PointCloud<pcl::PointXYZI>::Ptr& points) {
    float distance = std::sqrt(std::pow(end.x - start.x, 2) + std::pow(end.y - start.y, 2));
    int numSteps = static_cast<int>(distance / step);
    
    for (int i = 0; i <= numSteps; ++i) {
        pcl::PointXYZI point;
        point.x = start.x + (end.x - start.x) * (i / static_cast<float>(numSteps));
        point.y = start.y + (end.y - start.y) * (i / static_cast<float>(numSteps));
        points->push_back(point);
    }
}