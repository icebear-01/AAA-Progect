#ifndef __PLAY_PATH_H
#define __PLAY_PATH_H
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "yaml-cpp/yaml.h"
#include <pthread.h>
#include <limits.h>
#include <cfloat>
#include <ros/ros.h>
#include <message_filters/subscriber.h>
#include <sensor_msgs/PointCloud2.h>
#include <vector>
#include <cmath>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <geometry_msgs/Pose2D.h>
#include <fstream>
#include <sstream>

using namespace std;
class TrajectoryRecorder_pub {
public:
    fstream& file_;
    ros::Publisher  line_pub;
    void read_path();
    TrajectoryRecorder_pub(fstream& file,ros::NodeHandle &nh);
    ~TrajectoryRecorder_pub();
};


extern pcl::PointCloud<pcl::PointXYZI>::Ptr line_record(new pcl::PointCloud<pcl::PointXYZI>);

const std::string FILE_NAME = "trajectory.txt";  //文件名称
// struct point_path
// {
//     float x,y,z;
// };

#endif