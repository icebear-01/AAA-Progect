/**
 * @FilePath     : /Play_RecordPath/include/play_path.cpp
 * @Description  :  
 * @Author       : WMD
 * @Version      : 0.0.1
 * @LastEditors  : WMD email:732485622@qq.com
 * @LastEditTime : 2023-11-30 19:59:21
 * @Copyright    : G AUTOMOBILE RESEARCH INSTITUTE CO.,LTD Copyright (c) 2023.
**/
#include "play_path.hpp"
#include <fstream>
using namespace std;

TrajectoryRecorder_pub::TrajectoryRecorder_pub(std::fstream& file,ros::NodeHandle &nh) : file_(file)
{
    read_path();
     
    TrajectoryRecorder_pub::line_pub = nh.advertise<sensor_msgs::PointCloud2> ("line_Path_tra", 100); 
    ros::spin();
}

TrajectoryRecorder_pub::~TrajectoryRecorder_pub()
{
    if (file_.is_open()) {
        file_.close();
    }
}

void TrajectoryRecorder_pub::read_path()
{
    string line;
    while (getline(this->file_, line))
    {
        pcl::PointXYZI points;
        std::istringstream iss(line);
        if (!(iss >> points.x >> points.y))
        {
            std::cout << "Error reading line: " << line << std::endl;
            continue;
        }
        line_record->points.push_back(points);
    }
    sensor_msgs::PointCloud2 line_record_pub;
    pcl::toROSMsg(*line_record, line_record_pub);
    line_record_pub.header.frame_id = "velodyne";
    line_pub.publish(line_record_pub);
    cout<<"Successfully load path!"<<endl;

}