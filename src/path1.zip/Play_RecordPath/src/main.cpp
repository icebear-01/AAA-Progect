/**
 * @FilePath     : /Play_RecordPath/src/main.cpp
 * @Description  :  
 * @Author       : WMD
 * @Version      : 0.0.1
 * @LastEditors  : WMD email:732485622@qq.com
 * @LastEditTime : 2023-11-30 19:47:58
 * @Copyright    : G AUTOMOBILE RESEARCH INSTITUTE CO.,LTD Copyright (c) 2023.
**/
#include "play_path.cpp"

using namespace std;

int main(int argc, char* argv[]) 
{
    ros::init(argc, argv, "play_recordPath");
    ros::NodeHandle nh;
    fstream file(FILE_NAME.c_str());
    TrajectoryRecorder_pub trajectoryRecorder_pub(file,nh);

    return 0;
}