#ifndef __RECORD_PATH_HPP
#define __RECORD_PATH_HPP
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "yaml-cpp/yaml.h"
#include <pthread.h>
#include <cfloat>
#include <ros/ros.h>
#include <message_filters/subscriber.h>
#include <sensor_msgs/PointCloud2.h>
#include <vector>
#include <cmath>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <geometry_msgs/Pose2D.h>
#include <fstream>
#include <sstream>

const std::string FILE_NAME = "trajectory.txt";  //文件名称
// fstream file(FILE_NAME.c_str());

class TrajectoryRecorder {
public:
    
    std::fstream& file_;
    ros::Publisher  line_pub;
    ros::Subscriber sub_pos;
    void callBack_Pos(const geometry_msgs::Pose2D::ConstPtr &car_pose);
    TrajectoryRecorder(std::fstream& file,ros::NodeHandle &nh);
    ~TrajectoryRecorder();
};


// struct point_path
// {
//     float x,y,z;
// };


#endif