/**
 * @FilePath     : /Record_Path/src/record_path.cpp
 * @Description  :  
 * @Author       : WMD
 * @Version      : 0.0.1
 * @LastEditors  : WMD email:732485622@qq.com
 * @LastEditTime : 2023-11-30 18:40:03
 * @Copyright    : G AUTOMOBILE RESEARCH INSTITUTE CO.,LTD Copyright (c) 2023.
**/
#include "record_path.hpp"
#include <fstream>
using namespace std;

TrajectoryRecorder::TrajectoryRecorder(std::fstream& file,ros::NodeHandle &nh) : file_(file)
{
    TrajectoryRecorder::sub_pos = nh.subscribe<geometry_msgs::Pose2D>("/car_pos", 100, &TrajectoryRecorder::callBack_Pos, this); 
    // TrajectoryRecorder::line_pub = nh.publisher<geometry_msgs::Pose2D>("/car_pos", 100, &pureNode::callBack2, this); // 订阅车位置姿态
    ros::spin();
}

void TrajectoryRecorder::callBack_Pos(const geometry_msgs::Pose2D::ConstPtr &car_pose)
{
    this->file_<<car_pose->x<<" "<<car_pose->y<<std::endl;
}

TrajectoryRecorder::~TrajectoryRecorder()
{
    if (file_.is_open()) {
        file_.close();
    }
}
