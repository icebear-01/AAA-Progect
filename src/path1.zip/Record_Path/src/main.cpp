/**
 * @FilePath     : /Record_Path/src/main.cpp
 * @Description  :  
 * @Author       : WMD
 * @Version      : 0.0.1
 * @LastEditors  : WMD email:732485622@qq.com
 * @LastEditTime : 2023-11-30 18:59:38
 * @Copyright    : G AUTOMOBILE RESEARCH INSTITUTE CO.,LTD Copyright (c) 2023.
**/
#include "record_path.hpp"

using namespace std;

int main(int argc, char* argv[]) 
{
    ros::init(argc, argv, "record_Path");
    ros::NodeHandle nh;
    fstream file(FILE_NAME.c_str());
    TrajectoryRecorder TrajectoryRecorder(file,nh);
    // std::vector<double> x_values;
    // std::vector<double> y_values;
    // std::vector<point_path> p_path;
    // float z=0;
    // ifstream file_read("trajectory.txt");
    // string line;
    // while (getline(file_read, line))
    // {
    //     std::istringstream iss(line);
    //     float x, y, z;
    //     if (!(iss >> x >> y >> z))
    //     {
    //         std::cout << "Error reading line: " << line << std::endl;
    //         continue;
    //     }
    //     p_path.push_back({x, y, z});
    // }
    // for(auto it=p_path.begin();it!=p_path.end();it++)
    // {
    //     cout<<" x:"<<it->x<<" y:"<<it->y<<" z:"<<it->z<<endl;
    // }

    // file_read.close();
    return 0;
}