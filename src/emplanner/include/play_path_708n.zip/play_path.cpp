/**
 * @FilePath     : /Play_RecordPath/include/play_path.cpp
 * @Description  : 版本0.01：此版本为稳定运行路径规划的画图版本，添加了matplotlib cpp画图库，稳定运行路径规划，实现SL动态图
 *                 版本0.02：添加了起始点的优化，现在的起点及车辆路径更加稳定
 *                 版本0.03：修复了dp_path和qp_path的终点不一致的Bug，优化了部分程序
 *                 版本0.04：添加了速度规划的DP，QP速度规划算法，及matplotlib cpp 的ST动态图
 *                 版本0.05：修复了速度规划中DP规划的重大bug，DP_speed正常运行，但是，QP_speed存在问题
 *                 版本0.06：修复了QP_speed中躲避障碍物错误问题，较好的运行路径规划的流程
 *                 版本0.07：修复了ST图中起点无解问题，优化了碰瓷问题的解决
 *                 版本0.08：稳定运行版本，粗略完成决策与规划功能
 *                 版本0.09：针对小车的版本，修改针对小车的参数，考虑障碍物的尺寸与道路边界限制
 * @Author       : WMD
 * @Version      : 0.0.9
 * @LastEditors  : 
 * @LastEditTime : 2024-6-28 22:53:20
 * 
 * @Copyright    : G AUTOMOBILE RESEARCH INSTITUTE CO.,LTD Copyright (c) 2023.
 **/
#include <play_path.hpp>
#include <fstream>
using namespace std;
// namespace plt = matplotlibcpp;

TrajectoryRecorder_pub::TrajectoryRecorder_pub(std::fstream &file, ros::NodeHandle &nh) : file_(file)
{

    ros::Rate loop_rate(10);
    TrajectoryRecorder_pub::line_pub = nh.advertise<sensor_msgs::PointCloud2>("line_Path_tra", 100);

    TrajectoryRecorder_pub::line_pub_watch = nh.advertise<sensor_msgs::PointCloud2>("watch_line_Path_tra", 100);
    TrajectoryRecorder_pub::line_pub_local_path = nh.advertise<sensor_msgs::PointCloud2>("local_Path", 100);
    TrajectoryRecorder_pub::line_pub_local_qp_path = nh.advertise<planning_msgs::car_path>("QP_Path", 100);
    TrajectoryRecorder_pub::line_pub_path = nh.advertise<planning_msgs::car_path>("line_Path", 100);
    TrajectoryRecorder_pub::obs_watch_pub = nh.advertise<sensor_msgs::PointCloud2>("obs_watch", 100);

    
    TrajectoryRecorder_pub::line_pub_local_qp_path_watch = nh.advertise<sensor_msgs::PointCloud2>("local_qp_Path", 100);
    TrajectoryRecorder_pub::sub_obstacle_list_lidar = nh.subscribe<planning_msgs::ObstacleList>("/obstacleList_lidar", 100, &TrajectoryRecorder_pub::callBack_obstacleList_lidar, this); // 订阅车位置姿态
    TrajectoryRecorder_pub::sub_obstacle_list_vision = nh.subscribe<obj_msgs::ObstacleList>("/object_detection_local", 100, &TrajectoryRecorder_pub::callBack_obstacle_vision_List, this); // 订阅车位置姿态
    TrajectoryRecorder_pub::sub_location = nh.subscribe<planning_msgs::car_info>("/car_pos", 100, &TrajectoryRecorder_pub::callBack_location, this);        // 订阅车位置姿态
    TrajectoryRecorder_pub::sub_car_info = nh.subscribe<planning_msgs::car_info>("/car_info", 100, &TrajectoryRecorder_pub::callBack_carInfo, this);
    TrajectoryRecorder_pub::sub_car_stop = nh.subscribe<std_msgs::Float32>("/car_stop", 100, &TrajectoryRecorder_pub::callBack_car_stop, this);
    // while (ros::ok())
    // {
    //     loop_rate.sleep(); // 控制发布频率
    // }
    ros::spin();
}


TrajectoryRecorder_pub::~TrajectoryRecorder_pub()
{
    if (file_.is_open())
    {
        file_.close();
    }
}
void TrajectoryRecorder_pub::callBack_car_stop(const std_msgs::Float32::ConstPtr& flag_car_stop)
{
    flagCarStop=flag_car_stop->data;
}

void TrajectoryRecorder_pub::callBack_obstacleList_lidar(const planning_msgs::ObstacleList::ConstPtr &Obstacle_list_lidar) //车速赋值回调
{
    obstacle_list_lidar.reset(new planning_msgs::ObstacleList);
    *obstacle_list_lidar=*Obstacle_list_lidar;
}


void TrajectoryRecorder_pub::callBack_carInfo(const planning_msgs::car_info::ConstPtr &car_info) //车速赋值回调
{
    real_vehicle_speed=car_info->speed;
}
void TrajectoryRecorder_pub::callBack_location(const planning_msgs::car_info::ConstPtr &car_pose)//NDT定位回调
{
    // Car_Pose.reset(new geometry_msgs::Pose2D());
    Car_Pose->x = ((car_pose->x) + L * cos(car_pose->yaw)); // 纠正为后车身XY坐标
    Car_Pose->y = ((car_pose->y) + L * sin(car_pose->yaw)); // 纠正为后车身XY坐标
    Car_Pose->theta = car_pose->yaw;
    Car_Pose_middle->x = car_pose->x;
    Car_Pose_middle->y = car_pose->y;
    Car_Pose_middle->theta = car_pose->yaw;
    Car_Pose_back->x = ((car_pose->x) - L * cos(car_pose->yaw)); // 纠正为后车身XY坐标
    Car_Pose_back->y = ((car_pose->y) - L * sin(car_pose->yaw)); // 纠正为后车身XY坐标
    Car_Pose_back->theta = car_pose->yaw;
    read_path();
    obstacle_list_qp_path_sl.reset(new planning_msgs::ObstacleList);
    obstacle_list.reset(new planning_msgs::ObstacleList);
    
    car_pos_is_arrive = true;
}

void TrajectoryRecorder_pub::callBack_obstacle_vision_List(const obj_msgs::ObstacleList::ConstPtr &Obstacle_list_vision) //视觉回调
{
    obstacle_list_vision.reset(new planning_msgs::ObstacleList);
    for (int i = 0; i < Obstacle_list_vision->obstacles.size(); i++)
    {
        planning_msgs::Obstacle obs_vision;
        for (int j = 0; j < obstacle_list_vision->obstacles[i].bounding_boxs.size(); j++)
        {
            obs_vision.bounding_boxs[j].x =Obstacle_list_vision->obstacles[i].bounding_boxs[j].x;
            obs_vision.bounding_boxs[j].y =Obstacle_list_vision->obstacles[i].bounding_boxs[j].y;
        }
        
        obs_vision.x_vel =Obstacle_list_vision->obstacles[i].vel.x;

        obs_vision.y_vel =Obstacle_list_vision->obstacles[i].vel.y;
        obstacle_list_vision->obstacles.push_back(obs_vision);
    }
}


/**
 * @description: 障碍物参数计算
 * @param {Ptr} &Obstacle_list
 * @return {*}
 */
void Obstacle_list_Initialization(planning_msgs::ObstacleList::Ptr &Obstacle_list) 
{
    for (int i = 0; i < Obstacle_list->obstacles.size(); i++)
    {
        Obstacle_list->obstacles[i].is_dynamic_obs=false;
        float max_s;
        float min_s;
        float max_l;
        float min_l;

        vector<float> s_temp;
        vector<float> l_temp;

        // Eigen::Vector2d obstacle_point_center(Obstacle_list->obstacles[i].x, Obstacle_list->obstacles[i].y);
        Eigen::Vector2d obstacle_point_point1(Obstacle_list->obstacles[i].max_x, Obstacle_list->obstacles[i].max_y);
        Eigen::Vector2d obstacle_point_point2(Obstacle_list->obstacles[i].max_x, Obstacle_list->obstacles[i].min_y);
        Eigen::Vector2d obstacle_point_point3(Obstacle_list->obstacles[i].min_x, Obstacle_list->obstacles[i].max_y);
        Eigen::Vector2d obstacle_point_point4(Obstacle_list->obstacles[i].min_x, Obstacle_list->obstacles[i].min_y);

        Eigen::Vector2d obstacle_point_point1_sl = calc_obstacle_sl(obstacle_point_point1); // 上下左右障碍物四个角点计算
        Eigen::Vector2d obstacle_point_point2_sl = calc_obstacle_sl(obstacle_point_point2);
        // Eigen::Vector2d obstacle_point_center_sl=calc_obstacle_sl(obstacle_point_center);//障碍物中心点计算
        Eigen::Vector2d obstacle_point_point3_sl = calc_obstacle_sl(obstacle_point_point3);
        Eigen::Vector2d obstacle_point_point4_sl = calc_obstacle_sl(obstacle_point_point4);

        s_temp.push_back(obstacle_point_point1_sl(0));
        s_temp.push_back(obstacle_point_point2_sl(0));
        s_temp.push_back(obstacle_point_point3_sl(0));
        s_temp.push_back(obstacle_point_point4_sl(0));

        l_temp.push_back(obstacle_point_point1_sl(1));
        l_temp.push_back(obstacle_point_point2_sl(1));
        l_temp.push_back(obstacle_point_point3_sl(1));
        l_temp.push_back(obstacle_point_point4_sl(1));

        auto s_point_min = std::min_element(s_temp.begin(), s_temp.end());
        auto s_point_max = std::max_element(s_temp.begin(), s_temp.end());
        auto l_point_min = std::min_element(l_temp.begin(), l_temp.end());
        auto l_point_max = std::max_element(l_temp.begin(), l_temp.end());

        Obstacle_list->obstacles[i].min_s = *s_point_min;
        Obstacle_list->obstacles[i].max_s = *s_point_max;
        Obstacle_list->obstacles[i].min_l = *l_point_min;
        Obstacle_list->obstacles[i].max_l = *l_point_max;
        Obstacle_list->obstacles[i].s = (*s_point_min + *s_point_max) / 2;
        Obstacle_list->obstacles[i].l = (*l_point_min + *l_point_max) / 2;
        // if (abs(Obstacle_list->obstacles[i].l) < 1.5)
        // {
        //     cout << i << " 个障碍物 l<1.5; l:" << Obstacle_list->obstacles[i].l << "!!!!!!!!!!" << endl;
        // }

        // Obstacle_list->obstacles[i].max_length = sqrt(pow(Obstacle_list->obstacles[i].max_x - Obstacle_list->obstacles[i].min_x, 2) + pow(Obstacle_list->obstacles[i].max_y - Obstacle_list->obstacles[i].min_y, 2));
    }
}


/**
 * @description: 障碍物参数计算
 * @param {Ptr} &Obstacle_list
 * @return {*}
 */
void Obstacle_list_Initialization_vision(planning_msgs::ObstacleList::Ptr &Obstacle_list)
{
    for (int i = 0; i < Obstacle_list->obstacles.size(); i++)
    {
        Obstacle_list->obstacles[i].is_consider=true;
        if(sqrt(pow(Obstacle_list->obstacles[i].x_vel,2)+pow(Obstacle_list->obstacles[i].y_vel,2))>dynamic_vel_threshold)
            Obstacle_list->obstacles[i].is_dynamic_obs=true;
        else
            Obstacle_list->obstacles[i].is_dynamic_obs=false;
        float max_s;
        float min_s;
        float max_l;
        float min_l;
        float middle_x,middle_y;

        vector<float> s_temp;
        vector<float> l_temp;

        // Eigen::Vector2d obstacle_point_center(Obstacle_list->obstacles[i].x, Obstacle_list->obstacles[i].y);
        Eigen::Vector2d obstacle_point_point1(Obstacle_list->obstacles[i].bounding_boxs[0].x, Obstacle_list->obstacles[i].bounding_boxs[0].y);
        Eigen::Vector2d obstacle_point_point2(Obstacle_list->obstacles[i].bounding_boxs[1].x, Obstacle_list->obstacles[i].bounding_boxs[1].y);
        Eigen::Vector2d obstacle_point_point3(Obstacle_list->obstacles[i].bounding_boxs[2].x, Obstacle_list->obstacles[i].bounding_boxs[2].y);
        Eigen::Vector2d obstacle_point_point4(Obstacle_list->obstacles[i].bounding_boxs[3].x, Obstacle_list->obstacles[i].bounding_boxs[3].y);
        middle_x=(Obstacle_list->obstacles[i].bounding_boxs[0].x+Obstacle_list->obstacles[i].bounding_boxs[1].x+Obstacle_list->obstacles[i].bounding_boxs[2].x+Obstacle_list->obstacles[i].bounding_boxs[3].x)/4;
        middle_y=(Obstacle_list->obstacles[i].bounding_boxs[0].y+Obstacle_list->obstacles[i].bounding_boxs[1].y+Obstacle_list->obstacles[i].bounding_boxs[2].y+Obstacle_list->obstacles[i].bounding_boxs[3].y)/4;
        
        Eigen::Vector2d obstacle_point_point1_sl = calc_obstacle_sl(obstacle_point_point1); // 上下左右障碍物四个角点计算
        Eigen::Vector2d obstacle_point_point2_sl = calc_obstacle_sl(obstacle_point_point2);
        // Eigen::Vector2d obstacle_point_center_sl=calc_obstacle_sl(obstacle_point_center);//障碍物中心点计算
        Eigen::Vector2d obstacle_point_point3_sl = calc_obstacle_sl(obstacle_point_point3);
        Eigen::Vector2d obstacle_point_point4_sl = calc_obstacle_sl(obstacle_point_point4);
        
        s_temp.push_back(obstacle_point_point1_sl(0));
        s_temp.push_back(obstacle_point_point2_sl(0));
        s_temp.push_back(obstacle_point_point3_sl(0));
        s_temp.push_back(obstacle_point_point4_sl(0));

        l_temp.push_back(obstacle_point_point1_sl(1));
        l_temp.push_back(obstacle_point_point2_sl(1));
        l_temp.push_back(obstacle_point_point3_sl(1));
        l_temp.push_back(obstacle_point_point4_sl(1));

        auto s_point_min = std::min_element(s_temp.begin(), s_temp.end());
        auto s_point_max = std::max_element(s_temp.begin(), s_temp.end());
        auto l_point_min = std::min_element(l_temp.begin(), l_temp.end());
        auto l_point_max = std::max_element(l_temp.begin(), l_temp.end());

        Obstacle_list->obstacles[i].x = middle_x;
        Obstacle_list->obstacles[i].y = middle_y;
        Obstacle_list->obstacles[i].min_s = *s_point_min;
        Obstacle_list->obstacles[i].max_s = *s_point_max;
        Obstacle_list->obstacles[i].min_l = *l_point_min;
        Obstacle_list->obstacles[i].max_l = *l_point_max;
        Obstacle_list->obstacles[i].s = (*s_point_min + *s_point_max) / 2;
        Obstacle_list->obstacles[i].l = (*l_point_min + *l_point_max) / 2;
        Obstacle_list->obstacles[i].max_length=abs(Obstacle_list->obstacles[i].max_l-Obstacle_list->obstacles[i].min_l);
        // cout<<"obs "<<i<<":"<<Obstacle_list->obstacles[i].s<<","<<Obstacle_list->obstacles[i].l<<","<<Obstacle_list->obstacles[i].x_vel<<endl;

        // Obstacle_list->obstacles[i].x_vel=Obstacle_list->obstacles[i].x_vel+real_vehicle_speed;
        Obstacle_list->obstacles[i].x_vel=Obstacle_list->obstacles[i].x_vel;
    }
}


/**
 * @description: 针对qp_path_路线计算各个障碍物的SL
 * @param {Ptr} &Obstacle_list
 * @return {*}
 */
void Obstacle_list_Initialization_qp_path(planning_msgs::ObstacleList::Ptr &Obstacle_list,Eigen::Vector2d planning_frist_star)
{
    for (int i = 0; i < Obstacle_list->obstacles.size(); i++)
    {
        float max_s,min_s,max_l,min_l;
        float middle_x,middle_y;

        vector<float> s_temp;
        vector<float> l_temp;

        // Eigen::Vector2d obstacle_point_center(Obstacle_list->obstacles[i].x, Obstacle_list->obstacles[i].y);
        Eigen::Vector2d obstacle_point_point1(Obstacle_list->obstacles[i].bounding_boxs[0].x, Obstacle_list->obstacles[i].bounding_boxs[0].y);
        Eigen::Vector2d obstacle_point_point2(Obstacle_list->obstacles[i].bounding_boxs[1].x, Obstacle_list->obstacles[i].bounding_boxs[1].y);
        Eigen::Vector2d obstacle_point_point3(Obstacle_list->obstacles[i].bounding_boxs[2].x, Obstacle_list->obstacles[i].bounding_boxs[2].y);
        Eigen::Vector2d obstacle_point_point4(Obstacle_list->obstacles[i].bounding_boxs[3].x, Obstacle_list->obstacles[i].bounding_boxs[3].y);
        middle_x=(Obstacle_list->obstacles[i].bounding_boxs[0].x+Obstacle_list->obstacles[i].bounding_boxs[1].x+Obstacle_list->obstacles[i].bounding_boxs[2].x+Obstacle_list->obstacles[i].bounding_boxs[3].x)/4;
        middle_y=(Obstacle_list->obstacles[i].bounding_boxs[0].y+Obstacle_list->obstacles[i].bounding_boxs[1].y+Obstacle_list->obstacles[i].bounding_boxs[2].y+Obstacle_list->obstacles[i].bounding_boxs[3].y)/4;

        Eigen::Vector2d obstacle_point_point1_sl = calc_obstacle_sl(obstacle_point_point1,QP_path,planning_frist_star); // 上下左右障碍物四个角点计算
        Eigen::Vector2d obstacle_point_point2_sl = calc_obstacle_sl(obstacle_point_point2,QP_path,planning_frist_star);  //sl为qp坐标系的sl
        // Eigen::Vector2d obstacle_point_center_sl=calc_obstacle_sl(obstacle_point_center);//障碍物中心点计算
        Eigen::Vector2d obstacle_point_point3_sl = calc_obstacle_sl(obstacle_point_point3,QP_path,planning_frist_star);
        Eigen::Vector2d obstacle_point_point4_sl = calc_obstacle_sl(obstacle_point_point4,QP_path,planning_frist_star);
        // cout<<"sl1:"<<obstacle_point_point1_sl(0)<<","<<obstacle_point_point1_sl(1)<<endl;

        int index_match_middle_points = get_closest_point(middle_x, middle_y, *QP_path);
        Eigen::Vector2d d(QP_path->points[index_match_middle_points].tor.x,QP_path->points[index_match_middle_points].tor.y);  //路径方向
        Eigen::Vector2d v(Obstacle_list->obstacles[i].x_vel,Obstacle_list->obstacles[i].y_vel); //速度
        double s_dot = d.dot(v);  //s_vel


        Eigen::Vector2d v_tor=s_dot*d;
        Eigen::Vector2d v_nor=v-v_tor;
        double l_dot=v_nor.norm();  //l_vel
        double cross_sign = d.x() * v.y() - d.y() * v.x(); // 这是二维向量叉积的计算方式
        if (cross_sign < 0)
        {
            l_dot=-l_dot;
        }

        Obstacle_list->obstacles[i].s_vel=s_dot;  //障碍物sl的速度赋值
        Obstacle_list->obstacles[i].l_vel=l_dot;  

        s_temp.push_back(obstacle_point_point1_sl(0));
        s_temp.push_back(obstacle_point_point2_sl(0));
        s_temp.push_back(obstacle_point_point3_sl(0));
        s_temp.push_back(obstacle_point_point4_sl(0));

        l_temp.push_back(obstacle_point_point1_sl(1));
        l_temp.push_back(obstacle_point_point2_sl(1));
        l_temp.push_back(obstacle_point_point3_sl(1));
        l_temp.push_back(obstacle_point_point4_sl(1));

        auto s_point_min = std::min_element(s_temp.begin(), s_temp.end());
        auto s_point_max = std::max_element(s_temp.begin(), s_temp.end());
        auto l_point_min = std::min_element(l_temp.begin(), l_temp.end());
        auto l_point_max = std::max_element(l_temp.begin(), l_temp.end());

        Obstacle_list->obstacles[i].min_s = *s_point_min-lidarToCarHead;
        Obstacle_list->obstacles[i].max_s = *s_point_max-lidarToCarHead;
        Obstacle_list->obstacles[i].min_l = *l_point_min-lidarToCarHead;
        Obstacle_list->obstacles[i].max_l = *l_point_max-lidarToCarHead;
        Obstacle_list->obstacles[i].s = (*s_point_min + *s_point_max) / 2-lidarToCarHead;
        Obstacle_list->obstacles[i].l = (*l_point_min + *l_point_max) / 2-lidarToCarHead;
        // cout<<"!!!qp_path_sl:"<<Obstacle_list->obstacles[i].s<<","<<Obstacle_list->obstacles[i].l<<endl;
    }
    if(car_direct==1)  //前进
    {
        for (int i = 0; i < Obstacle_list->obstacles.size(); i++)
        {
            if(Obstacle_list->obstacles[i].min_s<safe_distance2close) //障碍物过近
            {
                if(Obstacle_list->obstacles[i].l>=host_forward_sl(1)) //障碍物在车左侧
                {
                    if(Obstacle_list->obstacles[i].min_l<host_forward_sl(1)+0.4)//+车宽
                    {
                        flag_obstacle_too_close=true;
                    }
                    else
                    {
                        flag_obstacle_too_close=false;
                    }

                }
                else //障碍物在车右侧
                {
                    if(Obstacle_list->obstacles[i].max_l>host_forward_sl(1)-0.4)//+车宽
                    {
                        flag_obstacle_too_close=true;
                    }
                    else
                    {
                        flag_obstacle_too_close=false;
                    }

                }

            }
        }
    }
}

Eigen::Vector2d calc_obstacle_sl(Eigen::Vector2d obstacle_point)
{
    Eigen::Vector2d obstacle_sl;
    int index_match_points = get_closest_point(obstacle_point(0), obstacle_point(1), path, index_closest_Car);

    planning_msgs::path_point host_projected_point1 = find_projected_point_Frenet(path, index_match_points, obstacle_point);
    Eigen::Vector2d AB(host_projected_point1.tor.x, host_projected_point1.tor.y);
    Eigen::Vector2d AC(obstacle_point(0) - host_projected_point1.x, obstacle_point(1) - host_projected_point1.y);
    obstacle_sl(0) = host_projected_point1.absolute_s;
    float l = AB.x() * AC.y() - AB.y() * AC.x();

    // float l=sqrt(pow(obstacle_point(0) - host_projected_point1.x, 2) + pow(obstacle_point(1) - host_projected_point1.y, 2));

    obstacle_sl(1) = l;
    return obstacle_sl;
}

Eigen::Vector2d calc_obstacle_sl(Eigen::Vector2d obstacle_point,planning_msgs::car_path::Ptr &path,Eigen::Vector2d planning_frist_star)
{
    Eigen::Vector2d obstacle_sl;
    int index_match_points = get_closest_point(obstacle_point(0), obstacle_point(1), *path);
    planning_msgs::path_point host_projected_point1 = find_projected_point_Frenet(*path, index_match_points, obstacle_point);
    Eigen::Vector2d AB(host_projected_point1.tor.x, host_projected_point1.tor.y);
    Eigen::Vector2d AC(obstacle_point(0) - host_projected_point1.x, obstacle_point(1) - host_projected_point1.y);
    // obstacle_sl(0) = host_projected_point1.absolute_s+planning_frist_star(0);
    obstacle_sl(0) = host_projected_point1.absolute_s;
    float l = AB.x() * AC.y() - AB.y() * AC.x();

    obstacle_sl(1) = l;
    return obstacle_sl;
}

void TrajectoryRecorder_pub::read_path()
{
    string play_path_path = ros::package::getPath("play_path");
    if (flag_is_first_run)
    {
        path.V_turn = V_turn;
        path.V_straight = V_straight;
        string line;
        // 读取txt文件
        while (getline(this->file_, line))
        {
            pcl::PointXYZI points_;
            std::istringstream iss(line);
            if (!(iss >> points_.x >> points_.y >> points_.z >> points_.intensity))
            {
                std::cout << "Error reading line: " << line << std::endl;
                continue;
            }
            points_.z = (float)points_.z;
            points_.x = (float)points_.x;
            points_.y = (float)points_.y;
            points_.intensity = (float)points_.intensity;
            line_record_->push_back(points_);
        }
        total_points_num = line_record_->points.size();
        // 路径优化
        Eigen::VectorXd QPSolution = Smooth_Reference_Line(line_record_);

        // 计算路线航向角(斜率）
        vector<float> temp_phi(total_points_num);
        Calculate_OptimizedPath_Heading(QPSolution, temp_phi);

        // 进行均值插值
        Mean_Interpolation(line_record_opt, line_record);
        // 路径参数计算
        Path_Parameter_Calculate(path);

        // 写入优化后路线点
        std::ofstream outfile_watch(play_path_path + "/text/data_watch.txt");
        // 检查文件是否成功打开
        if (!outfile_watch.is_open())
        {
            std::cerr << "Error: Unable to open the file for writing." << std::endl;
        }

        for (int i = 0; i < path.points.size(); i++)
        {
            outfile_watch << path.points[i].number << " ";
            outfile_watch << path.points[i].x << " ";
            outfile_watch << path.points[i].y << " ";
            outfile_watch << path.points[i].yaw << " ";
            outfile_watch << path.points[i].ds << " ";
            outfile_watch << path.points[i].theta << " ";
            // outfile_watch << path.points[i].flag_turn << " ";
            // outfile_watch << path.points[i].flag_right_turn << " ";
            // outfile_watch << path.points[i].flag_left_turn << " " << endl;
            outfile_watch << path.points[i].kappa << endl;
        }
        // 关闭文件流
        outfile_watch.close();

        // rviz观测数据
        for (int i = 0; i < path.points.size(); i++)
        {
            pcl::PointXYZI points_watch;
            points_watch.x = path.points[i].x;
            points_watch.y = path.points[i].y;
            points_watch.z = 0;
            points_watch.intensity = path.points[i].vel;
            line_record_watch->push_back(points_watch);
            // cout << "number,int,vel,right,left: " << path.number[i - 1] << " " << path.theta[i - 1] << " " << path.vel[i - 1] << " " << path.flag_right_turn[i - 1] << " " << path.flag_left_turn[i - 1] << endl;
        }

        flag_is_first_run = false;
        cout << "Initialization successful!!! ";
        cout << " Path_total_num:" << path.points.size() << endl;

        index_closest_Car = get_closest_point(Car_Pose->x, Car_Pose->y, path);

        // planning_msgs::ObstacleList::Ptr obstacle_list_temp(new planning_msgs::ObstacleList);
        // *obstacle_list_temp=*Obstacle_list;
        // Obstacle_list_Initialization(obstacle_list_temp);
        // for (int i = 0; i < obstacle_list_temp->obstacles.size(); i++)
        // {

        //     if(obstacle_list_temp->obstacles[i].l-obstacle_list_temp->obstacles[i].max_length/2 >5)
        //     {
        //         continue;
        //     }
        //     else
        //     {
        //         obstacle_list->obstacles.push_back(obstacle_list_temp->obstacles[i]);
        //     }
        // }

        // Eigen::Vector2d host_point(Car_Pose->x, Car_Pose->y);
        // planning_msgs::path_point host_projected_point = find_projected_point_Frenet(path, index_closest_Car, host_point);
        // planning_frist_star_l = sqrt(pow(host_point(0) - host_projected_point.x, 2) + pow(host_point(1) - host_projected_point.y, 2));
        // planning_frist_star_s = host_projected_point.absolute_s;
        // Min_path_nodes min_cost_path_frist = CalcNodeMinCost(planning_frist_star_s, planning_frist_star_l);

        // planning_Interpolate_path = InterpolatePoints(min_cost_path_frist);

        // vector<Eigen::Vector2d> planning_Interpolate_path_xy = FrenetToXY(planning_Interpolate_path, path);

        // for (int i = 0; i < planning_Interpolate_path_xy.size(); i++)
        // {
        //     pcl::PointXYZI local_path_point;
        //     local_path_point.x = planning_Interpolate_path_xy[i](0);
        //     local_path_point.y = planning_Interpolate_path_xy[i](1);
        //     // cout<<"i:"<<i<<" x:"<<planning_Interpolate_path_xy[i](0)<<" y:"<<planning_Interpolate_path_xy[i](1)<<endl;
        //     local_path->points.push_back(local_path_point);
        // }
        // sensor_msgs::PointCloud2 ss_local_path;
        // pcl::toROSMsg(*local_path, ss_local_path);
        // ss_local_path.header.frame_id = "velodyne";
        // line_pub_local_path.publish(ss_local_path);
        // local_path.reset(new pcl::PointCloud<pcl::PointXYZI>);

        // // path.header.frame_id = "velodyne";
        // line_pub_path.publish(path);

        float x_middle = Car_Pose_middle->x ; // 车轴中点坐标
        float y_middle = Car_Pose_middle->y ;
        float x_back = Car_Pose_back->x; // 车轴中点坐标
        float y_back = Car_Pose_back->y;

        index_closest_Car = get_closest_point(Car_Pose->x, Car_Pose->y, path);
        if (index_closest_Car == 0)
        {
            index_middle_Car = 0;
            index_back_Car = 0;
        }
        else
        {
            index_middle_Car = get_closest_point(x_middle, y_middle, path, 1, index_closest_Car);
            if (index_middle_Car == 0)
            {
                index_back_Car = 0;
            }
            else
            {
                index_back_Car = get_closest_point(x_back, y_back, path, 1, index_middle_Car);
            }
        }

        Eigen::Vector2d host_point(x_middle, y_middle); // 此处的host点是车身中间点
        planning_msgs::path_point host_projected_point = find_projected_point_Frenet(path, index_middle_Car, host_point);
        Eigen::Vector2d planning_frist_star = Find_start_sl_FirstRun(host_point, host_projected_point, index_middle_Car);//车的sl

        Min_path_nodes min_cost_path_frist = CalcNodeMinCost(planning_frist_star(0), planning_frist_star(1)); // 最小路径错误，只有两组点

        DP_path_sl = InterpolatePoints(min_cost_path_frist);

        QP_path_sl_global = cacl_qp_path(planning_frist_star(0), planning_frist_star(1), 0, 0);

        vector<Eigen::Vector2d> planning_dp_path_xy = FrenetToXY(DP_path_sl, path);
        vector<Eigen::Vector2d> planning_qp_path_xy = FrenetToXY(QP_path_sl_global, path);
        // 计算路线航向角(斜率）
        vector<float> temp_phi_qp(planning_qp_path_xy.size());
        pcl::PointCloud<pcl::PointXYZI>::Ptr line_qp_path(new pcl::PointCloud<pcl::PointXYZI>); // 存储计算osqp求解出的解
        Calculate_OptimizedPath_Heading(planning_qp_path_xy, temp_phi_qp, line_qp_path);

        // 进行均值插值
        Mean_Interpolation(line_qp_path, line_qp_Interpolation);
        planning_msgs::car_path::Ptr QP_path(new planning_msgs::car_path);
        // QP_xy转化为pcl发布，用来观测
        QP_Path_Publish(QP_path, line_qp_Interpolation);

        // clock_t time_end2 = clock();
        // double time_diff2 = static_cast<double>(time_end2 - time_start) / CLOCKS_PER_SEC;
        // std::cout << "qp程序运行时间: " << time_diff2 << " 秒" << std::endl;

        for (int i = 0; i < planning_dp_path_xy.size(); i++)
        {
            pcl::PointXYZI local_dp_path_point;
            local_dp_path_point.x = planning_dp_path_xy[i](0);
            local_dp_path_point.y = planning_dp_path_xy[i](1);
            local_path->points.push_back(local_dp_path_point);
        }
        for (int i = 0; i < planning_qp_path_xy.size(); i++)
        {
            pcl::PointXYZI local_qp_path_point;
            local_qp_path_point.x = planning_qp_path_xy[i](0);
            local_qp_path_point.y = planning_qp_path_xy[i](1);
            local_qp_path->points.push_back(local_qp_path_point);
        }

        // dp_path发布
        sensor_msgs::PointCloud2 ss_local_path;
        pcl::toROSMsg(*local_path, ss_local_path);
        ss_local_path.header.frame_id = "velodyne";
        line_pub_local_path.publish(ss_local_path);
        local_path.reset(new pcl::PointCloud<pcl::PointXYZI>);
        // qp_path观测发布
        sensor_msgs::PointCloud2 ss_local_qp_path;
        pcl::toROSMsg(*local_qp_path, ss_local_qp_path);
        ss_local_qp_path.header.frame_id = "velodyne";
        line_pub_local_qp_path_watch.publish(ss_local_qp_path);
        local_qp_path.reset(new pcl::PointCloud<pcl::PointXYZI>);

        // QP_path.header.frame_id = "velodyne";
        QP_path->RunningNormally = QpPathRunningNormally;
        line_pub_local_qp_path.publish(*QP_path);

        // line_pub_local_qp_path.publish(QP_path);
        // line_qp_Interpolation

        // path.header.frame_id = "velodyne";
        line_pub_path.publish(path);

    } // 首次循环结束

    else
    {
        clock_t time_start = clock();
        planning_msgs::ObstacleList::Ptr obstacle_list_temp(new planning_msgs::ObstacleList);

        for (int i = 0; i < obstacle_list->obstacles.size(); i++)
        {
            pcl::PointXYZI obs;
            obs.x=obstacle_list->obstacles[i].x;
            obs.y=obstacle_list->obstacles[i].y;
            obs_watch->points.push_back(obs);
        }
         
        // *obstacle_list = *Obstacle_list;
        // Obstacle_list_Initialization(obstacle_list);

        Obstacle_list_Initialization_vision(obstacle_list_lidar);//视觉感知障碍物初始化
        for (const auto& obstacle: obstacle_list_lidar->obstacles) //视觉与雷达感知合并为一个变量
        {
            obstacle_list->obstacles.push_back(obstacle);
        }

        Obstacle_list_Initialization_vision(obstacle_list_vision);//视觉感知障碍物初始化
        for (const auto& obstacle: obstacle_list_vision->obstacles) //视觉与雷达感知合并为一个变量
        {
            obstacle_list->obstacles.push_back(obstacle);
        }
        // for (int i = 0; i < obstacle_list->obstacles.size(); i++)
        // {
        //     if (abs(obstacle_list->obstacles[i].l) < 2)
        //     {
        //         obstacle_list_swap->obstacles.push_back(obstacle_list->obstacles[i]);
        //     }
        // }
        // *obstacle_list = *obstacle_list_swap;


        // obstacle_list_swap.reset(new planning_msgs::ObstacleList);

        float x_middle = Car_Pose_middle->x ; // 车轴中点坐标
        float y_middle = Car_Pose_middle->y ;
        float x_back = Car_Pose_back->x; // 车轴中点坐标
        float y_back = Car_Pose_back->y;

        index_closest_Car = get_closest_point(Car_Pose->x, Car_Pose->y, path);
        if (index_closest_Car == 0)
        {
            index_middle_Car = 0;
            index_back_Car = 0;
        }
        else
        {
            index_middle_Car = get_closest_point(x_middle, y_middle, path, 1, index_closest_Car);
            if (index_middle_Car == 0)
            {
                index_back_Car = 0;
            }
            else
            {
                index_back_Car = get_closest_point(x_back, y_back, path, 1, index_middle_Car);
            }
        }
        // cout << " index_closest_Car:" << index_closest_Car << " index_middle_Car:" << index_middle_Car << " index_back_Car:" << index_back_Car << endl;

        Eigen::Vector2d host_point(x_middle, y_middle); // 此处的host点是车身中间点
        planning_msgs::path_point host_projected_middle_point = find_projected_point_Frenet(path, index_middle_Car, host_point);
        // Eigen::Vector2d planning_frist_star = Find_start_sl(host_point, host_projected_middle_point,index_middle_Car);
        host_middle_sl = Find_start_sl(host_point, host_projected_middle_point, index_middle_Car);  //全局路径下

        Eigen::Vector2d host_forward_point(Car_Pose->x, Car_Pose->y); // 此处的host点是车前的点的投影
        planning_msgs::path_point host_projected_forward_point = find_projected_point_Frenet(path, index_closest_Car, host_forward_point);
        host_forward_sl = Find_start_sl(host_forward_point, host_projected_forward_point, index_closest_Car); //全局路径下
   
        // int index_car_forward_qp_path = index2s(QP_path_sl_global, host_forward_sl(0));
        // int index_car_middle_qp_path = index2s(QP_path_sl_global, host_middle_sl(0));
        // //起始点为上一规划路径的车前点
        // Eigen::Vector2d planning_frist_star(QP_path_sl_global.s(index_car_forward_qp_path), QP_path_sl_global.l(index_car_forward_qp_path));
        Eigen::Vector2d planning_frist_star=host_middle_sl;
        //保留上一个时刻的车中点到车前点的规划路线的sl no.(1)
        // Eigen::VectorXd swap_qp_path_s = QP_path_sl_global.s.segment(index_car_middle_qp_path, index_car_forward_qp_path - index_car_middle_qp_path + 1);
        // Eigen::VectorXd swap_qp_path_l = QP_path_sl_global.l.segment(index_car_middle_qp_path, index_car_forward_qp_path - index_car_middle_qp_path + 1);
        //模式判断
        // if(!QpPathRunningNormally&&real_vehicle_speed<=0.01)
        // {
        //     car_direct=-1; //倒车
        // }
        // else{
        //     car_direct=1; //前进
        // }
        //模式判断
        
        if(!QpPathRunningNormally&&real_vehicle_speed<=0.1 ||flagCarStop==1)  //无解且停车
        {   sum_forward_reverse_num++;
            if(sum_forward_reverse_num>20)
            {
                if(flag_is_first_reverse)
                {
                    firstReversePosition(0)=x_middle;
                    firstReversePosition(1)=y_middle;
                }
                flag_is_first_reverse=false;
                car_direct=-1; //倒车
                cout<<" 无解且停车,开始倒车 "<<endl;
            }
            
        }
        else if(QpPathRunningNormally&&(reverseDistance>=minReverseDistance)  ) //有解且倒车到一定距离了
        {
            sum_back_reverse_num;
            flag_is_first_reverse=true;
            car_direct=1; //前进
            sum_forward_reverse_num=0;
            sum_back_reverse_num=0;
            cout<<" 有解,且倒车到一定距离,开始前进 "<<endl;
        }
        else if(flagCarStop==2&&car_direct==-1)  //倒车时有后方障碍物
        {
            sum_back_reverse_num++;
            if(sum_back_reverse_num>5)
            {
                flag_is_first_reverse=true;
                car_direct=1; //前进
                sum_forward_reverse_num=0;
                cout<<" 倒车时有后方障碍物,开始前进 "<<endl;
            }
            
        }
        // //过近状态改变
        // if(flagCarStop==1)
        // {
        //     sum_flag_stop_forward_num++;
        //     if(sum_flag_stop_forward_num>21)
        //     {
        //         car_direct=-1; //倒车
        //         sum_flag_stop_back_num=0;
        //     }
        // }
        // else if(flagCarStop==2)
        // {
        //     sum_flag_stop_back_num++;
        //     if(sum_flag_stop_forward_num>21)
        //     {
        //         car_direct=1; //前进
        //         sum_flag_stop_forward_num=0;
        //     }
        // }

        reverseDistance=sqrt(pow(x_middle-firstReversePosition(0),2)+pow(y_middle-firstReversePosition(1),2));

        //倒车模式
        
        //计算DP最小节点

        Min_path_nodes min_cost_path_frist = CalcNodeMinCost(planning_frist_star(0), planning_frist_star(1));
        DP_path_sl = InterpolatePoints(min_cost_path_frist);
        float calc_start_dl=tan(Car_Pose->theta-path.points[index_middle_Car].yaw);
        QP_path_sl = cacl_qp_path(planning_frist_star(0), planning_frist_star(1), calc_start_dl, 0);
        
        if(car_direct==-1) //倒车
        {
            Min_path_nodes min_cost_path_frist = CalcDpPathNodeMinCost_reverse(planning_frist_star(0), planning_frist_star(1));
            DP_path_sl_r = InterpolateDpPathPoints_reverse(min_cost_path_frist);
            QP_path_sl_r = calcQpPath_reverse(planning_frist_star(0), planning_frist_star(1), 0, 0);
            DP_path_sl=DP_path_sl_r;
            QP_path_sl=QP_path_sl_r;
            planning_dp_path_xy = FrenetToXY_r(DP_path_sl, path); //dp由frenet转XY坐标
            planning_qp_path_xy = FrenetToXY_r(QP_path_sl, path); //qp由frenet转XY坐标
        }
        else
        {
            planning_dp_path_xy = FrenetToXY(DP_path_sl, path); //dp由frenet转XY坐标
            planning_qp_path_xy = FrenetToXY(QP_path_sl, path); //qp由frenet转XY坐标
        }
        // for (int i = 0; i < QP_path_sl.s.size(); i++)
        // {
        //     cout<<"QP DP SL:"<<QP_path_sl.s(i)<<","<<QP_path_sl.l(i)<<";"<<DP_path_sl.s(i)<<","<<DP_path_sl.l(i)<<endl;
        // }
        


        //保留上一个时刻的车中点到车前点的规划路线的sl no.(2)
        // int concatenation_size = QP_path_sl.s.size() + index_car_forward_qp_path - index_car_middle_qp_path + 1;
        // Eigen::VectorXd QP_path_sl_new_s(concatenation_size);
        // Eigen::VectorXd QP_path_sl_new_l(concatenation_size);
        // QP_path_sl_new_s << swap_qp_path_s, QP_path_sl.s;
        // QP_path_sl_new_l << swap_qp_path_l, QP_path_sl.l;
        // if (RunningNormally)
        // {
        //     QP_path_sl.s = QP_path_sl_new_s;
        //     QP_path_sl.l = QP_path_sl_new_l;
        //     QP_path_sl_global.s = QP_path_sl_new_s;
        //     QP_path_sl_global.l = QP_path_sl_new_l;
        // }

        
        // cout<<"planning_dp_path_xy_size:"<<planning_dp_path_xy.size()<<endl;
        // for (int i = 0; i < planning_dp_path_xy.size(); i++)
        // {
        //     cout<<"planning_dp_path_xy xy:"<<planning_dp_path_xy[i][0]<<","<<planning_dp_path_xy[i][1]<<endl;
        // }
       
        // Plot_SL_Graph(host_forward_sl, DP_path_sl, QP_path_sl); //SL图绘画
      
        vector<float> temp_phi_qp(planning_qp_path_xy.size());
        pcl::PointCloud<pcl::PointXYZI>::Ptr line_qp_path(new pcl::PointCloud<pcl::PointXYZI>);
        if(car_direct==1) //前进
        {
            Calculate_OptimizedPath_Heading(planning_qp_path_xy, temp_phi_qp, line_qp_path);
        }
        else if(car_direct==-1)  //倒车
        {
            Calculate_OptimizedPath_Heading_reverse(planning_qp_path_xy, temp_phi_qp, line_qp_path);
        }
        else{
            cout<<"Car_State Error 02!"<<endl;
        }
        

        // 进行均值插值
        Mean_Interpolation(line_qp_path, line_qp_Interpolation);

        // QP_xy转化为pcl发布，用来观测
        QP_Path_Publish(QP_path, line_qp_Interpolation);
        Calc_QP_path_param(QP_path);
        //记录最近一次的路径规划可行解
        if(QpPathRunningNormally)
        {
            QP_path_last_success_run.reset(new planning_msgs::car_path);
            planning_qp_path_xy_last_success_run=planning_qp_path_xy;
            *QP_path_last_success_run=*QP_path;
        }
        else if(car_direct==1)
        {
            planning_qp_path_xy=planning_qp_path_xy_last_success_run;
            *QP_path=*QP_path_last_success_run;
        }
        
        //Speed Plan
        *obstacle_list_qp_path_sl=*obstacle_list;   //实际测试要注释开***
        
        Obstacle_list_Initialization_qp_path(obstacle_list_qp_path_sl,host_forward_sl); //将障碍物投影到QPpath下

        Speed_plan_calc_obs_ST(obstacle_list_qp_path_sl);   
        // Speed_Plan_DP_ST_nodes ST_Nodes= CalcSpeedPlanDp_StNodes(QP_path_sl_global.s(index_car_forward_qp_path));
        Speed_Plan_DP_ST_nodes ST_Nodes= CalcSpeedPlanDp_StNodes(host_middle_sl(0));  //生成DP坐标节点
        vector<double> Speed_DP_path_s=CalcSpeedDpCost(obstacle_list_qp_path_sl, ST_Nodes);
        Speed_plan_points speed_qp_points=CalcSpeedPlan_QpPath(obstacle_list_qp_path_sl, ST_Nodes, Speed_DP_path_s,host_middle_sl(0));//速度qp规划的结果
        // plt::ion(); // 动态画图
        // Plot_ST_Graph(speed_qp_points,Speed_DP_path_s,obstacle_list_qp_path_sl); //ST图绘画
        
        //dp_path转化为pcl格式方便rviz观察
        for (int i = 0; i < planning_dp_path_xy.size(); i++)
        {
            pcl::PointXYZI local_dp_path_point;
            local_dp_path_point.x = planning_dp_path_xy[i](0);
            local_dp_path_point.y = planning_dp_path_xy[i](1);
            local_path->points.push_back(local_dp_path_point);
        }
        //qp_path转化为pcl格式方便rviz观察
        
        local_qp_path->points.reserve(planning_qp_path_xy.size());
        for (int i = 0; i < planning_qp_path_xy.size(); i++)
        {
            pcl::PointXYZI local_qp_path_point;
            local_qp_path_point.x = planning_qp_path_xy[i](0);
            local_qp_path_point.y = planning_qp_path_xy[i](1);
            local_qp_path->points.push_back(local_qp_path_point);
        }
        
        // dp_path发布
        sensor_msgs::PointCloud2 ss_local_path;
        pcl::toROSMsg(*local_path, ss_local_path);
        ss_local_path.header.frame_id = "velodyne";
        line_pub_local_path.publish(ss_local_path);
        local_path.reset(new pcl::PointCloud<pcl::PointXYZI>);
        // qp_path观测发布
        sensor_msgs::PointCloud2 ss_local_qp_path;
        pcl::toROSMsg(*local_qp_path, ss_local_qp_path);
        ss_local_qp_path.header.frame_id = "velodyne";
        line_pub_local_qp_path_watch.publish(ss_local_qp_path);
        local_qp_path.reset(new pcl::PointCloud<pcl::PointXYZI>);
        // obs观测发布
        sensor_msgs::PointCloud2 ss_local_obs;
        pcl::toROSMsg(*obs_watch, ss_local_obs);
        ss_local_obs.header.frame_id = "velodyne";
        obs_watch_pub.publish(ss_local_obs);
        obs_watch.reset(new pcl::PointCloud<pcl::PointXYZI>);
        
        // if(!QpPathRunningNormally&&car_direct==1)
        // {
        //     QP_path_last_success_run->car_direct=car_direct;
        //     QP_path_last_success_run->V_straight=calc_car_speed;
        //     line_pub_local_qp_path.publish(*QP_path_last_success_run);
        // }
        // else
        // {
            QP_path->V_straight=calc_car_speed;
            QP_path->car_direct=car_direct;
            QP_path->RunningNormally = QpPathRunningNormally;
            line_pub_local_qp_path.publish(*QP_path);
        // }


        // QP_path.header.frame_id = "velodyne";
        
        QP_path.reset(new planning_msgs::car_path);

        // line_pub_local_qp_path.publish(QP_path);
        // line_qp_Interpolation

        // path.header.frame_id = "velodyne";
        line_pub_path.publish(path);


        
        // clock_t time_end = clock();
        // double time_diff = static_cast<double>(time_end - time_start) / CLOCKS_PER_SEC;
        // std::cout << "程序运行时间: " << time_diff << " 秒" << std::endl;
    }

    // 发布全局观测路线
    sensor_msgs::PointCloud2 line_record_pub_watch;
    pcl::toROSMsg(*line_record_watch, line_record_pub_watch);
    line_record_pub_watch.header.frame_id = "velodyne";
    line_pub_watch.publish(line_record_pub_watch);
    // path.header.frame_id = "velodyne";
    // line_pub_path.publish(path);

    line_qp_Interpolation.reset(new pcl::PointCloud<pcl::PointXYZI>);

    line_qp_Interpolation.reset(new pcl::PointCloud<pcl::PointXYZI>);
    // cout << "Path_total_num:" << line_record->points.size();
    // cout << "   Successfully load path!!!" << endl;
}

Eigen::Vector2d ObstacleSL2XY(planning_msgs::Obstacle obs)
{
    int index_obs2=index2s(path,obs.s);
    planning_msgs::path_point proj_point_ = find_projected_point_Frenet(path, index_obs2, obs.s, obs.l);
    Eigen::Vector2d match_point_xy(proj_point_.x, proj_point_.y);
    Eigen::Vector2d point_nor(proj_point_.nor.x, proj_point_.nor.y);
    Eigen::Vector2d point_temp_xy = match_point_xy + obs.l * point_nor;
    return point_temp_xy;
}

void Calc_QP_path_param(planning_msgs::car_path::Ptr &QP_path)
{
    QP_path->points[0].absolute_s=0;
    QP_path->points[0].ds=0;
    double absolute_s=0;
    for (int i = 1; i < QP_path->points.size(); i++)
    {
        QP_path->points[i].ds=sqrt(pow(QP_path->points[i].x-QP_path->points[i-1].x,2)+pow(QP_path->points[i].y-QP_path->points[i-1].y,2)); 
        absolute_s+=QP_path->points[i].ds;
        QP_path->points[i].absolute_s=absolute_s;
        QP_path->points[i].tor.x=cos(QP_path->points[i].yaw);
        QP_path->points[i].tor.y=sin(QP_path->points[i].yaw);
        QP_path->points[i].nor.x=-sin(QP_path->points[i].yaw);
        QP_path->points[i].nor.y=cos(QP_path->points[i].yaw);
    }
    
}

// void Plot_ST_Graph(Speed_plan_points speed_qp_points,vector<double> Speed_DP_path_s,planning_msgs::ObstacleList::Ptr &obstacle_list_qp_path_sl)
// {
//     plt::ion();
//     plt::figure(2); // 动态画图
//     plt::clf(); // 清空画布
//     plt::named_plot("QP_ST", speed_qp_points.s_time, speed_qp_points.s, "--");
//     plt::named_plot("DP_ST", speed_qp_points.s_time, Speed_DP_path_s, "green");
//     // for (int i = 0; i < obstacle_list_qp_path_sl->obstacles.size(); i++)
//     // {
//     //     vector<double> obs_x,obs_y;
//     //     obs_x.push_back(obstacle_list_qp_path_sl->obstacles[i].speed_plan_s_in);
//     //     obs_x.push_back(obstacle_list_qp_path_sl->obstacles[i].speed_plan_s_out);
//     //     obs_y.push_back(obstacle_list_qp_path_sl->obstacles[i].min_s);
//     //     obs_y.push_back(obstacle_list_qp_path_sl->obstacles[i].max_s);
//     //     plt::named_plot("DP_ST", speed_qp_points.s_time, Speed_DP_path_s, "red");
//     // }
//     for (int i = 0; i < obstacle_list_qp_path_sl->obstacles.size(); i++)
//     {
//         if(obstacle_list_qp_path_sl->obstacles[i].is_consider)
//         {
//             std::vector<double> obs_t = {obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_in,obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_out};
//             std::vector<double> obs_s = {obstacle_list_qp_path_sl->obstacles[i].speed_plan_s_in, obstacle_list_qp_path_sl->obstacles[i].speed_plan_s_out};
//             // cout<<"obs_t_in/out:"<<obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_in<<","<<obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_out<<endl;
//             plt::plot(obs_t, obs_s,"red");
//         }
//     }
    
//     // plt::named_plot("Obstacle", speed_qp_points.s_time, Speed_DP_path_s, "green");
//     int max_y=Speed_DP_path_s.back()>speed_qp_points.s.back()?Speed_DP_path_s.back():speed_qp_points.s.back();
//     // plt::ylim(int(speed_qp_points.s[0]), max_y+1);
//     plt::xlim(0, 7);
//     plt::legend();
//     plt::title("ST");
//     plt::pause(0.0000001); // 等待0.001秒，让GUI有机会响应用户交互
//     plt::show();
// }

//这里的T_in,T_out,应该考虑的更细致一些，应该考虑障碍物的外形（待优化）
void Speed_plan_calc_obs_ST(planning_msgs::ObstacleList::Ptr &obstacle_list_qp_path_sl)
{
    int is_close_obs_num=0;
    for (int i = 0; i < obstacle_list_qp_path_sl->obstacles.size(); i++)
    {
        if(QpPathRunningNormally)
        {
            //距离太远或静态障碍物不考虑
            // cout<<"只考虑动态障碍物"<<endl;
            if (obstacle_list_qp_path_sl->obstacles[i].max_l < -road_obsracle_limit || obstacle_list_qp_path_sl->obstacles[i].min_l > road_obsracle_limit || obstacle_list_qp_path_sl->obstacles[i].is_dynamic_obs==false ) // 障碍物在+-2外不考虑？？？
            {
                obstacle_list_qp_path_sl->obstacles[i].is_consider = false;
                // cout<<"false02"<<endl;
                continue;
            }
        }
        else
        {
            // cout<<"动态静态障碍物都考虑"<<endl;
            // cout<<"obstacle_list_qp_path_sl->obstacles[i].l:"<<obstacle_list_qp_path_sl->obstacles[i].max_l<<" ,"<<obstacle_list_qp_path_sl->obstacles[i].min_l<<endl;
            if (obstacle_list_qp_path_sl->obstacles[i].max_l < -road_obsracle_limit || obstacle_list_qp_path_sl->obstacles[i].min_l > road_obsracle_limit ) // 障碍物在+-2外不考虑？？？
            {
                obstacle_list_qp_path_sl->obstacles[i].is_consider = false;
                // cout<<"false02"<<endl;
                continue;
            }
        }
        //这里为当无解时，速度规划考虑静态障碍物，当判定为静态障碍时，速度赋值为很小的数字
        if(obstacle_list_qp_path_sl->obstacles[i].is_dynamic_obs)
        {
            obstacle_list_qp_path_sl->obstacles[i].l_vel=0.01;
            obstacle_list_qp_path_sl->obstacles[i].s_vel=0.01;
        }
        float t_zero = obstacle_list_qp_path_sl->obstacles[i].l / (-obstacle_list_qp_path_sl->obstacles[i].l_vel); //车辆到道路中心线的距离
        float t_boundary1 = obstacleConsiderDistance / obstacle_list_qp_path_sl->obstacles[i].l_vel + t_zero;
        float t_boundary2 = -obstacleConsiderDistance / obstacle_list_qp_path_sl->obstacles[i].l_vel + t_zero;
        float t_in,t_out,s_in,s_out;
        if (t_boundary1 >= t_boundary2)
        {
            t_in = t_boundary2-abs(obstacle_list_qp_path_sl->obstacles[i].max_length/(obstacle_list_qp_path_sl->obstacles[i].l_vel*2));
            t_out = t_boundary1+abs(obstacle_list_qp_path_sl->obstacles[i].max_length/(obstacle_list_qp_path_sl->obstacles[i].l_vel*2));
        }
        else
        {
            t_in = t_boundary1-abs(obstacle_list_qp_path_sl->obstacles[i].max_length/(obstacle_list_qp_path_sl->obstacles[i].l_vel*2));
            t_out = t_boundary2+abs(obstacle_list_qp_path_sl->obstacles[i].max_length/(obstacle_list_qp_path_sl->obstacles[i].l_vel*2));
        }
        if (t_in > plan_time || t_out < 0) //在plan_time秒内无影响则舍弃
        {
            obstacle_list_qp_path_sl->obstacles[i].is_consider = false;
            cout<<"false01"<<endl;
            continue;
        }
        t_in=t_in>0?t_in:0;
        t_out=t_out>plan_time?plan_time:t_out;
        s_in=obstacle_list_qp_path_sl->obstacles[i].min_s + obstacle_list_qp_path_sl->obstacles[i].s_vel * t_in;
        s_out=obstacle_list_qp_path_sl->obstacles[i].max_s + obstacle_list_qp_path_sl->obstacles[i].s_vel * t_out;
        //障碍物过近
        if(s_in<1)
        {
            flag_obstacle_too_close=true;
            is_close_obs_num++;
        }

        obstacle_list_qp_path_sl->obstacles[i].speed_plan_s_in = s_in>sMinDistance?s_in:sMinDistance;
        obstacle_list_qp_path_sl->obstacles[i].speed_plan_s_out = s_out>sMinDistance?s_out:sMinDistance;
        obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_in = t_in;
        obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_out = t_out;
        // cout<<"obs_ST "<<i<<": s_in:"<<obstacle_list_qp_path_sl->obstacles[i].speed_plan_s_in<<",s_out: "<<obstacle_list_qp_path_sl->obstacles[i].speed_plan_s_out<<",t_in:"<<obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_in<<",t_out:"<<obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_out<<endl;

    }
    //重置
    if(is_close_obs_num==0)
    {
        flag_obstacle_too_close=false;
    }
}

Speed_Plan_DP_ST_nodes CalcSpeedPlanDp_StNodes(float plan_start_s)
{
    float t_node_num = plan_time / speed_plan_t_dt;
    Speed_Plan_DP_ST_nodes DP_ST_nodes;
    vector<float> s_node;
    s_node.reserve(71);

    for (float i = 0.0; i <= speed_plan_distance; i += ST_s_min_step) // 0-7m 分辨率 0.1m 
    {
        s_node.push_back(i);
    }

    float s_node_num = s_node.size();
    std::vector<std::vector<float>> st_node(t_node_num, std::vector<float>(s_node.size()));

    Speed_DP_col_nodes speed_DP_col_start_nodes;    
    Speed_DP_Single_node speed_single_start_node;
    speed_single_start_node.node_s = s_node[0];
    speed_single_start_node.node_t = 0;
    speed_single_start_node.node_s_dot = real_vehicle_speed; // 待修改：这里如果接入车速应该设置为当前车速！！！
    speed_DP_col_start_nodes.rol_nodes.push_back(speed_single_start_node);

    DP_ST_nodes.col_nodes.push_back(speed_DP_col_start_nodes);

    for (size_t j = 1; j <= t_node_num; ++j)
    {
        Speed_DP_col_nodes speed_DP_col_nodes;
        for (size_t i = 0; i < s_node_num; ++i)
        {
            Speed_DP_Single_node speed_single_node;
            speed_single_node.node_s = s_node[i];
            speed_single_node.node_t = j * speed_plan_t_dt;
            speed_DP_col_nodes.rol_nodes.push_back(speed_single_node);
        }
        DP_ST_nodes.col_nodes.push_back(speed_DP_col_nodes);
    }
    return DP_ST_nodes;
}


vector<double> CalcSpeedDpCost(planning_msgs::ObstacleList::Ptr &obstacle_list_qp_path_sl, Speed_Plan_DP_ST_nodes &DP_ST_nodes)
{
    int max_jump_S=ceil(dp_vel_max*speed_plan_t_dt/ST_s_min_step);  //向上取整 
    
    // 起点循环
    DP_ST_nodes.col_nodes[0].rol_nodes[0].is_possible = true; //起点为true
    for (int i = 0; i <= max_jump_S; i++)
    {
        DP_ST_nodes.col_nodes[1].rol_nodes[i].node_s_dot = (DP_ST_nodes.col_nodes[1].rol_nodes[i].node_s - DP_ST_nodes.col_nodes[0].rol_nodes[0].node_s) / speed_plan_t_dt;
        DP_ST_nodes.col_nodes[1].rol_nodes[i].node_s_dot2 = (DP_ST_nodes.col_nodes[1].rol_nodes[i].node_s_dot - DP_ST_nodes.col_nodes[0].rol_nodes[0].node_s_dot) / speed_plan_t_dt;
        if (DP_ST_nodes.col_nodes[1].rol_nodes[i].node_s_dot < dp_vel_max || DP_ST_nodes.col_nodes[1].rol_nodes[i].node_s_dot2 < dp_a_max)
        {
            DP_ST_nodes.col_nodes[1].rol_nodes[i].is_possible = true;
            DP_ST_nodes.col_nodes[1].rol_nodes[i].speed_cost = w_SpeedDpPlan_ref_vel * pow(speed_reference - DP_ST_nodes.col_nodes[1].rol_nodes[i].node_s_dot, 2);
            DP_ST_nodes.col_nodes[1].rol_nodes[i].a_cost = w_SpeedDpPlan_a * pow(DP_ST_nodes.col_nodes[1].rol_nodes[i].node_s_dot2, 2);
            DP_ST_nodes.col_nodes[1].rol_nodes[i].obs_cost= CalcSpeedDp_ObsCost(obstacle_list_qp_path_sl, DP_ST_nodes, 0, 1, 0,i);
            DP_ST_nodes.col_nodes[1].rol_nodes[i].cost = DP_ST_nodes.col_nodes[1].rol_nodes[i].obs_cost + DP_ST_nodes.col_nodes[1].rol_nodes[i].speed_cost + DP_ST_nodes.col_nodes[1].rol_nodes[i].a_cost;
            DP_ST_nodes.col_nodes[1].rol_nodes[i].toThis_min_cost_index=0;  //第一列的上一行的最优节点都是0，因为第0列只有0号节点
        }
        else
        {
            break;
        }
    }

    // 计算剩下列cost损失
    #pragma omp for
    for (int i = 1; i < DP_ST_nodes.col_nodes.size()-1 ; i++) // 列数
    {
        for (int k = 0; k < ((i+1)*max_jump_S>DP_ST_nodes.col_nodes[i].rol_nodes.size()?DP_ST_nodes.col_nodes[i].rol_nodes.size():(i+1)*max_jump_S); k++) //下一列行数
        {
            double min_cost = std::numeric_limits<double>::max();
            int min_cost_index;
            for(int j = (k-max_jump_S>0?k-max_jump_S:0); j <= k; j++)  // 开始列行数    //此处为省略计算，k-6为手动计算的速度最大节点，更改ST图时要重新计算更改
            {
                if(!DP_ST_nodes.col_nodes[i].rol_nodes[j].is_possible || k<j ) //上一列不可能节点和小于这列数的不考虑，即不考虑倒车
                {
                    continue;
                }
                double node_vel=(DP_ST_nodes.col_nodes[i+1].rol_nodes[k].node_s - DP_ST_nodes.col_nodes[i].rol_nodes[j].node_s) / speed_plan_t_dt;
                // cout<<"node_vel:"<<node_vel<<endl;
                double node_a=(DP_ST_nodes.col_nodes[i+1].rol_nodes[k].node_s_dot - DP_ST_nodes.col_nodes[i].rol_nodes[j].node_s_dot) / speed_plan_t_dt;

                if (node_vel <= dp_vel_max || node_a <= dp_a_max)
                {
                    DP_ST_nodes.col_nodes[i+1].rol_nodes[k].is_possible = true;
                    double speed_cost = w_SpeedDpPlan_ref_vel * pow(speed_reference - node_vel, 2);
                    double a_cost = w_SpeedDpPlan_a * pow(node_a, 2);
                    double obs_cost= w_SpeedDpPlan_obs* CalcSpeedDp_ObsCost(obstacle_list_qp_path_sl, DP_ST_nodes, i, i+1, j,k);  
                    // cout<<"cost:::"<< DP_ST_nodes.col_nodes[i+1].rol_nodes[k].speed_cost<<" ,"<<DP_ST_nodes.col_nodes[i+1].rol_nodes[k].a_cost<<" ,"<<DP_ST_nodes.col_nodes[i+1].rol_nodes[k].obs_cost<<endl;
                    double forward_node_to_this_node_cost=speed_cost+a_cost+obs_cost;
                    double total_cost=forward_node_to_this_node_cost+DP_ST_nodes.col_nodes[i].rol_nodes[j].cost; //总代价等于上一节点代价加上列到此节点代价
                    if(total_cost<min_cost)  //选择最小的cost，并记录最小值cost的上一列序号
                    {
                        min_cost=total_cost;
                        min_cost_index=j;

                        // DP_ST_nodes.col_nodes[i+1].rol_nodes[k].a_cost=a_cost;
                        // DP_ST_nodes.col_nodes[i+1].rol_nodes[k].speed_cost=speed_cost;
                        // DP_ST_nodes.col_nodes[i+1].rol_nodes[k].obs_cost=obs_cost;
                       
                        DP_ST_nodes.col_nodes[i+1].rol_nodes[k].cost=min_cost;
                        DP_ST_nodes.col_nodes[i+1].rol_nodes[k].node_s_dot=node_vel;
                        DP_ST_nodes.col_nodes[i+1].rol_nodes[k].node_s_dot2=node_a;
                        DP_ST_nodes.col_nodes[i+1].rol_nodes[k].toThis_min_cost_index=min_cost_index;

                    }
                    
                    
                }
                else
                {
                    continue;
                }
            }
            
            
        }
    //     clock_t time_end = clock();
    // double time_diff = static_cast<double>(time_end - time_start) / CLOCKS_PER_SEC;
    // std::cout << "DP——start  列节点运行时间: " << time_diff << " 秒" << std::endl;
    }

    // for (int i = 0; i < DP_ST_nodes.col_nodes.size(); i++)
    // {
    //     for (int j = 0; j < DP_ST_nodes.col_nodes[i].rol_nodes.size(); j++)
    //     {
    //         cout<<i<<","<<j<<":"<<"||"<<DP_ST_nodes.col_nodes[i].rol_nodes[j].node_s_dot<<"||";
    //     }
    //     cout<<endl;
    // }
    
    //寻找终点cost的最小值
    double min_cost = std::numeric_limits<double>::max();
    int min_cost_last_index;
    int min_cost_index;
    //求出最后一列总代价最小的一个节点
    for (int i = 0; i < DP_ST_nodes.col_nodes[DP_ST_nodes.col_nodes.size()-1].rol_nodes.size(); i++) 
    {
        if(DP_ST_nodes.col_nodes[DP_ST_nodes.col_nodes.size()-1].rol_nodes[i].cost<min_cost)
        {
            min_cost=DP_ST_nodes.col_nodes[DP_ST_nodes.col_nodes.size()-1].rol_nodes[i].cost;
            min_cost_last_index=i;
        }
    }
    
    vector<double> Speed_DP_path_s;
    // 回朔序号
    if(min_cost>1e6)
    {
        cout<<"DpSpeed无解,为初始0节点，速度规划为0"<<endl;
        for (int i = 0; i < DP_ST_nodes.col_nodes.size(); i++)
        {
            Speed_DP_path_s.push_back(0.0);
        }
    }
    else
    {
        vector<int> Speed_DP_path_index;
        Speed_DP_path_index.push_back(min_cost_last_index);
        min_cost_index=min_cost_last_index;

        // cout<< DP_ST_nodes.col_nodes[DP_ST_nodes.col_nodes.size()-1].rol_nodes[min_cost_last_index].cost<<" <<"<<endl;
        for (int i =DP_ST_nodes.col_nodes.size()-1; i > 0; i--)
        {
            Speed_DP_path_index.push_back(DP_ST_nodes.col_nodes[i].rol_nodes[min_cost_index].toThis_min_cost_index);
            min_cost_index=DP_ST_nodes.col_nodes[i].rol_nodes[min_cost_index].toThis_min_cost_index;
        }

        std::reverse(Speed_DP_path_index.begin(), Speed_DP_path_index.end()); // 序号反转，改为正序
    
        for (int i = 0; i < Speed_DP_path_index.size(); i++)
        {
            Speed_DP_path_s.push_back(DP_ST_nodes.col_nodes[i].rol_nodes[Speed_DP_path_index[i]].node_s);
        }

    }
    cout<<endl;

    return Speed_DP_path_s;
}

Speed_plan_points CalcSpeedPlan_QpPath(planning_msgs::ObstacleList::Ptr &obstacle_list_qp_path_sl, Speed_Plan_DP_ST_nodes &DP_ST_nodes, vector<double> best_speed_path_s,double s_start)
{
    Eigen::VectorXd s_ub = Eigen::VectorXd::Constant(plan_time / speed_plan_t_dt+1, speed_plan_distance);
    Eigen::VectorXd s_lb = Eigen::VectorXd::Zero(plan_time / speed_plan_t_dt+1);
    // cout<<"obstacle_list_qp_path_sl->obstacles.size():"<<obstacle_list_qp_path_sl->obstacles.size()<<endl;
    // cout<<"s_start:"<<s_start<<endl;
    for (int i = 0; i < obstacle_list_qp_path_sl->obstacles.size(); i++)
    {
        if (!obstacle_list_qp_path_sl->obstacles[i].is_consider)
        {
            continue;
        }
        int index_s_t_in, index_s_t_out;

        index_s_t_in = obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_in / speed_plan_t_dt;       // 找到障碍物的ST图Tmin
        index_s_t_out = static_cast<int>(obstacle_list_qp_path_sl->obstacles[i].speed_plan_t_out / speed_plan_t_dt) ; // 找到障碍物的ST图Tmax

        // if (obstacle_list_qp_path_sl->obstacles[i].s >= best_speed_path_s[index_s_t_in]) // 决策为减速避让
        // {
            // cout<<"减速避让"<<endl;
            for (int j = index_s_t_in; j <= index_s_t_out; j++)
            {
                if (s_ub[j] > obstacle_list_qp_path_sl->obstacles[i].min_s+j*speed_plan_t_dt*obstacle_list_qp_path_sl->obstacles[i].s_vel - SpeedQpPlan_SafeDistance) // 这里加减一就是安全域度
                {
                    double bound=obstacle_list_qp_path_sl->obstacles[i].min_s+j*speed_plan_t_dt*obstacle_list_qp_path_sl->obstacles[i].s_vel - SpeedQpPlan_SafeDistance;
                    bound=bound>0.01?bound:0.01;
                    s_ub[j] = bound;
              
                    // cout<<"上界改变:"<<j*0.5<<"秒：start_s:"<<s_start<<","<<obstacle_list_qp_path_sl->obstacles[i].min_s<<obstacle_list_qp_path_sl->obstacles[i].min_s - 2-s_start<<endl;
                }
            }
        // }
        // else // 决策为加速超越
        // {
        //     cout<<"加速超越"<<endl;
        //     for (int j = index_s_t_in; j <= index_s_t_out; j++)
        //     {
        //         if (s_lb[j] < obstacle_list_qp_path_sl->obstacles[i].max_s + SpeedQpPlan_SafeDistance) // 这里加减一就是安全域度
        //         {
        //             s_lb[j] = obstacle_list_qp_path_sl->obstacles[i].max_s + SpeedQpPlan_SafeDistance;
        //         }
        //     }
        // }
    }
    
    // qp_speed计算
    int n = plan_time / speed_plan_t_dt+1;
    
    Eigen::SparseMatrix<double> A(6 * n - 3, 3 * n);
    Eigen::SparseMatrix<double> H(3 * n, 3 * n);
    Eigen::SparseMatrix<double> Aeq_sub(2, 6);
    Eigen::SparseMatrix<double> A_sub1(3, 3);
    Eigen::SparseMatrix<double> A_sub2(1, 6);
    
    Eigen::VectorXd f = Eigen::VectorXd::Zero(3 * n, 1);
    Eigen::VectorXd lb = Eigen::VectorXd::Zero(6 * n - 3, 1);
    Eigen::VectorXd ub = Eigen::VectorXd::Zero(6 * n - 3, 1);
    // Eigen::VectorXd l_min = Eigen::VectorXd::Constant(n, min_l);
    // Eigen::VectorXd l_max = Eigen::VectorXd::Constant(n, max_l);

    Aeq_sub.reserve(9); // 预分配非零元素空间
    A_sub1.reserve(3);
    A_sub2.reserve(2);
    A.reserve(14 * n - 11);

    H.reserve(2 * n);

    // 设置 Aeq_sub 稀疏矩阵的值
    Aeq_sub.insert(0, 0) = 1;
    Aeq_sub.insert(0, 1) = speed_plan_t_dt;
    Aeq_sub.insert(0, 2) = pow(speed_plan_t_dt, 2) / 3;
    Aeq_sub.insert(0, 3) = -1;
    Aeq_sub.insert(0, 5) = pow(speed_plan_t_dt, 2) / 6;
    Aeq_sub.insert(1, 1) = 1;
    Aeq_sub.insert(1, 2) = speed_plan_t_dt / 2;
    Aeq_sub.insert(1, 4) = -1;
    Aeq_sub.insert(1, 5) = speed_plan_t_dt / 2;
     
    // 设置 A_sub 稀疏矩阵的值
    A_sub1.insert(0, 0) = 1;
    A_sub1.insert(1, 1) = 1;
    A_sub1.insert(2, 2) = 1;

    A_sub2.insert(0, 0) = -1;
    A_sub2.insert(0, 3) = 1;

    // 设置 A 稀疏矩阵的值
    for (int i = 0; i < n; i++)
    {
        A.insert(3 * i, 3 * i) = A_sub1.coeff(0, 0);
        A.insert(3 * i + 1, 3 * i + 1) = A_sub1.coeff(1, 1);
        A.insert(3 * i + 2, 3 * i + 2) = A_sub1.coeff(2, 2);
    }
    
    for (int i = 0; i < n - 1; i++)
    {
        A.insert(3 * n + 2 * i, 3 * i) = Aeq_sub.coeff(0, 0);
        A.insert(3 * n + 2 * i, 3 * i + 1) = Aeq_sub.coeff(0, 1);
        A.insert(3 * n + 2 * i, 3 * i + 2) = Aeq_sub.coeff(0, 2);
        A.insert(3 * n + 2 * i, 3 * i + 3) = Aeq_sub.coeff(0, 3);
        A.insert(3 * n + 2 * i, 3 * i + 5) = Aeq_sub.coeff(0, 5);
        A.insert(3 * n + 2 * i + 1, 3 * i + 1) = Aeq_sub.coeff(1, 1);
        A.insert(3 * n + 2 * i + 1, 3 * i + 2) = Aeq_sub.coeff(1, 2);
        A.insert(3 * n + 2 * i + 1, 3 * i + 4) = Aeq_sub.coeff(1, 4);
        A.insert(3 * n + 2 * i + 1, 3 * i + 5) = Aeq_sub.coeff(1, 5);

        A.insert((5 * n - 2) + i, 3 * i) = A_sub2.coeff(0, 0);
        A.insert((5 * n - 2) + i, 3 * i + 3) = A_sub2.coeff(0, 3);
        ub(5 * n - 2 + i) = 1e8;
    }
    // 设置 H 稀疏矩阵的值
    for (int i = 0; i < n; i++)
    {
        H.insert(3 * i + 1, 3 * i + 1) = 2 * (w_SpeedQpPlan_ref_vel);
        H.insert(3 * i + 2, 3 * i + 2) = 2 * (w_SpeedQpPlan_a);

        f(3 * i + 1) = -2 * speed_reference * w_SpeedQpPlan_ref_vel;
        lb(3 * i) = s_lb(i);  //这里的s_lb限制是绝对s，但是QP计算是相对s，所以减去自车s
        ub(3 * i) = s_ub(i);
       
        ub(3 * i + 1) = SpeedQP_v_max;
        ub(3 * i + 2) = SpeedQP_a_max;

    }
    lb(0)=0; //起点设置
    ub(0)=0; //起点设置
    
    A.makeCompressed();
    H.makeCompressed();

    // // osqp求解
    int NumberOfVariables = 3 * n;       // A矩阵的列数
    int NumberOfConstraints = 6 * n - 3; // A矩阵的行数
    // cout << "Path optimization progress --25% " << endl;
    // // 求解部分
    OsqpEigen::Solver solver;

    // // settings
    solver.settings()->setVerbosity(false); // 求解器信息输出控制
    solver.settings()->setWarmStart(true);  // 启用热启动
    // solver.settings()->setInitialGuessX(f); // 设置初始解向量,加速收敛

    // set the initial data of the QP solver
    // 矩阵A为m*n矩阵
    solver.data()->setNumberOfVariables(NumberOfVariables);     // 设置A矩阵的列数，即n
    solver.data()->setNumberOfConstraints(NumberOfConstraints); // 设置A矩阵的行数，即m

    if (!solver.data()->setHessianMatrix(H))
        // return 1; //设置P矩阵
        cout << "error1" << endl;
    if (!solver.data()->setGradient(f))
        // return 1; //设置q or f矩阵。当没有时设置为全0向量
        cout << "error2" << endl;
    if (!solver.data()->setLinearConstraintsMatrix(A))
        // return 1; //设置线性约束的A矩阵
        cout << "error3" << endl;
    if (!solver.data()->setLowerBound(lb))
    { // return 1; //设置下边界
        cout << "error4" << endl;
    }
    if (!solver.data()->setUpperBound(ub))
    { // return 1; //设置上边界
        cout << "error5" << endl;
    }

    // instantiate the solver
    if (!solver.initSolver())
        // return 1;
        cout << "speed_error6" << endl;
    Eigen::VectorXd QPSolution = Eigen::VectorXd::Zero(3 * n);

    // solve the QP problem

    if (!solver.solve())
    {
        SpeedPlanRunningNormally = false;
        cout << "Speed Error Slove!" << endl;
    }
    else
    {
        SpeedPlanRunningNormally = true;
    }

    QPSolution = solver.getSolution();

    vector<double> s(n);
    vector<double> s_dot(n);
    vector<double> s_dot2(n);
    vector<double> s_time(n);

    for (int i = 0; i < n; i++)
    {
        s[i] = QPSolution(3 * i);
        s_dot[i] = QPSolution(3 * i + 1);
        s_dot2[i] = QPSolution(3 * i + 2);
        s_time[i] = i*speed_plan_t_dt;
    }
    Speed_plan_points speed_plan_points;
    speed_plan_points.s=s;
    speed_plan_points.s_dot=s_dot;
    speed_plan_points.s_dot2=s_dot2;
    speed_plan_points.s_time=s_time;
    if(s_dot[0]<speed_reference-0.1)
        cout<<"减速！！！"<<endl;
    cout<<"推荐速度>>>>> "<<s_dot[0]<<" <<<<<"<<endl;
    QP_path->car_direct=car_direct;
    if(car_direct==1)
    {
        if(flag_obstacle_too_close)  
        {
            calc_car_speed=vel_deceleration_rate*s_dot[0];
        }
        else
        {
            calc_car_speed=s_dot[0];
        }
        
    }
    else
    {
        calc_car_speed=car_direct*0.5;
    }
        
    cout<<"car_direct:"<<car_direct<<" QP_path->V_straight:"<<QP_path->V_straight<<endl;
    return speed_plan_points;
}


/**
 * @description:
 * @param {Speed_DP_col_nodes} &speed_DP_col_nodes ST节点的列
 * @param {int} rol_start 行数
 * @return {*}
 */
double CalcSpeedDp_ObsCost(const planning_msgs::ObstacleList::Ptr &obstacle_list_qp_path_sl, Speed_Plan_DP_ST_nodes &DP_ST_nodes, int col_start, int col_end, int rol_start,int rol_end)
{
    int n = 5; // 点与点之间的采样间隔
    float dt = speed_plan_t_dt / 5;
    double cost=0;
    for (int k = 0; k < obstacle_list_qp_path_sl->obstacles.size(); k++) // 障碍物循环
    {
        // if(obstacle_list_qp_path_sl->obstacles[k].is_consider==true)
        //     cout<<"DP_speed:TURE"<<endl;
        // else
        //     cout<<"DP_speed:FALSE"<<endl;
        if (!obstacle_list_qp_path_sl->obstacles[k].is_consider) // 不满足的障碍物不考虑
        {
            continue;
        }
        for (int j = 0; j < n; j++) // 采样点循环
        {
            double A_s = DP_ST_nodes.col_nodes[col_start].rol_nodes[rol_start].node_s + (DP_ST_nodes.col_nodes[col_end].rol_nodes[rol_end].node_s - DP_ST_nodes.col_nodes[col_start].rol_nodes[rol_start].node_s) / n * j;
            double A_t = DP_ST_nodes.col_nodes[col_start].rol_nodes[rol_start].node_t + (DP_ST_nodes.col_nodes[col_end].rol_nodes[rol_end].node_t - DP_ST_nodes.col_nodes[col_start].rol_nodes[rol_start].node_t) / n * j;
            double min_dis; // 时间与l横向距离的平方开根号
            Eigen::Vector2d vec1(obstacle_list_qp_path_sl->obstacles[k].speed_plan_t_in - A_t, obstacle_list_qp_path_sl->obstacles[k].speed_plan_s_in - A_s);
            Eigen::Vector2d vec2(obstacle_list_qp_path_sl->obstacles[k].speed_plan_t_out - obstacle_list_qp_path_sl->obstacles[k].speed_plan_t_in, obstacle_list_qp_path_sl->obstacles[k].speed_plan_s_out - obstacle_list_qp_path_sl->obstacles[k].speed_plan_s_in);
            Eigen::Vector2d vec3(obstacle_list_qp_path_sl->obstacles[k].speed_plan_t_out - A_t, obstacle_list_qp_path_sl->obstacles[k].speed_plan_s_out - A_s);
            double dis_temp1 = sqrt(vec1.dot(vec1));
            double dis_temp2 = abs((vec1(0) * vec2(1) - vec1(1) * vec2(0)) / sqrt(vec2.dot(vec2)));
            double dis_temp3 = sqrt(vec3.dot(vec3));
            if ((vec1.dot(vec2) > 0 && vec3.dot(vec2) > 0) || (vec1.dot(vec2) < 0 && vec3.dot(vec2) < 0))
            {
                min_dis = (dis_temp1 < dis_temp3) ? dis_temp1 : dis_temp3;
            }
            else
            {
                min_dis = dis_temp2;
            }
            cost += Speed_Dp_collision_cost(min_dis);
        }
    }
    return cost;
}

double Speed_Dp_collision_cost(double min_dis)
{
    if (min_dis <= SpeedDpPlanMinObstacleDistance)
    {
        return 1e8;
    }
    else if ( min_dis>SpeedDpPlanMinObstacleDistance && min_dis<= SpeedDpPlanMaxObstacleDistance)
    {
        return 10 * (SpeedDpPlanMaxObstacleDistance - min_dis); // 临时函数，可以调整
    }
    else
    {
        return 0;
    }
}

// 寻找起始点的sl
Eigen::Vector2d Find_start_sl_FirstRun(Eigen::Vector2d host_point, planning_msgs::path_point host_projected_point, int index_match_start)
{
    float planning_start_s, planning_start_l;
    float host_s = host_projected_point.absolute_s;

    Eigen::Vector2d AB(path.points[index_match_start].tor.x, path.points[index_match_start].tor.y);
    Eigen::Vector2d AC(host_point(0) - path.points[index_match_start].x, host_point(1) - path.points[index_match_start].y);
    float host_l;

    Eigen::Vector2d tor_match(path.points[index_match_start].tor.x, path.points[index_match_start].tor.y);
    host_l = -1 * (AC.x() * tor_match.y() - AC.y() * tor_match.x());

    int index_host_to_path = 0;
    int index_host_plan_start_to_path = 0;

    for (int i = 0; i < DP_path_sl.s.size(); i++)
    {
        if (host_s < DP_path_sl.s(i))
        {
            index_host_to_path = i;
            break;
        }
    }

    planning_start_s = host_projected_point.absolute_s;

    planning_start_l = host_l;
    Eigen::Vector2d planning_start(planning_start_s, planning_start_l);
    return planning_start;
}

Eigen::Vector2d Find_start_sl(Eigen::Vector2d host_point, planning_msgs::path_point host_projected_point, int index_match_start)
{
    // index_car_match_points = index2s(path, host_projected_point, index_car_match_points);
    float planning_start_s, planning_start_l;
    float host_s = host_projected_point.absolute_s;

    Eigen::Vector2d AB(path.points[index_match_start].tor.x, path.points[index_match_start].tor.y);
    Eigen::Vector2d AC(host_point(0) - path.points[index_match_start].x, host_point(1) - path.points[index_match_start].y);
    float host_l;

    Eigen::Vector2d tor_match(path.points[index_match_start].tor.x, path.points[index_match_start].tor.y);
    host_l = -1 * (AC.x() * tor_match.y() - AC.y() * tor_match.x());

    int index_host_to_path = 0;
    int index_host_plan_start_to_path = 0;

    for (int i = 0; i < DP_path_sl.s.size(); i++)
    {
        if (host_s < DP_path_sl.s(i))
        {
            index_host_to_path = i;
            break;
        }
    }
    // if (sqrt(pow(host_s - planning_Interpolate_path.s(index_host_to_path), 2) + pow(host_l - planning_Interpolate_path.l(index_host_to_path), 2)) > panning_start_max_error)
    // {
    planning_start_s = host_projected_point.absolute_s;
    // planning_start_l = CrossProduct(AB, AC) * sqrt(pow(host_point(0) - host_projected_point.x, 2) + pow(host_point(1) - host_projected_point.y, 2));
    planning_start_l = host_l;
    Eigen::Vector2d planning_start(planning_start_s, planning_start_l);
    // cout << "host:" << host_s << " ," << host_l << " planning_Interpolate_path:" << planning_Interpolate_path.s(index_host_to_path) << " ," << planning_Interpolate_path.l(index_host_to_path) << endl;
    // cout << "误差：" << sqrt(pow(host_s - planning_Interpolate_path.s(index_host_to_path), 2) + pow(host_l - planning_Interpolate_path.l(index_host_to_path), 2)) << " Replanning!!!" << endl;
    return planning_start;
    // }
    // else
    // {
    //     planning_start_s = host_projected_point.absolute_s + v_planning_start * v_planning_start_dt;
    //     for (int i = index_host_to_path; i < planning_Interpolate_path.s.size(); i++)
    //     {
    //         if (planning_start_s < planning_Interpolate_path.s(i))
    //         {
    //             index_host_plan_start_to_path = i;
    //             break;
    //         }
    //     }
    //     planning_start_l = planning_Interpolate_path.l(index_host_plan_start_to_path);
    //     Eigen::Vector2d planning_start(planning_start_s, planning_start_l);
    //     return planning_start;
    // }
}

// void Plot_SL_Graph(Eigen::Vector2d host_forward_sl, const Frenet_path_points &DP_path_sl, const Frenet_path_points &QP_path_sl)
// {
//     plt::ion();
//     plt::figure(1);
//     plt::clf(); // 清空画布
//     int dp_num = DP_path_sl.s.size();
//     int qp_num = QP_path_sl.s.size();

//     vector<double> local_s_watch;
//     vector<double> local_l_watch;
//     vector<double> local_path_s_left_watch;
//     vector<double> local_path_l_left_watch;
//     vector<double> local_path_s_right_watch;
//     vector<double> local_path_l_right_watch;
//     vector<double> local_path_s_middle_watch;
//     vector<double> local_path_l_middle_watch;
//     std::vector<double> car_pose_s = {host_forward_sl(0), host_forward_sl(0), host_forward_sl(0), host_forward_sl(0) - 4.75, host_forward_sl(0) - 4.75, host_forward_sl(0)};
//     std::vector<double> car_pose_l = {host_forward_sl(1), host_forward_sl(1) - 1, host_forward_sl(1) + 1, host_forward_sl(1) + 1, host_forward_sl(1) - 1, host_forward_sl(1) - 1};

//     std::vector<double> dp_s(dp_num), dp_l(dp_num);
//     std::vector<double> qp_s(qp_num), qp_l(qp_num);

//     std::copy(DP_path_sl.s.data(), DP_path_sl.s.data() + DP_path_sl.s.size(), dp_s.begin());
//     std::copy(DP_path_sl.l.data(), DP_path_sl.l.data() + DP_path_sl.l.size(), dp_l.begin());
//     std::copy(QP_path_sl.s.data(), QP_path_sl.s.data() + QP_path_sl.s.size(), qp_s.begin());
//     std::copy(QP_path_sl.l.data(), QP_path_sl.l.data() + QP_path_sl.l.size(), qp_l.begin());

//     local_s_watch.reserve(2 * dp_num);
//     local_l_watch.reserve(2 * dp_num);
//     local_path_s_left_watch.reserve(2 * dp_num);
//     local_path_l_left_watch.reserve(2 * dp_num);
//     local_path_s_right_watch.reserve(2 * dp_num);
//     local_path_l_right_watch.reserve(2 * dp_num);
//     local_path_s_middle_watch.reserve(2 * dp_num);
//     local_path_l_middle_watch.reserve(2 * dp_num);

//     for (int i = 0; i < obstacle_list->obstacles.size(); i++)
//     {
//         if(obstacle_list->obstacles[i].s>host_forward_sl[0]+50||obstacle_list->obstacles[i].s<host_middle_sl[0])
//             continue;
//         std::vector<double> obs_list_s_watch = {obstacle_list->obstacles[i].max_s, obstacle_list->obstacles[i].max_s, obstacle_list->obstacles[i].min_s, obstacle_list->obstacles[i].min_s, obstacle_list->obstacles[i].max_s};
//         std::vector<double> obs_list_l_watch = {obstacle_list->obstacles[i].max_l, obstacle_list->obstacles[i].min_l, obstacle_list->obstacles[i].min_l, obstacle_list->obstacles[i].max_l, obstacle_list->obstacles[i].max_l};
//         plt::plot(obs_list_s_watch, obs_list_l_watch);
//     }

//     int index_local_path_watch = get_aim_point(40, path, index_middle_Car, true);
//     for (int i = index_middle_Car; i <= index_local_path_watch; i++) // 添加参考线，左右路宽
//     {
//         local_s_watch.push_back(path.points[i].absolute_s);
//         local_l_watch.push_back(0);
//         local_path_s_right_watch.push_back(path.points[i].absolute_s);
//         local_path_l_right_watch.push_back(-2.5);
//         local_path_s_left_watch.push_back(path.points[i].absolute_s);
//         local_path_l_left_watch.push_back(7.5);
//         local_path_s_middle_watch.push_back(path.points[i].absolute_s);
//         local_path_l_middle_watch.push_back(2.5);
//     }

//     // plt::plot(local_s_watch,local_l_watch,"--");

//     plt::named_plot("left_path", local_path_s_left_watch, local_path_l_left_watch, "black");
//     plt::named_plot("right_path", local_path_s_right_watch, local_path_l_right_watch, "black");

//     plt::named_plot("local", local_s_watch, local_l_watch, "--");
//     plt::named_plot("middle", local_path_s_middle_watch, local_path_l_middle_watch, "--");
//     plt::named_plot("Car", car_pose_s, car_pose_l, "red");
//     plt::named_plot("dp", dp_s, dp_l, "blue");
//     plt::named_plot("qp", qp_s, qp_l, "green");
//     plt::ylim(-20, 20);
//     plt::legend();
//     plt::title("SL");
//     plt::pause(0.0000001); // 等待0.001秒，让GUI有机会响应用户交互
//     plt::show();
// }

float CrossProduct(Eigen::Vector2d AB, Eigen::Vector2d A, Eigen::Vector2d C)
{
    float Z; // 判断叉积结果
    Eigen::Vector2d AC = C - A;
    Z = AB.x() * AC.y() - AB.y() * AC.x();
    if (Z >= 0)
    {
        return 1.0;
    }
    else
    {
        return -1.0;
    }
}

float CrossProduct(Eigen::Vector2d AB, Eigen::Vector2d AC)
{
    float Z; // 判断叉积结果
    Z = AB.x() * AC.y() - AB.y() * AC.x();
    if (Z >= 0)
    {
        // cout<<"车在法相量左侧"<<endl;
        return 1.0;
    }
    else
    {
        // cout<<"车在法相量右侧"<<endl;
        return -1.0;
    }
}

/**
 * @description: 计算在frenet坐标系下所有局部路径的点转化为XY坐标系
 * @param {Frenet_path_points} frenet_path_points
 * @param {car_path} path
 * @return {*}
 */
vector<Eigen::Vector2d> FrenetToXY(const Frenet_path_points &frenet_path_points, planning_msgs::car_path &path)
{
    // cout<<"FrenetToXY start"<<endl;
    vector<Eigen::Vector2d> points_XY;
    points_XY.reserve(frenet_path_points.s.size());
    int pre_index2s_id = index_back_Car;
    for (int i = 0; i < frenet_path_points.s.size(); i++)
    {
        planning_msgs::path_point proj_point_;
        planning_msgs::path_point point_xy;

        proj_point_.absolute_s = frenet_path_points.s[i];
        // cout<<"proj_point_.absolute_s :"<<proj_point_.absolute_s <<endl;
        int index_match_points;
        index_match_points = index2s(path, proj_point_, pre_index2s_id);

        proj_point_ = find_projected_point_Frenet(path, index_match_points, frenet_path_points.s[i], frenet_path_points.l[i]);

        Eigen::Vector2d match_point_xy(proj_point_.x, proj_point_.y);
        Eigen::Vector2d point_nor(proj_point_.nor.x, proj_point_.nor.y);   //法相量
        Eigen::Vector2d point_temp_xy = match_point_xy + frenet_path_points.l(i) * point_nor;
        
        pre_index2s_id = index_match_points;

        points_XY.push_back(point_temp_xy);
    }

    // std::cout << "FrenetToXY程序运行时间: " << time_diff << " 秒" << std::endl;
    return points_XY;
}

/**
 * @description: 此函数已知在frenet坐标系下的点找到frenet坐标系下的投影点
 * @param {car_path} &path 全局路径
 * @param {int} index_match_point  匹配点序号
 * @param {Vector2d} host_point 自车坐标
 * @return {*}
 */
planning_msgs::path_point find_projected_point_Frenet(planning_msgs::car_path &path, int index_match_point, float point_s, float point_l)
{
    planning_msgs::path_point projected_point;
    float match_points_x = path.points[index_match_point].x;
    float match_points_y = path.points[index_match_point].y;
    Eigen::Vector2d match_point(match_points_x, match_points_y);
    float match_points_heading = path.points[index_match_point].yaw;
    float match_points_kappa = path.points[index_match_point].kappa;
    float ds = point_s - path.points[index_match_point].absolute_s;
    
    Eigen::Vector2d point_tor(path.points[index_match_point].tor.x, path.points[index_match_point].tor.y);
    Eigen::Vector2d proj_point = match_point + ds * point_tor;
    float proj_points_heading = path.points[index_match_point].yaw + ds * path.points[index_match_point].kappa;
    float proj_points_kappa = path.points[index_match_point].kappa;
    projected_point.x = proj_point(0);
    projected_point.y = proj_point(1);
    projected_point.yaw = proj_points_heading;
    projected_point.tor.x = cos(proj_points_heading);
    projected_point.tor.y = sin(proj_points_heading);
    // cout<<"yaw、torx，tory："<<projected_point.yaw<<","<<projected_point.tor.x<<","<<projected_point.tor.y<<endl;
    projected_point.nor.x = -sin(proj_points_heading);
    projected_point.nor.y = cos(proj_points_heading);
    projected_point.kappa = proj_points_kappa;
    projected_point.absolute_s = point_s;

    return projected_point;
}

/**
 * @description: 此函数在frenet坐标系下找到投影点
 * @param {car_path} &path 全局路径
 * @param {int} index_match_point  匹配点序号
 * @param {Vector2d} host_point 自车坐标
 * @return {*}
 */
planning_msgs::path_point find_projected_point_Frenet(planning_msgs::car_path &path, int index_match_point, Eigen::Vector2d host_point)
{
    planning_msgs::path_point projected_point;

    Eigen::Vector2f vec_d(host_point(0) - path.points[index_match_point].x, host_point(1) - path.points[index_match_point].y);
    Eigen::Vector2f vec_tor(path.points[index_match_point].tor.x, path.points[index_match_point].tor.y);
    Eigen::Vector2f vec_Rm(path.points[index_match_point].x, path.points[index_match_point].y);
    Eigen::Vector2f vec_Rr = vec_Rm + (vec_d.dot(vec_tor)) * vec_tor;
    projected_point.x = vec_Rr(0);
    projected_point.y = vec_Rr(1);
    projected_point.absolute_s = path.points[index_match_point].absolute_s + vec_d.dot(vec_tor);

    projected_point.l = 0; // 此处应该为投影点的l
    // projected_point.yaw = path.points[index_match_point].yaw + path.points[index_match_point].kappa * (vec_d.dot(vec_tor));
    projected_point.yaw = path.points[index_match_point].yaw;
    projected_point.yaw = revise_angle(projected_point.yaw);
    projected_point.tor.x = cos(projected_point.yaw);
    projected_point.tor.y = sin(projected_point.yaw);
    projected_point.kappa = path.points[index_match_point].kappa;
    return projected_point;
}

/**
 * @description: 增密min_path_nodes节点之间的点，相当于对s进行插值,每米20个s点
 * @param {Min_path_nodes} min_path_nodes
 * @return {*} 增密后的s点
 */
Frenet_path_points InterpolatePoints(const Min_path_nodes &min_path_nodes)
{
    Frenet_path_points frenet_path_points;

    int total_points_num = static_cast<int>(std::floor((min_path_nodes.nodes.size() - 1) * sample_s * sample_s_per_meters));
    Eigen::VectorXd ds_(total_points_num);
    Eigen::VectorXd l_(total_points_num);
    Eigen::VectorXd dl_(total_points_num);
    Eigen::VectorXd ddl_(total_points_num);
    Eigen::VectorXd dddl_(total_points_num);

    for (int i = 0; i < min_path_nodes.nodes.size() - 1; i++)
    {
        float start_l = min_path_nodes.nodes[i].node_l;
        float start_dl = 0;
        float start_ddl = 0;
        float end_l = min_path_nodes.nodes[i + 1].node_l;
        float end_dl = 0;
        float end_ddl = 0;
        float start_s = min_path_nodes.nodes[i].node_s;
        float end_s = min_path_nodes.nodes[i + 1].node_s;
        // cout<<i<<" start s l:"<<start_s<<" "<<start_l<<" ,end s l:"<<end_s<<" "<<end_l<<endl;
        // Eigen::VectorXd coeff = CalculateFiveDegreePolynomialCoefficients(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s);
        Eigen::VectorXd coeff = CalculateThreeDegreePolynomialCoefficients(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s);
        float a0 = coeff(0);
        float a1 = coeff(1);
        float a2 = coeff(2);
        float a3 = coeff(3);
        // float a4 = coeff(4);
        // float a5 = coeff(5);
        float points_num_float = sample_s * sample_s_per_meters;
        int points_num = static_cast<int>(std::floor(points_num_float)); // 每米20个点,这里丢掉了终点应该为sample_s * sample_s_per_meters+1

        Eigen::VectorXd I_ = Eigen::VectorXd::Ones(points_num);
        Eigen::VectorXd ds(points_num);
        Eigen::VectorXd l(points_num);
        Eigen::VectorXd dl(points_num);
        Eigen::VectorXd ddl(points_num);
        Eigen::VectorXd dddl(points_num);
        for (int j = 0; j < points_num; j++) // 0.1米一个点
        {
            ds(j) = start_s + j / (points_num_float)*sample_s;
        }
        // l = a0 * I_.array() + a1 * ds.array() + a2 * ds.array().pow(2) + a3 * ds.array().pow(3) + a4 * ds.array().pow(4) + a5 * ds.array().pow(5);
        // dl = a1 * I_.array() + 2 * a2 * ds.array() + 3 * a3 * ds.array().pow(2) + 4 * a4 * ds.array().pow(3) + 5 * a5 * ds.array().pow(4);
        // ddl = 2 * a2 * I_.array() + 6 * a3 * ds.array() + 12 * a4 * ds.array().pow(2) + 20 * a5 * ds.array().pow(3);
        // dddl = 6 * a3 * I_.array() + 24 * a4 * ds.array() + 60 * a5 * ds.array().pow(2);
        l = a0 * I_.array() + a1 * ds.array() + a2 * ds.array().pow(2) + a3 * ds.array().pow(3) ;
        dl = a1 * I_.array() + 2 * a2 * ds.array() + 3 * a3 * ds.array().pow(2) ;
        ddl = 2 * a2 * I_.array() + 6 * a3 * ds.array() ;
        dddl = 6 * a3 * I_.array();

        
        frenet_path_points.s = ds;

        ds_.segment(i * points_num, points_num) = ds;
        l_.segment(i * points_num, points_num) = l;
        dl_.segment(i * points_num, points_num) = dl;
        ddl_.segment(i * points_num, points_num) = ddl;
        dddl_.segment(i * points_num, points_num) = dddl;
    }

    frenet_path_points.s = ds_;
    frenet_path_points.l = l_;
    frenet_path_points.dl = dl_;
    frenet_path_points.ddl = ddl_;
    frenet_path_points.dddl = dddl_;

    return frenet_path_points;
}

/**
 * @description: 计算最小代价的路径节点
 * @param {float} plan_star_s
 * @param {float} plan_star_l
 * @return {*} 返回最小代价的路径节点的sl
 */
Min_path_nodes CalcNodeMinCost(float plan_star_s, float plan_star_l)
{
    clock_t time_start = clock();
    Avoid_nodes avoid_nodes;
    Col_nodes col_node;
    avoid_nodes.nodes.reserve(col_node_num);
    col_node.row_nodes.reserve(row_node_num);
    for (int i = 0; i < row_node_num; i++) // 计算起点与第一列的cost，单独计算
    {
        clock_t time_start001 = clock();
        Single_node single_node;
        float node_s = plan_star_s + sample_s;
        float node_l = ((row_node_num - 1) / 2 - i) * sample_l;
        double cost = CalculateStarCost(plan_star_s, plan_star_l, 0, 0, node_s, node_l);
        single_node.node_s = node_s;
        single_node.node_l = node_l;
        single_node.toThisNodeMinCost = cost;      // 第一列最小cost就是起点到此点 ，不需要判断
        single_node.pre2this_min_cost_index = 0;   // 第一列最小cost序号就是起点 ，不需要判断
        col_node.row_nodes.push_back(single_node); // 将第一列节点加入
    }
    avoid_nodes.nodes.push_back(col_node); // 列加入总节点（未包含原点）

    #pragma omp for
    for (int j = 1; j < col_node_num; j++) // 计算第一列与第最后一列的cost
    {
        Col_nodes col_nodes;
        col_nodes.row_nodes.reserve(row_node_num);
        for (int i = 0; i < row_node_num; i++) // 行
        {
            float node_s = plan_star_s + (j + 1) * sample_s;        // 该节点的s
            float node_l = ((row_node_num - 1) / 2 - i) * sample_l; // 无误 
            double min_cost = std::numeric_limits<double>::max();
            int min_cost_index;
            Single_node sigle_node;
            sigle_node.node_s = node_s;
            sigle_node.node_l = node_l;
            for (int k = 0; k < row_node_num; k++) // 遍历上一列
            {
                double cost = CalculateForwardCost(avoid_nodes.nodes[j - 1].row_nodes[k].node_s, avoid_nodes.nodes[j - 1].row_nodes[k].node_l, node_s, node_l);
                cost = cost + avoid_nodes.nodes[j - 1].row_nodes[k].toThisNodeMinCost;
                if (cost < min_cost)
                {
                    min_cost = cost;
                    min_cost_index = k;
                }
            }
            sigle_node.toThisNodeMinCost = min_cost;
            sigle_node.pre2this_min_cost_index = min_cost_index;
            col_nodes.row_nodes.push_back(sigle_node);
            // cout<<"行:"<<i<<"，列："<<j<<" min_cost:"<<min_cost<<" min_cost_index:"<<min_cost_index<<endl;
        }

        avoid_nodes.nodes.push_back(col_nodes);
    }

    double path_min_cost = std::numeric_limits<double>::max();
    int min_cost_last_index;
    // 寻找全局最小代价路径
    for (int i = 0; i < row_node_num; i++)
    {
        if (avoid_nodes.nodes[col_node_num - 1].row_nodes[i].toThisNodeMinCost < path_min_cost)
        {
            path_min_cost = avoid_nodes.nodes[col_node_num - 1].row_nodes[i].toThisNodeMinCost;
            min_cost_last_index = i;
        }
    }

    // 从后向前遍历
    vector<int> min_cost_index;
    min_cost_index.push_back(min_cost_last_index); // 最优路径最后一列的序号
    for (int i = col_node_num - 1; i > 0; i--)     // 倒序输入
    {
        min_cost_index.push_back(avoid_nodes.nodes[i].row_nodes[min_cost_last_index].pre2this_min_cost_index);
        min_cost_last_index = avoid_nodes.nodes[i].row_nodes[min_cost_last_index].pre2this_min_cost_index;
    }
    std::reverse(min_cost_index.begin(), min_cost_index.end()); // 序号反转，改为正序
    avoid_nodes.min_cost_path_indexs = min_cost_index;

    // for (int i = 0; i < min_cost_index.size(); i++)
    // {
    //     cout<<i<<" node_s:"<<avoid_nodes.nodes[i].row_nodes[min_cost_index[i]].node_s<<" node_l"<<avoid_nodes.nodes[i].row_nodes[min_cost_index[i]].node_l<<endl;;
    // }
    Single_node min_path_node_star;
    Min_path_nodes min_path_nodes;

    min_path_node_star.node_s = plan_star_s; // 加入起点
    min_path_node_star.node_l = plan_star_l;
    min_path_nodes.nodes.push_back(min_path_node_star);

    for (int i = 0; i < min_cost_index.size(); i++)
    {
        Single_node min_path_node;
        min_path_node.node_s = (avoid_nodes.nodes[i].row_nodes[min_cost_index[i]].node_s);
        min_path_node.node_l = (avoid_nodes.nodes[i].row_nodes[min_cost_index[i]].node_l);
        // cout<<"min_path_node_s:"<<min_path_node.node_s<<" l:"<<min_path_node.node_l<<endl;
        min_path_nodes.nodes.push_back(min_path_node);
    }
    return min_path_nodes;
}

double CalculateForwardCost(float pre_node_s, float pre_node_l, float current_node_s, float current_node_l)
{
    // cout<<"CalculateForwardCost_star"<<endl;
    float start_l = pre_node_l;
    float start_dl = 0;
    float start_ddl = 0;
    float end_l = current_node_l;
    float end_dl = 0;
    float end_ddl = 0;
    float start_s = pre_node_s;
    float end_s = current_node_s;
    Eigen::VectorXd coeff = CalculateThreeDegreePolynomialCoefficients(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s);

    float a0 = coeff(0);
    float a1 = coeff(1);
    float a2 = coeff(2);
    float a3 = coeff(3);
    // float a4 = coeff(4);
    // float a5 = coeff(5);

    int points_num = static_cast<int>(std::floor(sample_s * sample_s_num)); // 输出80
    Eigen::VectorXd I_ = Eigen::VectorXd::Ones(points_num);
    Eigen::VectorXd ds = Eigen::VectorXd::LinSpaced(points_num, start_s, start_s + sample_s); // 生成等间距的向量
    Eigen::VectorXd ds_pow2 = ds.array().pow(2);
    Eigen::VectorXd ds_pow3 = ds.array().pow(3);
    // Eigen::VectorXd ds_pow4 = ds.array().pow(4);
    // Eigen::VectorXd ds_pow5 = ds.array().pow(5);

    // Eigen::VectorXd l = a0 * I_ + a1 * ds + a2 * ds_pow2 + a3 * ds_pow3 + a4 * ds_pow4 + a5 * ds_pow5;
    // Eigen::VectorXd dl = a1 * I_ + 2 * a2 * ds + 3 * a3 * ds_pow2 + 4 * a4 * ds_pow3 + 5 * a5 * ds_pow4;
    // Eigen::VectorXd ddl = 2 * a2 * I_ + 6 * a3 * ds + 12 * a4 * ds_pow2 + 20 * a5 * ds_pow3;
    // Eigen::VectorXd dddl = 6 * a3 * I_ + 24 * a4 * ds + 60 * a5 * ds_pow2;

    Eigen::VectorXd l = a0 * I_ + a1 * ds + a2 * ds_pow2 + a3 * ds_pow3;
    Eigen::VectorXd dl = a1 * I_ + 2 * a2 * ds + 3 * a3 * ds_pow2 ;
    Eigen::VectorXd ddl = 2 * a2 * I_ + 6 * a3 * ds ;
    Eigen::VectorXd dddl = 6 * a3 * I_;

    float cost_smooth = w_cost_smooth_dl * dl.squaredNorm() + w_cost_smooth_ddl * ddl.squaredNorm() + w_cost_smooth_dddl * dddl.squaredNorm();

    float cost_ref = w_cost_ref * l.squaredNorm();
    double cost_collision = 0;

    for (int i = 0; i < obstacle_list->obstacles.size(); i++)
    {
        if(obstacle_list->obstacles[i].is_dynamic_obs)
        {
            continue;
        }
        for (int j = 0; j < points_num; j++) // 0.1米一个点
        {
            cost_collision += CalcObstacleCost(obstacle_list->obstacles[i], ds[j], l[j]);
        }
    }
    cost_collision = cost_collision * w_cost_collision;
    double cost_all = 0;
    cost_all = cost_collision + cost_ref + cost_smooth;
    // cout<<"cost_collision:"<<cost_collision<<" cost_ref:"<<cost_ref<<" cost_smooth:"<<cost_smooth<<endl;
    return cost_all;
}

double CalculateStarCost(float begin_s, float begin_l, float begin_dl, float begin_ddl, float end_S, float end_L)
{
    clock_t time_start = clock();
    float start_l = begin_l;
    float start_dl = begin_dl;
    float start_ddl = begin_ddl;
    float end_l = end_L;
    float end_dl = 0;
    float end_ddl = 0;
    float start_s = begin_s;
    float end_s = end_S;
    Eigen::VectorXd coeff = CalculateThreeDegreePolynomialCoefficients(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s);

    float a0 = coeff(0);
    float a1 = coeff(1);
    float a2 = coeff(2);
    float a3 = coeff(3);
    // float a4 = coeff(4);
    // float a5 = coeff(5);

    int points_num = static_cast<int>(std::floor(sample_s * sample_s_num)); // 输出80
    Eigen::VectorXd I_ = Eigen::VectorXd::Ones(points_num);
    Eigen::VectorXd ds = Eigen::VectorXd::LinSpaced(points_num, start_s, start_s + sample_s); // 生成等间距的向量
    Eigen::VectorXd ds_pow2 = ds.array().pow(2);
    Eigen::VectorXd ds_pow3 = ds.array().pow(3);
    // Eigen::VectorXd ds_pow4 = ds.array().pow(4);
    // Eigen::VectorXd ds_pow5 = ds.array().pow(5);

    // Eigen::VectorXd l = a0 * I_ + a1 * ds + a2 * ds_pow2 + a3 * ds_pow3 + a4 * ds_pow4 + a5 * ds_pow5;
    // Eigen::VectorXd dl = a1 * I_ + 2 * a2 * ds + 3 * a3 * ds_pow2 + 4 * a4 * ds_pow3 + 5 * a5 * ds_pow4;
    // Eigen::VectorXd ddl = 2 * a2 * I_ + 6 * a3 * ds + 12 * a4 * ds_pow2 + 20 * a5 * ds_pow3;
    // Eigen::VectorXd dddl = 6 * a3 * I_ + 24 * a4 * ds + 60 * a5 * ds_pow2;

    Eigen::VectorXd l = a0 * I_ + a1 * ds + a2 * ds_pow2 + a3 * ds_pow3;
    Eigen::VectorXd dl = a1 * I_ + 2 * a2 * ds + 3 * a3 * ds_pow2 ;
    Eigen::VectorXd ddl = 2 * a2 * I_ + 6 * a3 * ds ;
    Eigen::VectorXd dddl = 6 * a3 * I_;

    float cost_smooth = w_cost_smooth_dl * dl.squaredNorm() + w_cost_smooth_ddl * ddl.squaredNorm() + w_cost_smooth_dddl * dddl.squaredNorm();
    float cost_ref = w_cost_ref * l.squaredNorm();
    double cost_collision = 0;
    for (int i = 0; i < obstacle_list->obstacles.size(); i++)
    {
        if(obstacle_list->obstacles[i].is_dynamic_obs)
        {
            continue;
        }
        for (int j = 0; j < points_num; j++) // 0.1米一个点
        {
            cost_collision += CalcObstacleCost(obstacle_list->obstacles[i], ds[j], l[j]);
        }
    }

    cost_collision = cost_collision * w_cost_collision;
    double cost_all = 0;
    cost_all = cost_collision + cost_ref + cost_smooth;
    // cout<<"start_cost_collision:"<<cost_collision<<" start_cost_ref:"<<cost_ref<<" start_cost_smooth:"<<cost_smooth<<endl;
    return cost_all;
}

double CalcObstacleCost(planning_msgs::Obstacle &Obstacle_, float aim_s, float aim_l)
{
    double Obstacle_cost = 0;
    float distance0 = sqrt(pow(Obstacle_.s - aim_s, 2) + pow(Obstacle_.l - aim_l, 2));
    float distance1 = distance0+Obstacle_.max_length;
    float distance2 = distance0-Obstacle_.max_length;
    float distance=distance1>distance2?distance2:distance1;
    // cout<<"pow(Obstacle_.sl:"<<Obstacle_.s<<" "<<Obstacle_.l<<" aim_sl:"<<aim_s<<" "<<aim_l<<endl;
    // cout<<"Obstacle_.s:"<<Obstacle_.s<<" Obstacle_.l:"<<Obstacle_.l<<" aim_s:"<<aim_s<<" aim_l:"<<aim_l<<endl;
    // cout<<"Obstacle_.distance:"<<Obstacle_.distance<<endl;
    if (distance >= max_collision_distance)
    {
        return 0;
    }
    else if (distance > min_collision_distance && distance < max_collision_distance)
    {
        Obstacle_cost = 5 / (distance - min_collision_distance + 1e-5);
        return Obstacle_cost;
    }
    else
    {
        Obstacle_cost = 1e10;
        return Obstacle_cost;
    };
    // cout<<"Obstacle_cost:"<<Obstacle_cost<<endl;
    // cout<<"aim_sl:"<<aim_s<<","<<aim_l<<"obstacle_max_min_s:"<<Obstacle_.max_s<<" ,"<<Obstacle_.min_s<<"obstacle_max_min_l:"<<Obstacle_.max_l<<" ,"<<Obstacle_.min_l<<endl;

    // if(aim_s>Obstacle_.min_s&&aim_s<Obstacle_.max_s)
    // {
    //     if((aim_l>Obstacle_.max_l&&aim_l>Obstacle_.min_l) || (aim_l<Obstacle_.max_l&&aim_l<Obstacle_.min_l) )
    //     {
    //         return 0;
    //     }
    //     else
    //     {
    //         Obstacle_cost = 1e10;
    //         return Obstacle_cost;
    //     }
    // }
    // else
    // {
    //     return 0;
    // }
}

/**
 * @description: 求解五次多项式的系数
 * @param {float} star_l
 * @param {float} star_dl l一阶导数
 * @param {float} star_ddl 二阶导数
 * @param {float} end_l
 * @param {float} end_dl
 * @param {float} end_ddl
 * @param {float} star_s
 * @param {float} end_s
 * @return {*} 五次多项式系数
 */
Eigen::VectorXd CalculateFiveDegreePolynomialCoefficients(float start_l, float start_dl, float start_ddl, float end_l, float end_dl, float end_ddl, float start_s, float end_s)
{
    float ss = start_s * start_s;
    float sss = ss * start_s;
    float ssss = sss * start_s;
    float sssss = ssss * start_s;

    float es = end_s * end_s;
    float ess = es * end_s;
    float esss = ess * end_s;
    float essss = esss * end_s;

    Eigen::MatrixXd A(6, 6);
    A << 1, start_s, ss, sss, ssss, sssss,
        0, 1, 2 * start_s, 3 * ss, 4 * sss, 5 * ssss,
        0, 0, 2, 6 * start_s, 12 * ss, 20 * sss,
        1, end_s, es, ess, esss, essss,
        0, 1, 2 * end_s, 3 * es, 4 * ess, 5 * esss,
        0, 0, 2, 6 * end_s, 12 * es, 20 * ess;
    Eigen::VectorXd B(6);
    B << start_l, start_dl, start_ddl, end_l, end_dl, end_ddl;
    // 求解线性方程组
    // 求解线性方程组
    // Eigen::VectorXd x = A.colPivHouseholderQr().solve(B);
    Eigen::VectorXd x = A.fullPivLu().solve(B);
    // 检查矩阵是否满秩，即方程组是否有唯一解
    // if(solver.rank() != A.rows()) {
    //     std::cerr << "矩阵不满秩，可能没有唯一解！" << std::endl;
    //     // 根据实际情况处理，比如返回一个默认解或处理特殊情况
    // }
    
    return x;
}

Eigen::VectorXd CalculateThreeDegreePolynomialCoefficients(float start_l, float start_dl, float start_ddl, float end_l, float end_dl, float end_ddl, float start_s, float end_s)
{
    float ss = start_s * start_s;
    float sss = ss * start_s;

    float es = end_s * end_s;
    float ess = es * end_s;

    Eigen::MatrixXd A(4, 4);
    A << 1, start_s, ss, sss, 
        0, 1, 2 * start_s, 3 * ss, 
        1, end_s, es, ess,
        0, 1, 2 * end_s, 3 * es;
    Eigen::VectorXd B(4);
    B << start_l, start_dl, end_l, end_dl;
    // 求解线性方程组
    // 求解线性方程组
    // Eigen::VectorXd x = A.colPivHouseholderQr().solve(B);
    Eigen::VectorXd x = A.fullPivLu().solve(B);
    // 检查矩阵是否满秩，即方程组是否有唯一解
    // if(solver.rank() != A.rows()) {
    //     std::cerr << "矩阵不满秩，可能没有唯一解！" << std::endl;
    //     // 根据实际情况处理，比如返回一个默认解或处理特殊情况
    // }
    return x;
}


/**
 * @description: 通过优化后的路径来计算航向角
 * @param {VectorXd} QPSolution 优化后路径点
 * @param {vector<float>&} temp_phi 临时存储航向角变量
 * @return {*}
 */
void Calculate_OptimizedPath_Heading(const Eigen::VectorXd &QPSolution, vector<float> &temp_phi)
{

    // 计算航向角(路线斜率) 隔着两个点计算
    for (int i = 0; i < 2 * total_points_num - 12; i += 2)
    {
        float dif_x1 = QPSolution(i + 6) - QPSolution(i);
        float dif_x2 = QPSolution(i + 12) - QPSolution(i + 6);
        float dif_y1 = QPSolution(i + 7) - QPSolution(i + 1);
        float dif_y2 = QPSolution(i + 13) - QPSolution(i + 7);
        float phi_1 = atan2(dif_y1, dif_x1);
        float phi_2 = atan2(dif_y2, dif_x2);
        if (abs(phi_1 - phi_2) > 3.14)
        {
            temp_phi[(i / 2) + 3] = phi_2;
        }
        else if (phi_1 + phi_2 == 0)
        {
            temp_phi[(i / 2) + 3] = temp_phi[(i / 2) + 2];
        }
        else
        {
            temp_phi[(i / 2) + 3] = (phi_1 + phi_2) / 2;
        }
    }
    // temp_phi[0] = temp_phi[3];
    // temp_phi[1] = temp_phi[3];
    // temp_phi[2] = temp_phi[3];
    temp_phi[total_points_num - 1] = temp_phi[total_points_num - 4];
    temp_phi[total_points_num - 2] = temp_phi[total_points_num - 4];
    temp_phi[total_points_num - 3] = temp_phi[total_points_num - 4];
    for (int i = 0; i < 20; i++)// 因为计算出的头部偏航角不稳定和不准确，这里纯属暂时应对方法，应该当全局规划路线换为Astart等后，用多项式求导求出，而不是简单计算！？
    {
        temp_phi[i]=temp_phi[20];
    }
    

    for (int i = 1; i < total_points_num; i++)
    {
        if (temp_phi[i] == 0)
            temp_phi[i] = temp_phi[i - 1];
    }

    line_record_opt->points.reserve(2 * total_points_num);
    for (int i = 0; i < 2 * total_points_num; i += 2)
    {
        pcl::PointXYZI points_;
        points_.x = QPSolution(i);
        points_.y = QPSolution(i + 1);
        points_.z = temp_phi[i / 2];
        // points_.intensity = line_record_->points[i].intensity;
        line_record_opt->push_back(points_);
    }
}

/**
 * @description: 通过优化后的路径来计算航向角
 * @param {VectorXd} QPSolution 优化后路径点
 * @param {vector<float>&} temp_phi 临时存储航向角变量
 * @return {*}
 */
void Calculate_OptimizedPath_Heading(const vector<Eigen::Vector2d> &QPSolution, vector<float> &temp_phi, pcl::PointCloud<pcl::PointXYZI>::Ptr &line_qp_path)
{
    // 计算航向角(路线斜率) 隔着两个点计算
    for (int i = 0; i < QPSolution.size() - 6; i++)
    {
        float dif_x1 = QPSolution[i + 3][0] - QPSolution[i][0];
        float dif_x2 = QPSolution[i + 6][0] - QPSolution[i + 3][0];
        float dif_y1 = QPSolution[i + 3][1] - QPSolution[i][1];
        float dif_y2 = QPSolution[i + 6][1] - QPSolution[i + 3][1];
        float phi_1 = atan2(dif_y1, dif_x1);
        float phi_2 = atan2(dif_y2, dif_x2);
        if (abs(phi_1 - phi_2) > 3.14)
        {
            temp_phi[i + 3] = phi_2;
        }
        else if (phi_1 + phi_2 == 0)
        {
            temp_phi[i + 3] = temp_phi[i + 2];
        }
        else
        {
            temp_phi[i + 3] = (phi_1 + phi_2) / 2;
        }
    }

    temp_phi[0] = temp_phi[3];
    temp_phi[1] = temp_phi[3];
    temp_phi[2] = temp_phi[3];
    temp_phi[QPSolution.size() - 1] = temp_phi[QPSolution.size() - 4];
    temp_phi[QPSolution.size() - 2] = temp_phi[QPSolution.size() - 4];
    temp_phi[QPSolution.size() - 3] = temp_phi[QPSolution.size() - 4];

    for (int i = 1; i < temp_phi.size(); i++)
    {
        if (temp_phi[i] == 0)
            temp_phi[i] = temp_phi[i - 1];
    }

    line_qp_path.reset(new pcl::PointCloud<pcl::PointXYZI>);
    line_qp_path->points.reserve(QPSolution.size());

    for (int i = 0; i < QPSolution.size(); i++)
    {
        pcl::PointXYZI points_;
        points_.x = QPSolution[i][0];
        points_.y = QPSolution[i][1];
        points_.z = temp_phi[i];
        // cout<<i<<" xyz"<<points_.x<<" "<<points_.y<<" "<<points_.z<<endl;
        line_qp_path->push_back(points_);
    }
}

/**
 * @description: 计算路径上的航向角，曲率，切、法向量、速度规划（暂时）
 * @param {car_path} &path  输入路径点
 * @return {*}
 */
void Path_Parameter_Calculate(planning_msgs::car_path &path)
{
    cout << "Path_Parameter_Calculate" << endl;
    // ** 速度规划 ** /
    int num = 0;
    // 第一次push_back到path_points
    path.points.reserve(line_record->points.size() + 1);
    for (pcl::PointCloud<pcl::PointXYZI>::iterator it = line_record->begin(); it != line_record->end(); ++it)
    {
        // cout << "star" << num << endl;
        planning_msgs::path_point point_temp;
        point_temp.number = num;
        num++;
        point_temp.x = (*it).x;
        point_temp.y = (*it).y;
        point_temp.yaw = (*it).z;
        point_temp.theta = (*it).intensity;
        
        path.points.push_back(point_temp);
        // cout << "number,int,vel: " << path.number[num - 1] << " " << path.theta[num - 1] << " " << path.vel[num - 1] << endl;
    }

    // 曲率、ds计算
    float kappa_ = 0;
    path.points[0].ds = 0;
    path.points[0].absolute_s = 0;
    // path.points[0].kappa = 0;

    float calc_s_temp = 0; // 临时变量，用于计算绝对的纵向距离
    for (int i = 1; i != path.points.size(); ++i)
    {
        path.points[i].ds = (sqrt(pow((path.points[i].x - path.points[i - 1].x), 2) + pow((path.points[i].y - path.points[i - 1].y), 2)));
        calc_s_temp += path.points[i].ds;
        path.points[i].absolute_s = calc_s_temp;

        // float delta_angle = abs(path.points[i].yaw - path.points[i - 1].yaw);
        // if (abs(delta_angle) > M_PI)
        // {
        //     delta_angle = 2 * M_PI - abs(path.points[i].yaw) - abs(path.points[i - 1].yaw);
        // }
        // kappa_ = delta_angle / path.points[i].ds;
        // if (abs(kappa_) < 0.001) // 太小置0
        //     kappa_ = 0;
        // if (delta_angle < 0.0001)
        // {
        //     path.points[i].kappa = path.points[i - 1].kappa;
        // }
        // else
        // {
        //     path.points[i].kappa = kappa_;
        // }
    }
    // 曲率计算
    for (int i = 2; i < path.points.size() - 2; ++i)
    {
        float a = sqrt(pow(path.points[i + 2].x - path.points[i].x, 2) + pow(path.points[i + 2].y - path.points[i].y, 2));
        float b = sqrt(pow(path.points[i + 2].x - path.points[i - 2].x, 2) + pow(path.points[i + 2].y - path.points[i - 2].y, 2));
        float c = sqrt(pow(path.points[i].x - path.points[i - 2].x, 2) + pow(path.points[i].y - path.points[i - 2].y, 2));
        float temp_ = (pow(a, 2) + pow(c, 2) - pow(b, 2)) / (2 * a * c);
        if (temp_ > 1)
            temp_ = 1;
        if (temp_ < -1)
            temp_ = -1;
        float theta_b = acos(temp_);
        // cout<<"theta_b:"<<theta_b<<endl;
        path.points[i].kappa = 2 * sin(theta_b) / b;
    }
    path.points[0].kappa = path.points[2].kappa;
    path.points[1].kappa = path.points[2].kappa;
    path.points[path.points.size() - 2].kappa = path.points[path.points.size() - 3].kappa;
    path.points[path.points.size() - 1].kappa = path.points[path.points.size() - 3].kappa;
    // 法向量、切向量初始化
    for (int i = 0; i != path.points.size(); ++i)
    {
        path.points[i].tor.x = cos(path.points[i].yaw);
        path.points[i].tor.y = sin(path.points[i].yaw);
        path.points[i].nor.x = -sin(path.points[i].yaw);
        path.points[i].nor.y = cos(path.points[i].yaw);
    }
    for (int i = 1; i < path.points.size(); i++)
    {
        if (path.points[i].flag_turn == 0 && path.points[i - 1].flag_turn == 1)
        {
            get_front_point_and_setVel(path, i);
        }
    }
}

/**
 * @description: 计算路径上的航向角，曲率，切、法向量、速度规划（暂时）
 * @param {car_path} &path  输入路径点
 * @return {*}
 */
void QP_Path_Publish(planning_msgs::car_path::Ptr &path, pcl::PointCloud<pcl::PointXYZI>::Ptr line_qp_Interpolation)
{
    // ** 速度规划 ** /
    int num = 0;
    // 第一次push_back到path_points
    path->points.reserve(line_qp_Interpolation->points.size() + 1);
    for (pcl::PointCloud<pcl::PointXYZI>::iterator it = line_qp_Interpolation->begin(); it != line_qp_Interpolation->end(); ++it)
    {
        planning_msgs::path_point point_temp;
        point_temp.number = num;
        point_temp.x = (*it).x;
        point_temp.y = (*it).y;
        point_temp.yaw = (*it).z;
        path->points.push_back(point_temp);
        num++;
    }
}

/**
 * @description: 均值插值
 * @param {Ptr} line_record_opt 输入路径点
 * @param {Ptr} line_record 输出插值路径点
 * @return {*}
 */
void Mean_Interpolation(pcl::PointCloud<pcl::PointXYZI>::Ptr line_record_opt, pcl::PointCloud<pcl::PointXYZI>::Ptr line_record)
{
    pcl::PointXYZI points_next;
    line_record->points.reserve(line_record_opt->points.size() * (divide_num + 1));
    for (pcl::PointCloud<pcl::PointXYZI>::iterator it = line_record_opt->begin(); it != line_record_opt->end() - 1; it++)
    {
        line_record->push_back(*it);
        points_next = *(it + 1);
        for (int i = 0; i < divide_num; i++)
        {
            pcl::PointXYZI points;
            points.x = (i + 1) * (points_next.x - it->x) / (divide_num + 1) + it->x;
            points.y = (i + 1) * (points_next.y - it->y) / (divide_num + 1) + it->y;

            if (abs(points_next.z - it->z) > M_PI)
            {
                float abs_delta_z = 2 * M_PI - (abs(points_next.z) + abs(it->z));
                if (it->z > 0)
                {
                    points.z = it->z + (i + 1) * (abs_delta_z) / (divide_num + 1);
                }
                else
                {
                    points.z = it->z - (i + 1) * (abs_delta_z) / (divide_num + 1);
                }
                if (points.z > M_PI)
                {
                    points.z -= 2 * M_PI;
                }
                if (points.z < -M_PI)
                {
                    points.z += 2 * M_PI;
                }
            }
            else
            {
                points.z = (i + 1) * (points_next.z - it->z) / (divide_num + 1) + it->z;
            }
            points.intensity = (i + 1) * (points_next.intensity - it->intensity) / (divide_num + 1) + it->intensity;
            line_record->push_back(points);
        }
    }
    line_record->push_back(points_next);
}

/**
 * @description: 注意要加障碍物判断，否则障碍物太多，其次需要加障碍物信息，判断障碍物四个角点的最大最小sl信息,注意qp_path数量序号要和增密后的dp_path数量一致
 * @param {Obstacle_list} obstacle_list
 * @param {Frenet_path_points} &planning_Interpolate_path
 * @param {VectorXd} &l_min
 * @param {VectorXd} &l_max
 * @param {float} min_l
 * @param {float} max_l
 * @return {*}
 */
void calculatePathBoundary(planning_msgs::ObstacleList::Ptr &obstacle_list, const Frenet_path_points &DP_path_sl, Eigen::VectorXd &l_min, Eigen::VectorXd &l_max, float min_l, float max_l)
{
    // 先判断障碍物决策，并给障碍物打躲避方向标签
    for (int i = 0; i < obstacle_list->obstacles.size(); i++) 
    {
        if(obstacle_list->obstacles[i].is_dynamic_obs) //动态障碍物不考虑
        {
            continue;
        }
        if (obstacle_list->obstacles[i].min_s > DP_path_sl.s.tail(1)(0) || obstacle_list->obstacles[i].max_s < DP_path_sl.s(0))
        {
            continue;
        }
        int index_min = 0;
        int index_middle = 0;
        int index_max = 0;

        for (int j = 0; j < DP_path_sl.s.size(); j++)
        {
            if (obstacle_list->obstacles[i].min_s < DP_path_sl.s(j))
            {
                index_min = j;
                break;
            }
        }
        for (int k = index_min; k < DP_path_sl.s.size(); k++)
        {
            if (obstacle_list->obstacles[i].s < DP_path_sl.s(k))
            {
                index_middle = k;
                break;
            }
        }
        obstacle_list->obstacles[i].index_s_min = index_min;
        for (int k = index_middle; k < DP_path_sl.s.size(); k++)
        {
            if (obstacle_list->obstacles[i].max_s < DP_path_sl.s(k))
            {
                index_max = k;
                break;
            }
        }
        obstacle_list->obstacles[i].index_s_max = index_max;
        if (DP_path_sl.l(index_middle) >= obstacle_list->obstacles[i].l) // 决策向左侧绕
        {
            obstacle_list->obstacles[i].is_left_avoid = true;
        }
        else
        {
            obstacle_list->obstacles[i].is_left_avoid = false;
        }
        // cout<<i<<" index_min:"<<index_min<<" ,"<<index_middle<<" ,"<<index_max<<endl;
    }
    
    //计算qp路径的边界值
    for (int i = 0; i < obstacle_list->obstacles.size(); i++) 
    {
        if(obstacle_list->obstacles[i].is_dynamic_obs)  //动态障碍物不考虑
        {
            continue;
        }
        if (obstacle_list->obstacles[i].min_s > DP_path_sl.s.tail(1)(0) || obstacle_list->obstacles[i].max_s < DP_path_sl.s(0))
        {
            continue;
        }
        if (obstacle_list->obstacles[i].is_left_avoid) // 决策向左侧绕
        {
            float distance = obstacle_list->obstacles[i].max_l + car_width / 2 + safe_distance;
            for (int j = obstacle_list->obstacles[i].index_s_min; j <= obstacle_list->obstacles[i].index_s_max; j++)
            {
                // cout<<"左侧distance="<<distance<<endl;
                if (obstacle_list->obstacles[i].max_l > l_min(j) && ((distance) < l_max(j)))
                {

                    l_min(j) = distance;
                }

            }
            
        }
        else // 决策向右侧绕
        {
            float distance = obstacle_list->obstacles[i].min_l - car_width / 2 - safe_distance;
            for (int j = obstacle_list->obstacles[i].index_s_min; j <= obstacle_list->obstacles[i].index_s_max; j++)
            {
                // cout<<"右侧distance="<<distance<<endl;
                
                if (obstacle_list->obstacles[i].min_l < l_max(j) && (distance > l_min(j)))
                {
                    l_max(j) = distance;
                }
            }
            
        }
    }

    max_watch = l_max;
    min_watch = l_min;
}

/**
 * @description: 参考线平滑算法,其中可以设置x_lb、x_ub、y_ub、y_lb、w设置参数，分别为xy离原始路径的最大误差，w为各个优化权重
 * @param {Ptr} line_record_ 待平滑原始路线
 * @return {*} 求解出的路线
 */
Frenet_path_points cacl_qp_path(float plan_start_s, float plan_start_l, float plan_start_dl, float plan_start_ddl)
{
    double min_l = -1.2;
    double max_l = 2.0;
    float max_dl = 1.0;
    float max_ddl = 1.0;

    int n = static_cast<int>(std::floor(col_node_num * sample_s * sample_s_per_meters)); //6*1.2*20=144
    float delta_s = sample_s*col_node_num/n;

    Eigen::SparseVector<double> qp_path_l(n);
    Eigen::SparseVector<double> qp_path_dl(n);
    Eigen::SparseVector<double> qp_path_ddl(n);
    Eigen::SparseMatrix<double> A(5 * n + 1, 3 * n);
    Eigen::SparseMatrix<double> H(3 * n, 3 * n);
    Eigen::SparseMatrix<double> Aeq_sub(2, 6);
    Eigen::SparseMatrix<double> A_sub(3, 3);

    Eigen::VectorXd f = Eigen::VectorXd::Zero(3 * n, 1);
    Eigen::VectorXd lb = Eigen::VectorXd::Zero(5 * n + 1, 1);
    Eigen::VectorXd ub = Eigen::VectorXd::Zero(5 * n + 1, 1);
    Eigen::VectorXd l_min = Eigen::VectorXd::Constant(n, min_l);
    Eigen::VectorXd l_max = Eigen::VectorXd::Constant(n, max_l);
    calculatePathBoundary(obstacle_list, DP_path_sl, l_min, l_max, min_l, max_l); // 根据障碍物来重新计算边界

    Aeq_sub.reserve(9); // 预分配非零元素空间
    A_sub.reserve(3);
    A.reserve(12 * n - 6);
    H.reserve(3 * n);

    // 设置 Aeq_sub 稀疏矩阵的值
    Aeq_sub.insert(0, 0) = 1;
    Aeq_sub.insert(0, 1) = delta_s;
    Aeq_sub.insert(0, 2) = pow(delta_s, 2) / 3;
    Aeq_sub.insert(0, 3) = -1;
    Aeq_sub.insert(0, 5) = pow(delta_s, 2) / 6;
    Aeq_sub.insert(1, 1) = 1;
    Aeq_sub.insert(1, 2) = delta_s / 2;
    Aeq_sub.insert(1, 4) = -1;
    Aeq_sub.insert(1, 5) = delta_s / 2;

    // 设置 A_sub 稀疏矩阵的值
    A_sub.insert(0, 0) = 1;
    A_sub.insert(1, 1) = 1;
    A_sub.insert(2, 2) = 1;

    // 设置 A 稀疏矩阵的值
    for (int i = 0; i < n; i++)
    {
        A.insert(3 * i, 3 * i) = A_sub.coeff(0, 0);
        A.insert(3 * i + 1, 3 * i + 1) = A_sub.coeff(1, 1);
        A.insert(3 * i + 2, 3 * i + 2) = A_sub.coeff(2, 2);
    }
    for (int i = 0; i < n - 1; i++)
    {
        A.insert(3 * n + 2 * i, 3 * i) = Aeq_sub.coeff(0, 0);
        A.insert(3 * n + 2 * i, 3 * i + 1) = Aeq_sub.coeff(0, 1);
        A.insert(3 * n + 2 * i, 3 * i + 2) = Aeq_sub.coeff(0, 2);
        A.insert(3 * n + 2 * i, 3 * i + 3) = Aeq_sub.coeff(0, 3);
        A.insert(3 * n + 2 * i, 3 * i + 5) = Aeq_sub.coeff(0, 5);
        A.insert(3 * n + 2 * i + 1, 3 * i + 1) = Aeq_sub.coeff(1, 1);
        A.insert(3 * n + 2 * i + 1, 3 * i + 2) = Aeq_sub.coeff(1, 2);
        A.insert(3 * n + 2 * i + 1, 3 * i + 4) = Aeq_sub.coeff(1, 4);
        A.insert(3 * n + 2 * i + 1, 3 * i + 5) = Aeq_sub.coeff(1, 5);
    }
    A.insert(5 * n - 2, 0) = 1;
    A.insert(5 * n - 1, 1) = 1;
    A.insert(5 * n, 2) = 1;

    // 设置 H 稀疏矩阵的值
    for (int i = 0; i < n; i++)
    {
        H.insert(3 * i, 3 * i) = 2 * (w_qp_l + w_qp_ref_dp);
        H.insert(3 * i + 1, 3 * i + 1) = 2 * (w_qp_dl);
        H.insert(3 * i + 2, 3 * i + 2) = 2 * (w_qp_ddl);
        lb(3 * i) = l_min(i);
        lb(3 * i + 1) = -max_dl;
        lb(3 * i + 2) = -max_ddl;
        ub(3 * i) = l_max(i);
        ub(3 * i + 1) = max_dl;
        ub(3 * i + 2) = max_ddl;
        f(3 * i) = -2 * DP_path_sl.l(i) * w_qp_ref_dp;
    }
    lb(5 * n - 2) = plan_start_l;
    ub(5 * n - 2) = plan_start_l;
    lb(5 * n - 1) = plan_start_dl;
    ub(5 * n - 1) = plan_start_dl;
    lb(5 * n) = plan_start_ddl;
    ub(5 * n) = plan_start_ddl;

    A.makeCompressed();
    H.makeCompressed();

    // // osqp求解
    int NumberOfVariables = 3 * n;       // A矩阵的列数
    int NumberOfConstraints = 5 * n + 1; // A矩阵的行数
    // cout << "Path optimization progress --25% " << endl;
    // // 求解部分
    OsqpEigen::Solver solver;

    // // settings
    solver.settings()->setVerbosity(false); // 求解器信息输出控制
    solver.settings()->setWarmStart(true);  // 启用热启动
    // solver.settings()->setInitialGuessX(f); // 设置初始解向量,加速收敛

    // set the initial data of the QP solver
    // 矩阵A为m*n矩阵
    solver.data()->setNumberOfVariables(NumberOfVariables);     // 设置A矩阵的列数，即n
    solver.data()->setNumberOfConstraints(NumberOfConstraints); // 设置A矩阵的行数，即m

    if (!solver.data()->setHessianMatrix(H))
        // return 1; //设置P矩阵
        cout << "error1" << endl;
    if (!solver.data()->setGradient(f))
        // return 1; //设置q or f矩阵。当没有时设置为全0向量
        cout << "error2" << endl;
    if (!solver.data()->setLinearConstraintsMatrix(A))
        // return 1; //设置线性约束的A矩阵
        cout << "error3" << endl;
    if (!solver.data()->setLowerBound(lb))
    { // return 1; //设置下边界
        cout << "error4" << endl;
    }
    if (!solver.data()->setUpperBound(ub))
    { // return 1; //设置上边界
        cout << "error5" << endl;
    }

    // instantiate the solver
    if (!solver.initSolver())
        // return 1;
        cout << "error6" << endl;
    Eigen::VectorXd QPSolution = Eigen::VectorXd::Zero(3 * n);

    // solve the QP problem

    if (!solver.solve())
    {
        QpPathRunningNormally = false;
        cout << "error_slove" << endl;
    }
    else
    {
        QpPathRunningNormally = true;
    }
    // get the controller input
    // clock_t time_start = clock();
    // clock_t time_end = clock();
    // time_start = clock();
    QPSolution = solver.getSolution();
    Eigen::VectorXd s_ = Eigen::VectorXd::Zero(n);
    Eigen::VectorXd l_ = Eigen::VectorXd::Zero(n);
    Eigen::VectorXd dl_ = Eigen::VectorXd::Zero(n);
    Eigen::VectorXd ddl_ = Eigen::VectorXd::Zero(n);
    Eigen::VectorXd dddl_ = Eigen::VectorXd::Zero(n);

    for (int i = 0; i < n; i++)
    {
        s_(i) = plan_start_s + i * delta_s;
        l_(i) = QPSolution(3 * i);
        dl_(i) = QPSolution(3 * i + 1);
        ddl_(i) = QPSolution(3 * i + 2);
    }
    // cout<<"dl_: "<<dl_<<endl;
    // cout<<"ddl_: "<<ddl_<<endl;

    Frenet_path_points qp_path;
    qp_path.s = s_;
    qp_path.l = l_;
    qp_path.dl = dl_;
    qp_path.ddl = ddl_;

    return qp_path;
}

/**
 * @description: 参考线平滑算法,其中可以设置x_lb、x_ub、y_ub、y_lb、w设置参数，分别为xy离原始路径的最大误差，w为各个优化权重
 * @param {Ptr} line_record_ 待平滑原始路线
 * @return {*} 求解出的路线
 */
Eigen::VectorXd Smooth_Reference_Line(pcl::PointCloud<pcl::PointXYZI>::Ptr line_record_)
{
    float x_lb = -0.06; // x限制值
    float x_ub = 0.06;
    float y_ub = 0.06;
    float y_lb = -0.06;

    // float w_smooth = 5;
    // float w_length = 2;
    // float w_ref = 0.000001;
    float w_smooth = 2000;
    float w_length = 2000;
    float w_ref = 0.1;
    int n_total = line_record_->points.size();
    cout<<"num:"<<n_total<<endl;
    Eigen::VectorXd referenceline_x = Eigen::VectorXd::Zero(n_total);
    Eigen::VectorXd referenceline_y = Eigen::VectorXd::Zero(n_total);
    for (int i = 0; i < line_record_->points.size(); i++)
    {
        referenceline_x(i) = line_record_->points[i].x;
        referenceline_y(i) = line_record_->points[i].y;
    }
    cout << "Path optimization progress --10% " << endl;
    Eigen::SparseMatrix<double> A1(2 * n_total - 4, 2 * n_total);
    Eigen::SparseMatrix<double> A2(2 * n_total - 2, 2 * n_total);
    // 创建稀疏矩阵对象
    Eigen::SparseMatrix<double> A3(2 * n_total, 2 * n_total);
    // 遍历对角线上的元素，设置为1
    for (int i = 0; i < 2 * n_total; ++i)
    {
        A3.insert(i, i) = 1.0; // 在(i, i)位置插入1.0
    }
    // 将所有元素插入矩阵中
    A3.makeCompressed();
    Eigen::MatrixXd A_cons = Eigen::MatrixXd::Identity(2 * n_total, 2 * n_total);
    Eigen::MatrixXd H = Eigen::MatrixXd::Zero(2 * n_total, 2 * n_total);
    Eigen::VectorXd f = Eigen::VectorXd::Zero(2 * n_total);

    Eigen::VectorXd lb = Eigen::VectorXd::Zero(2 * n_total);
    Eigen::VectorXd ub = Eigen::VectorXd::Zero(2 * n_total);
    // 限制条件赋值
    for (int i = 0; i < n_total; i++)
    {
        f(2 * i) = referenceline_x(i);
        f(2 * i + 1) = referenceline_y(i);
        lb(2 * i) = f(2 * i) + x_lb;
        ub(2 * i) = f(2 * i) + x_ub;
        lb(2 * i + 1) = f(2 * i + 1) + y_lb;
        ub(2 * i + 1) = f(2 * i + 1) + y_ub;
    }
    // A1赋值
    for (int i = 0; i < 2 * n_total - 4; i++)
    {
        A1.coeffRef(i, i) = 1;
        A1.coeffRef(i, i + 2) = -2;
        A1.coeffRef(i, i + 4) = 1;
    }
    // A2赋值
    for (int i = 0; i < 2 * n_total - 2; i++)
    {
        A2.coeffRef(i, i) = 1;
        A2.coeffRef(i, i + 2) = -1;
    }
    H = 2 * (w_smooth * A1.transpose() * A1 + w_length * A2.transpose() * A2 + w_ref * A3);
    f = -2 * w_ref * f;
    // osqp求解

    int NumberOfVariables = 2 * n_total;   // A矩阵的列数
    int NumberOfConstraints = 2 * n_total; // A矩阵的行数
    cout << "Path optimization progress --25% " << endl;
    // 求解部分
    OsqpEigen::Solver solver;
    Eigen::SparseMatrix<double> H_osqp = H.sparseView(); // 密集矩阵转换为稀疏矩阵
    H_osqp.makeCompressed();                             // 压缩稀疏行 (CSR) 格式
    H_osqp.reserve(H.nonZeros());                        // 预分配非零元素数量
    cout << "Path optimization progress --50% " << endl;
    Eigen::SparseMatrix<double> linearMatrix = A_cons.sparseView();
    linearMatrix.makeCompressed();                 // 压缩稀疏行 (CSR) 格式
    linearMatrix.reserve(linearMatrix.nonZeros()); // 预分配非零元素数量
    // lb_osqp.setConstant(-OsqpEigen::INFTY);
    // ub_osqp.setConstant(+OsqpEigen::INFTY);
    // settings
    solver.settings()->setVerbosity(false); // 求解器信息输出控制
    // solver.settings()->setWarmStart(true); // 启用热启动
    // solver.settings()->setInitialGuessX(f); // 设置初始解向量,加速收敛
    // solver.settings()->setWarmStart(true);

    // set the initial data of the QP solver
    // 矩阵A为m*n矩阵
    solver.data()->setNumberOfVariables(NumberOfVariables);     // 设置A矩阵的列数，即n
    solver.data()->setNumberOfConstraints(NumberOfConstraints); // 设置A矩阵的行数，即m

    if (!solver.data()->setHessianMatrix(H_osqp))
        // return 1; //设置P矩阵
        cout << "error1" << endl;
    if (!solver.data()->setGradient(f))
        // return 1; //设置q or f矩阵。当没有时设置为全0向量
        cout << "error2" << endl;
    if (!solver.data()->setLinearConstraintsMatrix(linearMatrix))
        // return 1; //设置线性约束的A矩阵
        cout << "error3" << endl;
    if (!solver.data()->setLowerBound(lb))
    { // return 1; //设置下边界
        cout << "error4" << endl;
    }
    if (!solver.data()->setUpperBound(ub))
    { // return 1; //设置上边界
        cout << "error5" << endl;
    }

    // instantiate the solver
    if (!solver.initSolver())
        // return 1;
        cout << "error6" << endl;
    Eigen::VectorXd QPSolution;

    // solve the QP problem

    cout << "Path optimization progress --75% " << endl;
    if (!solver.solve())
    {
        cout << "error_slove" << endl;
    }
    // get the controller input
    // clock_t time_start = clock();
    // clock_t time_end = clock();
    // time_start = clock();
    QPSolution = solver.getSolution();
    cout << "Path optimization progress --100% " << endl;
    cout << "Path Optimization Successful!" << endl;
    return QPSolution;
}

/**
 * @description: 此函数在Cartesian坐标系下找到投影点
 * @param {car_path} &path 全局路径
 * @param {int} index_match_point  匹配点序号
 * @param {Vector2d} host_point 自车坐标
 * @return {*}
 */
planning_msgs::path_point find_projected_point_Cartesian(planning_msgs::car_path &path, int index_match_point, planning_msgs::path_point host_point)
{
    planning_msgs::path_point projected_point;

    planning_msgs::path_point match_point = path.points[index_match_point];
    Eigen::Vector2d projected_xy;
    Eigen::Vector2d match_tor(match_point.tor.x, match_point.tor.y);
    Eigen::Vector2d match_xy(match_point.x, match_point.y);
    float ds = host_point.absolute_s - match_point.absolute_s;
    projected_xy = match_xy + ds * match_tor;
    projected_point.x = projected_xy(0);
    projected_point.y = projected_xy(1);

    return projected_point;
}
/**
 * @description: 由绝对s找到匹配点match_points
 * @param {car_path} path 全局路径
 * @param {path_point} point_ 目标点
 * @param {int} star_index 开始序号，默认为0
 * @return {*} 匹配点序号
 */
int index2s(planning_msgs::car_path &path, planning_msgs::path_point point_, int pre_index2s_id)
{
    int star_ = pre_index2s_id;

    for (int i = star_; i < path.points.size() - 1; i++)
    {
        // cout<<"i:"<<i<<" point_.absolute_s:"<<point_.absolute_s<<" path.points[i + 1].absolute_s"<<path.points[i + 1].absolute_s<<" path.points[i].absolute_s"<<path.points[i].absolute_s <<endl;
        if (path.points[i + 1].absolute_s > point_.absolute_s && path.points[i].absolute_s <= point_.absolute_s)
        {
            return i;
        }
    }

    // cout << "到达终点！！！若无到达则为寻找匹配点失败！" << endl;
    return 0;
}

int index2s_r(planning_msgs::car_path &path, planning_msgs::path_point point_, int pre_index2s_id)
{
    int star_ = pre_index2s_id;

    for (int i = star_; i > 0; i--)
    {
        // cout<<"i:"<<i<<" point_.absolute_s:"<<point_.absolute_s<<" path.points[i + 1].absolute_s"<<path.points[i + 1].absolute_s<<" path.points[i].absolute_s"<<path.points[i].absolute_s <<endl;
        if (path.points[i].absolute_s <= point_.absolute_s)
        {
            return i;
        }
    }

    // cout << "到达终点！！！若无到达则为寻找匹配点失败！" << endl;
    return 0;
}

int index2s(planning_msgs::car_path &path, float absolute_s, int pre_index2s_id)
{
    int star_ = pre_index2s_id;

    for (int i = star_; i < path.points.size() - 1; i++)
    {
        if (path.points[i + 1].absolute_s > absolute_s && path.points[i].absolute_s <= absolute_s)
        {
            return i;
        }
    }

    // cout << "到达终点！！！若无到达则为寻找匹配点失败！" << endl;
    return 0;
}

int index2s(const Frenet_path_points &path, float host_s)
{

    for (int i = 0; i < path.s.size(); i++)
    {
        if (path.s[i] >= host_s)
        {
            return i;
        }
    }

    // cout << "到达终点！！！若无到达则为寻找匹配点失败！" << endl;
    return 0;
}

float revise_angle(float angle)
{
    if (angle > 2 * M_PI)
    {
        angle -= 2 * M_PI;
    }
    else if (angle < -2 * M_PI)
    {
        angle += 2 * M_PI;
    }
    else
    {
        return angle;
    }
    return angle;
}

/**
 * @description: 找到最近点的匹配点序号
 * @param {float} x
 * @param {float} y
 * @param {car_path} path_ 路径点信息
 * @param {int} star 默认为0,开始从哪个点寻找   (加速)
 * @param {int} pre_index 默认为0,上个时刻的序号,若使用次加速，star直接置零 （加速）
 * @return {*} 序号点
 */
int get_closest_point(float x, float y, planning_msgs::car_path &path_, int star, int pre_index)
{
    float min_distance = std::numeric_limits<float>::max();
    int index = star;
    int index_forward_point = 0;
    int index_back_point = 0;

    if (pre_index != 0)
    {
        index_forward_point = get_aim_point(4, path_, pre_index, true);
        index_back_point = get_aim_point(4, path_, pre_index, false);
        for (int i = index_back_point; i < index_forward_point; i++)
        {
            float dx = x - path_.points[i].x;
            float dy = y - path_.points[i].y;
            float distance = sqrt(dx * dx + dy * dy);
            if (distance < min_distance)
            {
                min_distance = distance;
                index = i;
            }
        }
        // 终点是否循环判断
        if (index == path_.points.size() - 1)
        {
            float dx = x - path_.points[0].x;
            float dy = y - path_.points[0].y;
            float distance = sqrt(dx * dx + dy * dy);
            if (distance < min_distance)
            {
                min_distance = distance;
                index = 0;
            }
        }
    }
    else if (star != 0)
    {
        index_back_point = get_aim_point(2, path_, star, false);
        for (int i = index_back_point; i < path_.points.size(); i++)
        {
            float dx = x - path_.points[i].x;
            float dy = y - path_.points[i].y;
            float distance = sqrt(dx * dx + dy * dy);
            if (distance < min_distance)
            {
                min_distance = distance;
                index = i;
            }
        }
        // 终点是否循环判断
        if (index == path_.points.size() - 1)
        {
            float dx = x - path_.points[0].x;
            float dy = y - path_.points[0].y;
            float distance = sqrt(dx * dx + dy * dy);
            if (distance < min_distance)
            {
                min_distance = distance;
                index = 0;
            }
        }
    }
    else
    {
        for (int i = 0; i < path_.points.size(); i++)
        {
            float dx = x - path_.points[i].x;
            float dy = y - path_.points[i].y;
            float distance = sqrt(dx * dx + dy * dy);
            if (distance < min_distance)
            {
                // cout<<"distance:"<<distance<<" i:"<<i<<endl;
                min_distance = distance;
                index = i;
            }
        }
    }

    return index;
}

/**
 * @description: 找到最近点的匹配点序号
 * @param {float} x
 * @param {float} y
 * @param {car_path} path_ 路径点信息
 * @param {int} star 默认为0,开始从哪个点寻找   (加速)
 * @param {int} pre_index 默认为0,上个时刻的序号,若使用次加速，star直接置零 （加速）
 * @return {*} 序号点
 */
int get_closest_point(float x, float y, const vector<Eigen::Vector2d> &qp_path_xy)
{
    float min_distance = std::numeric_limits<float>::max();
    int index = 0;

    for (int i = 0; i < qp_path_xy.size(); i++)
    {
        float dx = x - qp_path_xy[i](0);
        float dy = y - qp_path_xy[i](1);
        float distance = sqrt(dx * dx + dy * dy);
        if (distance < min_distance)
        {
            min_distance = distance;
            index = i;
        }
    }

    return index;
}

/**
 * @description:  找到路线中，符合离目标点一定距离的点的下标,distance想要的距离点，begin从那个点开始遍历，sequence顺查，倒查
 * @param {float} distance 想要的距离
 * @param {car_path} path_ 路径点
 * @param {int} begin 从那个点开始遍历
 * @param {bool} sequence 顺查，倒查
 * @return {*}
 */
int get_aim_point(float distance, planning_msgs::car_path &path_, int begin, bool sequence)
{
    float num_dis = 0;
    int index = 0;
    if (sequence)
    {
        for (int i = begin; i < path_.points.size() - 1; i++)
        {
            num_dis += sqrt(pow((path_.points[i + 1].x - path_.points[i].x), 2) + pow((path_.points[i + 1].y - path_.points[i].y), 2));
            if (num_dis >= distance)
            {
                index = i + 1;
                break;
            }
        }
        if (num_dis < distance)
        {
            index = path_.points.size() - 1;
        }
        return index;
    }
    else
    {
        for (int i = begin; i > 0; i--)
        {
            num_dis += sqrt(pow((path_.points[i].x - path_.points[i - 1].x), 2) + pow((path_.points[i].y - path_.points[i - 1].y), 2));
            if (num_dis >= distance)
            {
                index = i - 1;
                break;
            }
        }
        if (num_dis < distance)
        {
            index = 0;
        }
        return index;
    }
}

void get_back_point_and_setVel(planning_msgs::car_path &path_, int begin)
{
    float num_dis = 0;
    int index = 0;
    float star_slow_num = 0;
    float end_slow_num = 0;

    for (int i = begin; i > 0; i--)
    {
        num_dis += sqrt(pow((path_.points[i].x - path_.points[i - 1].x), 2) + pow((path_.points[i].y - path_.points[i - 1].y), 2));
        if (num_dis <= end_slow_distance)
        {
            end_slow_num = i;
        }
        if (num_dis > star_slow_distance)
        {
            star_slow_num = i;
            break;
        }
    }

    for (int i = begin; i > 0; i--)
    {
        if (i >= end_slow_num)
        {
            path_.points[i].vel = V_turn;
            if (path_.points[begin].theta > 0)
            {
                path.points[i].flag_right_turn = 0;
                path.points[i].flag_left_turn = 1;
            }
            else
            {
                path.points[i].flag_right_turn = 1;
                path.points[i].flag_left_turn = 0;
            }
            // cout << "number_test:" << i << endl;
        }
        else if (i < end_slow_num && i >= star_slow_num)
        {
            path_.points[i].vel = V_turn + (V_straight - V_turn) / (end_slow_num - star_slow_num) * (end_slow_num - i);
            if (path_.points[begin].theta > 0)
            {
                path.points[i].flag_right_turn = 0;
                path.points[i].flag_left_turn = 1;
            }
            else
            {
                path.points[i].flag_right_turn = 1;
                path.points[i].flag_left_turn = 0;
            }
            // cout << "number_test:" << i << endl;
        }
        else
        {
            break;
        }
    }
    flag_V_slow = false;
}

void get_back_point_and_setVel2(planning_msgs::car_path &path_, int begin)
{
    float num_dis = 0;
    int index = 0;
    float star_slow_num = 0;
    float end_slow_num = 0;

    for (int i = begin; i > 0; i--)
    {
        num_dis += path_.points[i].ds;
        if (num_dis >= end_slow_distance)
        {
            end_slow_num = i;
            break;
        }
    }

    for (int i = end_slow_num; i > 0; i--)
    {
        num_dis += path_.points[i].ds;
        if (num_dis >= star_slow_distance)
        {
            star_slow_num = i;
            break;
        }
    }

    for (int i = begin; i > 0; i--)
    {
        if (i >= end_slow_num)
        {
            path_.points[i].vel = V_turn;
            if (path_.points[begin].theta > 0)
            {
                path.points[i].flag_right_turn = 0;
                path.points[i].flag_left_turn = 1;
            }
            else
            {
                path.points[i].flag_right_turn = 1;
                path.points[i].flag_left_turn = 0;
            }
            // cout << "number_test:" << i << endl;
        }
        else if (i < end_slow_num && i >= star_slow_num)
        {
            path_.points[i].vel = V_turn + (V_straight - V_turn) / (end_slow_num - star_slow_num) * (end_slow_num - i);
            if (path_.points[begin].theta > 0)
            {
                path.points[i].flag_right_turn = 0;
                path.points[i].flag_left_turn = 1;
            }
            else
            {
                path.points[i].flag_right_turn = 1;
                path.points[i].flag_left_turn = 0;
            }
            // cout << "number_test:" << i << endl;
        }
        else
        {
            break;
        }
    }
    flag_V_slow = false;
}

void get_front_point_and_setVel(planning_msgs::car_path &path_, int begin)
{
    float num_dis = 0;
    float star_speed_num = 0;
    float end_speed_num = 0;
    int index = 0;

    for (int i = begin; i < path_.points.size() - 1; i++)
    {
        num_dis += sqrt(pow((path_.points[i].x - path_.points[i + 1].x), 2) + pow((path_.points[i].y - path_.points[i + 1].y), 2));
        if (num_dis <= star_speed_distance)
        {
            star_speed_num = i;
        }
        else if (num_dis > end_speed_distance)
        {
            end_speed_num = i;
            break;
        }
    }
    for (int i = begin; i < path_.points.size() - 1; i++)
    {
        if (i <= star_speed_num)
        {
            path_.points[i].vel = V_turn;
            // cout << "number_test:" << i << endl;
        }
        else if (i > star_speed_num && i <= end_speed_num)
        {
            path_.points[i].vel = V_turn + (V_straight - V_turn) / (end_speed_num - star_speed_num) * (i - star_speed_num);
        }
    }
}

Min_path_nodes CalcDpPathNodeMinCost_reverse(float plan_star_s, float plan_star_l)
{
    Avoid_nodes avoid_nodes;
    Col_nodes col_node;
    avoid_nodes.nodes.reserve(col_node_num_reverse);
    col_node.row_nodes.reserve(row_node_num_reverse);
    for (int i = 0; i < row_node_num_reverse; i++) // 计算起点与第一列的cost，单独计算
    {
        Single_node single_node;
        float node_s = plan_star_s + sample_s_reverse;
        float node_l = ((row_node_num_reverse - 1) / 2 - i) * sample_l_reverse;
        double cost = CalculateDpPathStarCost_reverse(plan_star_s, plan_star_l, 0, 0, node_s, node_l);
        single_node.node_s = node_s;
        single_node.node_l = node_l;
        single_node.toThisNodeMinCost = cost;      // 第一列最小cost就是起点到此点 ，不需要判断
        single_node.pre2this_min_cost_index = 0;   // 第一列最小cost序号就是起点 ，不需要判断
        col_node.row_nodes.push_back(single_node); // 将第一列节点加入
    }
    avoid_nodes.nodes.push_back(col_node); // 列加入总节点（未包含原点）

#pragma omp for
    for (int j = 1; j < col_node_num_reverse; j++) // 计算第一列与第最后一列的cost
    {
        Col_nodes col_nodes;
        col_nodes.row_nodes.reserve(row_node_num_reverse);
        for (int i = 0; i < row_node_num_reverse; i++) // 行
        {
            float node_s = plan_star_s + (j + 1) * sample_s_reverse;                // 该节点的s
            float node_l = ((row_node_num_reverse - 1) / 2 - i) * sample_l_reverse; // 无误
            double min_cost = std::numeric_limits<double>::max();
            int min_cost_index;
            Single_node sigle_node;
            sigle_node.node_s = node_s;
            sigle_node.node_l = node_l;
            for (int k = 0; k < row_node_num_reverse; k++) // 遍历上一列
            {
                double cost = CalculateDpPathForwardCost_reverse(avoid_nodes.nodes[j - 1].row_nodes[k].node_s, avoid_nodes.nodes[j - 1].row_nodes[k].node_l, node_s, node_l);
                cost = cost + avoid_nodes.nodes[j - 1].row_nodes[k].toThisNodeMinCost;
                if (cost < min_cost)
                {
                    min_cost = cost;
                    min_cost_index = k;
                }
            }
            sigle_node.toThisNodeMinCost = min_cost;
            sigle_node.pre2this_min_cost_index = min_cost_index;
            col_nodes.row_nodes.push_back(sigle_node);
            // cout<<"行:"<<i<<"，列："<<j<<" min_cost:"<<min_cost<<" min_cost_index:"<<min_cost_index<<endl;
        }

        avoid_nodes.nodes.push_back(col_nodes);
    }

    double path_min_cost = std::numeric_limits<double>::max();
    int min_cost_last_index;
    // 寻找全局最小代价路径
    for (int i = 0; i < row_node_num_reverse; i++)
    {
        if (avoid_nodes.nodes[col_node_num_reverse - 1].row_nodes[i].toThisNodeMinCost < path_min_cost)
        {
            path_min_cost = avoid_nodes.nodes[col_node_num_reverse - 1].row_nodes[i].toThisNodeMinCost;
            min_cost_last_index = i;
        }
    }

    // 从后向前遍历
    vector<int> min_cost_index;
    min_cost_index.push_back(min_cost_last_index);     // 最优路径最后一列的序号
    for (int i = col_node_num_reverse - 1; i > 0; i--) // 倒序输入
    {
        min_cost_index.push_back(avoid_nodes.nodes[i].row_nodes[min_cost_last_index].pre2this_min_cost_index);
        min_cost_last_index = avoid_nodes.nodes[i].row_nodes[min_cost_last_index].pre2this_min_cost_index;
    }
    std::reverse(min_cost_index.begin(), min_cost_index.end()); // 序号反转，改为正序
    avoid_nodes.min_cost_path_indexs = min_cost_index;

    // for (int i = 0; i < min_cost_index.size(); i++)
    // {
    //     cout<<i<<" node_s:"<<avoid_nodes.nodes[i].row_nodes[min_cost_index[i]].node_s<<" node_l"<<avoid_nodes.nodes[i].row_nodes[min_cost_index[i]].node_l<<endl;;
    // }
    Single_node min_path_node_star;
    Min_path_nodes min_path_nodes;

    min_path_node_star.node_s = plan_star_s; // 加入起点
    min_path_node_star.node_l = plan_star_l;
    min_path_nodes.nodes.push_back(min_path_node_star);

    for (int i = 0; i < min_cost_index.size(); i++)
    {
        Single_node min_path_node;
        min_path_node.node_s = (avoid_nodes.nodes[i].row_nodes[min_cost_index[i]].node_s);
        min_path_node.node_l = (avoid_nodes.nodes[i].row_nodes[min_cost_index[i]].node_l);
        // cout<<"min_path_node_s:"<<min_path_node.node_s<<" l:"<<min_path_node.node_l<<endl;
        min_path_nodes.nodes.push_back(min_path_node);
    }
    return min_path_nodes;
}

Frenet_path_points calcQpPath_reverse(float plan_start_s, float plan_start_l, float plan_start_dl, float plan_start_ddl)
{

    double min_l = -2;
    double max_l = 2;
    float max_dl = 1;
    float max_ddl = 1;

    int n = static_cast<int>(std::floor(col_node_num_reverse * abs(sample_s_reverse) * sample_s_per_meters)); // 6*1.2*20=144
    float delta_s = sample_s_reverse * col_node_num / n;                                              // 这里暂时不清楚-s是否正确！？
    Eigen::SparseVector<double> qp_path_l(n);
    Eigen::SparseVector<double> qp_path_dl(n);
    Eigen::SparseVector<double> qp_path_ddl(n);
    Eigen::SparseMatrix<double> A(5 * n + 1, 3 * n);
    Eigen::SparseMatrix<double> H(3 * n, 3 * n);
    Eigen::SparseMatrix<double> Aeq_sub(2, 6);
    Eigen::SparseMatrix<double> A_sub(3, 3);

    Eigen::VectorXd f = Eigen::VectorXd::Zero(3 * n, 1);
    Eigen::VectorXd lb = Eigen::VectorXd::Zero(5 * n + 1, 1);
    Eigen::VectorXd ub = Eigen::VectorXd::Zero(5 * n + 1, 1);
    Eigen::VectorXd l_min = Eigen::VectorXd::Constant(n, min_l);
    Eigen::VectorXd l_max = Eigen::VectorXd::Constant(n, max_l);
    
    calculatePathBoundary(obstacle_list, DP_path_sl_r, l_min, l_max, min_l, max_l); // 根据障碍物来重新计算边界
    Aeq_sub.reserve(9); // 预分配非零元素空间
    A_sub.reserve(3);
    A.reserve(12 * n - 6);
    H.reserve(3 * n);

    // 设置 Aeq_sub 稀疏矩阵的值
    Aeq_sub.insert(0, 0) = 1;
    Aeq_sub.insert(0, 1) = delta_s;
    Aeq_sub.insert(0, 2) = pow(delta_s, 2) / 3;
    Aeq_sub.insert(0, 3) = -1;
    Aeq_sub.insert(0, 5) = pow(delta_s, 2) / 6;
    Aeq_sub.insert(1, 1) = 1;
    Aeq_sub.insert(1, 2) = delta_s / 2;
    Aeq_sub.insert(1, 4) = -1;
    Aeq_sub.insert(1, 5) = delta_s / 2;

    // 设置 A_sub 稀疏矩阵的值
    A_sub.insert(0, 0) = 1;
    A_sub.insert(1, 1) = 1;
    A_sub.insert(2, 2) = 1;
    // 设置 A 稀疏矩阵的值
    for (int i = 0; i < n; i++)
    {
        A.insert(3 * i, 3 * i) = A_sub.coeff(0, 0);
        A.insert(3 * i + 1, 3 * i + 1) = A_sub.coeff(1, 1);
        A.insert(3 * i + 2, 3 * i + 2) = A_sub.coeff(2, 2);
    }
    for (int i = 0; i < n - 1; i++)
    {
        A.insert(3 * n + 2 * i, 3 * i) = Aeq_sub.coeff(0, 0);
        A.insert(3 * n + 2 * i, 3 * i + 1) = Aeq_sub.coeff(0, 1);
        A.insert(3 * n + 2 * i, 3 * i + 2) = Aeq_sub.coeff(0, 2);
        A.insert(3 * n + 2 * i, 3 * i + 3) = Aeq_sub.coeff(0, 3);
        A.insert(3 * n + 2 * i, 3 * i + 5) = Aeq_sub.coeff(0, 5);
        A.insert(3 * n + 2 * i + 1, 3 * i + 1) = Aeq_sub.coeff(1, 1);
        A.insert(3 * n + 2 * i + 1, 3 * i + 2) = Aeq_sub.coeff(1, 2);
        A.insert(3 * n + 2 * i + 1, 3 * i + 4) = Aeq_sub.coeff(1, 4);
        A.insert(3 * n + 2 * i + 1, 3 * i + 5) = Aeq_sub.coeff(1, 5);
    }
    A.insert(5 * n - 2, 0) = 1;
    A.insert(5 * n - 1, 1) = 1;
    A.insert(5 * n, 2) = 1;

    // 设置 H 稀疏矩阵的值
    for (int i = 0; i < n; i++)
    {

        H.insert(3 * i, 3 * i) = 2 * (w_qp_l + w_qp_ref_dp);
        
        H.insert(3 * i + 1, 3 * i + 1) = 2 * (w_qp_dl);
        H.insert(3 * i + 2, 3 * i + 2) = 2 * (w_qp_ddl);
        lb(3 * i) = l_min(i);
        lb(3 * i + 1) = -max_dl;
        lb(3 * i + 2) = -max_ddl;
        
        ub(3 * i) = l_max(i);
        
        ub(3 * i + 1) = max_dl;
        
        ub(3 * i + 2) = max_ddl;
        

        f(3 * i) = -2 * DP_path_sl.l(i) * w_qp_ref_dp;

    }
   
    lb(5 * n - 2) = plan_start_l;
    ub(5 * n - 2) = plan_start_l;
    lb(5 * n - 1) = plan_start_dl;
    ub(5 * n - 1) = plan_start_dl;
    lb(5 * n) = plan_start_ddl;
    ub(5 * n) = plan_start_ddl;
    
    A.makeCompressed();
    H.makeCompressed();

    // // osqp求解
    int NumberOfVariables = 3 * n;       // A矩阵的列数
    int NumberOfConstraints = 5 * n + 1; // A矩阵的行数
    // cout << "Path optimization progress --25% " << endl;
    // // 求解部分
    OsqpEigen::Solver solver;

    // // settings
    solver.settings()->setVerbosity(false); // 求解器信息输出控制
    solver.settings()->setWarmStart(true);  // 启用热启动
    // solver.settings()->setInitialGuessX(f); // 设置初始解向量,加速收敛

    // set the initial data of the QP solver
    // 矩阵A为m*n矩阵
    solver.data()->setNumberOfVariables(NumberOfVariables);     // 设置A矩阵的列数，即n
    solver.data()->setNumberOfConstraints(NumberOfConstraints); // 设置A矩阵的行数，即m

    if (!solver.data()->setHessianMatrix(H))
        // return 1; //设置P矩阵
        cout << "error1" << endl;
    if (!solver.data()->setGradient(f))
        // return 1; //设置q or f矩阵。当没有时设置为全0向量
        cout << "error2" << endl;
    if (!solver.data()->setLinearConstraintsMatrix(A))
        // return 1; //设置线性约束的A矩阵
        cout << "error3" << endl;
    if (!solver.data()->setLowerBound(lb))
    { // return 1; //设置下边界
        cout << "error4" << endl;
    }
    if (!solver.data()->setUpperBound(ub))
    { // return 1; //设置上边界
        cout << "error5" << endl;
    }

    // instantiate the solver
    if (!solver.initSolver())
        // return 1;
        cout << "error6" << endl;
    Eigen::VectorXd QPSolution = Eigen::VectorXd::Zero(3 * n);
    // solve the QP problem

    if (!solver.solve())
    {
        reverseQpPathRunningNormally = false;
        cout << "error_slove" << endl;
    }
    else
    {
        reverseQpPathRunningNormally = true;
    }
    // get the controller input
    // clock_t time_start = clock();
    // clock_t time_end = clock();
    // time_start = clock();
    QPSolution = solver.getSolution();
    Eigen::VectorXd s_ = Eigen::VectorXd::Zero(n);
    Eigen::VectorXd l_ = Eigen::VectorXd::Zero(n);
    Eigen::VectorXd dl_ = Eigen::VectorXd::Zero(n);
    Eigen::VectorXd ddl_ = Eigen::VectorXd::Zero(n);
    Eigen::VectorXd dddl_ = Eigen::VectorXd::Zero(n);

    for (int i = 0; i < n; i++)
    {
        s_(i) = plan_start_s + i * delta_s;
        l_(i) = QPSolution(3 * i);
        dl_(i) = QPSolution(3 * i + 1);
        ddl_(i) = QPSolution(3 * i + 2);
    }
    // cout<<"dl_: "<<dl_<<endl;
    // cout<<"ddl_: "<<ddl_<<endl;
 
    Frenet_path_points qp_path;
    qp_path.s = s_;
    qp_path.l = l_;
    qp_path.dl = dl_;
    qp_path.ddl = ddl_;

    return qp_path;
}

/**
 * @description: 通过优化后的路径来计算航向角
 * @param {VectorXd} QPSolution 优化后路径点
 * @param {vector<float>&} temp_phi 临时存储航向角变量
 * @return {*}
 */
void Calculate_OptimizedPath_Heading_reverse(const vector<Eigen::Vector2d> &QPSolution, vector<float> &temp_phi, pcl::PointCloud<pcl::PointXYZI>::Ptr &line_qp_path)
{
    // 计算航向角(路线斜率) 隔着两个点计算
    for (int i = 0; i < QPSolution.size() - 6; i++)
    {
        //这里计算反向偏航角度
        float dif_x1 = QPSolution[i][0] - QPSolution[i + 3][0];
        float dif_x2 = QPSolution[i + 3][0] - QPSolution[i + 6][0];
        float dif_y1 = QPSolution[i][1] - QPSolution[i + 3][1];
        float dif_y2 = QPSolution[i + 3][1] - QPSolution[i + 6][1];
        float phi_1 = atan2(dif_y1, dif_x1);
        float phi_2 = atan2(dif_y2, dif_x2);
        if (abs(phi_1 - phi_2) > 3.14)
        {
            temp_phi[i + 3] = phi_2;
        }
        else if (phi_1 + phi_2 == 0)
        {
            temp_phi[i + 3] = temp_phi[i + 2];
        }
        else
        {
            temp_phi[i + 3] = (phi_1 + phi_2) / 2;
        }
    }

    temp_phi[0] = temp_phi[3];
    temp_phi[1] = temp_phi[3];
    temp_phi[2] = temp_phi[3];
    temp_phi[QPSolution.size() - 1] = temp_phi[QPSolution.size() - 4];
    temp_phi[QPSolution.size() - 2] = temp_phi[QPSolution.size() - 4];
    temp_phi[QPSolution.size() - 3] = temp_phi[QPSolution.size() - 4];

    for (int i = 1; i < temp_phi.size(); i++)
    {
        if (temp_phi[i] == 0)
            temp_phi[i] = temp_phi[i - 1];
    }

    line_qp_path.reset(new pcl::PointCloud<pcl::PointXYZI>);
    line_qp_path->points.reserve(QPSolution.size());

    for (int i = 0; i < QPSolution.size(); i++)
    {
        pcl::PointXYZI points_;
        points_.x = QPSolution[i][0];
        points_.y = QPSolution[i][1];
        points_.z = temp_phi[i];
        // cout<<i<<" xyz"<<points_.x<<" "<<points_.y<<" "<<points_.z<<endl;
        line_qp_path->push_back(points_);
    }
}


/**
 * @description: 增密min_path_nodes节点之间的点，相当于对s进行插值,每米20个s点
 * @param {Min_path_nodes} min_path_nodes
 * @return {*} 增密后的s点
 */
Frenet_path_points InterpolateDpPathPoints_reverse(const Min_path_nodes &min_path_nodes)
{
    Frenet_path_points frenet_path_points;
    int total_points_num = static_cast<int>(std::floor((min_path_nodes.nodes.size() - 1) * abs(sample_s_reverse) * sample_s_per_meters));
    Eigen::VectorXd ds_(total_points_num);
    Eigen::VectorXd l_(total_points_num);
    Eigen::VectorXd dl_(total_points_num);
    Eigen::VectorXd ddl_(total_points_num);
    Eigen::VectorXd dddl_(total_points_num);

    for (int i = 0; i < min_path_nodes.nodes.size() - 1; i++)
    {
        float start_l = min_path_nodes.nodes[i].node_l;
        float start_dl = 0;
        float start_ddl = 0;
        float end_l = min_path_nodes.nodes[i + 1].node_l;
        float end_dl = 0;
        float end_ddl = 0;
        float start_s = min_path_nodes.nodes[i].node_s;
        float end_s = min_path_nodes.nodes[i + 1].node_s;
        // cout<<i<<" start s l:"<<start_s<<" "<<start_l<<" ,end s l:"<<end_s<<" "<<end_l<<endl;
        // Eigen::VectorXd coeff = CalculateFiveDegreePolynomialCoefficients(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s);
        Eigen::VectorXd coeff = CalculateThreeDegreePolynomialCoefficients(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s);
        float a0 = coeff(0);
        float a1 = coeff(1);
        float a2 = coeff(2);
        float a3 = coeff(3);
        // float a4 = coeff(4);
        // float a5 = coeff(5);
        float points_num_float = abs(sample_s_reverse) * sample_s_per_meters;
        int points_num = static_cast<int>(std::floor(points_num_float)); // 每米20个点,这里丢掉了终点应该为sample_s * sample_s_per_meters+1

        Eigen::VectorXd I_ = Eigen::VectorXd::Ones(points_num);
        Eigen::VectorXd ds(points_num);
        Eigen::VectorXd l(points_num);
        Eigen::VectorXd dl(points_num);
        Eigen::VectorXd ddl(points_num);
        Eigen::VectorXd dddl(points_num);
        for (int j = 0; j < points_num; j++) // 0.1米一个点
        {
            ds(j) = start_s + j / (points_num_float)*sample_s_reverse;
        }
        // l = a0 * I_.array() + a1 * ds.array() + a2 * ds.array().pow(2) + a3 * ds.array().pow(3) + a4 * ds.array().pow(4) + a5 * ds.array().pow(5);
        // dl = a1 * I_.array() + 2 * a2 * ds.array() + 3 * a3 * ds.array().pow(2) + 4 * a4 * ds.array().pow(3) + 5 * a5 * ds.array().pow(4);
        // ddl = 2 * a2 * I_.array() + 6 * a3 * ds.array() + 12 * a4 * ds.array().pow(2) + 20 * a5 * ds.array().pow(3);
        // dddl = 6 * a3 * I_.array() + 24 * a4 * ds.array() + 60 * a5 * ds.array().pow(2);
        l = a0 * I_.array() + a1 * ds.array() + a2 * ds.array().pow(2) + a3 * ds.array().pow(3);
        dl = a1 * I_.array() + 2 * a2 * ds.array() + 3 * a3 * ds.array().pow(2);
        ddl = 2 * a2 * I_.array() + 6 * a3 * ds.array();
        dddl = 6 * a3 * I_.array();

        frenet_path_points.s = ds;

        ds_.segment(i * points_num, points_num) = ds;
        l_.segment(i * points_num, points_num) = l;
        dl_.segment(i * points_num, points_num) = dl;
        ddl_.segment(i * points_num, points_num) = ddl;
        dddl_.segment(i * points_num, points_num) = dddl;
    }

    frenet_path_points.s = ds_;
    frenet_path_points.l = l_;
    frenet_path_points.dl = dl_;
    frenet_path_points.ddl = ddl_;
    frenet_path_points.dddl = dddl_;

    return frenet_path_points;
}

double CalculateDpPathForwardCost_reverse(float pre_node_s, float pre_node_l, float current_node_s, float current_node_l)
{
    // cout<<"CalculateForwardCost_star"<<endl;

    float start_l = pre_node_l;
    float start_dl = 0;
    float start_ddl = 0;
    float end_l = current_node_l;
    float end_dl = 0;
    float end_ddl = 0;
    float start_s = pre_node_s;
    float end_s = current_node_s;
    Eigen::VectorXd coeff = CalculateThreeDegreePolynomialCoefficients(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s);

    float a0 = coeff(0);
    float a1 = coeff(1);
    float a2 = coeff(2);
    float a3 = coeff(3);
    // float a4 = coeff(4);
    // float a5 = coeff(5);

    int points_num = static_cast<int>(std::floor(abs(sample_s_reverse) * sample_s_num)); // 输出80
    Eigen::VectorXd I_ = Eigen::VectorXd::Ones(points_num);
    Eigen::VectorXd ds = Eigen::VectorXd::LinSpaced(points_num, start_s, start_s + sample_s_reverse); // 生成等间距的向量
    Eigen::VectorXd ds_pow2 = ds.array().pow(2);
    Eigen::VectorXd ds_pow3 = ds.array().pow(3);
    // Eigen::VectorXd ds_pow4 = ds.array().pow(4);
    // Eigen::VectorXd ds_pow5 = ds.array().pow(5);

    // Eigen::VectorXd l = a0 * I_ + a1 * ds + a2 * ds_pow2 + a3 * ds_pow3 + a4 * ds_pow4 + a5 * ds_pow5;
    // Eigen::VectorXd dl = a1 * I_ + 2 * a2 * ds + 3 * a3 * ds_pow2 + 4 * a4 * ds_pow3 + 5 * a5 * ds_pow4;
    // Eigen::VectorXd ddl = 2 * a2 * I_ + 6 * a3 * ds + 12 * a4 * ds_pow2 + 20 * a5 * ds_pow3;
    // Eigen::VectorXd dddl = 6 * a3 * I_ + 24 * a4 * ds + 60 * a5 * ds_pow2;

    Eigen::VectorXd l = a0 * I_ + a1 * ds + a2 * ds_pow2 + a3 * ds_pow3;
    Eigen::VectorXd dl = a1 * I_ + 2 * a2 * ds + 3 * a3 * ds_pow2;
    Eigen::VectorXd ddl = 2 * a2 * I_ + 6 * a3 * ds;
    Eigen::VectorXd dddl = 6 * a3 * I_;

    float cost_smooth = w_cost_smooth_dl * dl.squaredNorm() + w_cost_smooth_ddl * ddl.squaredNorm() + w_cost_smooth_dddl * dddl.squaredNorm();

    float cost_ref = w_cost_ref * l.squaredNorm();
    double cost_collision = 0;

    for (int i = 0; i < obstacle_list->obstacles.size(); i++)
    {
        if (obstacle_list->obstacles[i].is_dynamic_obs)
        {
            continue;
        }
        for (int j = 0; j < points_num; j++) // 0.1米一个点
        {
            cost_collision += CalcObstacleCost(obstacle_list->obstacles[i], ds[j], l[j]);
        }
    }
    cost_collision = cost_collision * w_cost_collision;
    double cost_all = 0;
    cost_all = cost_collision + cost_ref + cost_smooth;
    // cout<<"cost_collision:"<<cost_collision<<" cost_ref:"<<cost_ref<<" cost_smooth:"<<cost_smooth<<endl;
    return cost_all;
}

double CalculateDpPathStarCost_reverse(float begin_s, float begin_l, float begin_dl, float begin_ddl, float end_S, float end_L)
{
    clock_t time_start = clock();
    float start_l = begin_l;
    float start_dl = begin_dl;
    float start_ddl = begin_ddl;
    float end_l = end_L;
    float end_dl = 0;
    float end_ddl = 0;
    float start_s = begin_s;
    float end_s = end_S;
    Eigen::VectorXd coeff = CalculateThreeDegreePolynomialCoefficients(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s);

    float a0 = coeff(0);
    float a1 = coeff(1);
    float a2 = coeff(2);
    float a3 = coeff(3);
    // float a4 = coeff(4);
    // float a5 = coeff(5);

    int points_num = static_cast<int>(std::floor(abs(sample_s_reverse) * sample_s_num)); // 输出80
    Eigen::VectorXd I_ = Eigen::VectorXd::Ones(points_num);
    Eigen::VectorXd ds = Eigen::VectorXd::LinSpaced(points_num, start_s, start_s + sample_s_reverse); // 生成等间距的向量
    Eigen::VectorXd ds_pow2 = ds.array().pow(2);
    Eigen::VectorXd ds_pow3 = ds.array().pow(3);
    // Eigen::VectorXd ds_pow4 = ds.array().pow(4);
    // Eigen::VectorXd ds_pow5 = ds.array().pow(5);

    // Eigen::VectorXd l = a0 * I_ + a1 * ds + a2 * ds_pow2 + a3 * ds_pow3 + a4 * ds_pow4 + a5 * ds_pow5;
    // Eigen::VectorXd dl = a1 * I_ + 2 * a2 * ds + 3 * a3 * ds_pow2 + 4 * a4 * ds_pow3 + 5 * a5 * ds_pow4;
    // Eigen::VectorXd ddl = 2 * a2 * I_ + 6 * a3 * ds + 12 * a4 * ds_pow2 + 20 * a5 * ds_pow3;
    // Eigen::VectorXd dddl = 6 * a3 * I_ + 24 * a4 * ds + 60 * a5 * ds_pow2;

    Eigen::VectorXd l = a0 * I_ + a1 * ds + a2 * ds_pow2 + a3 * ds_pow3;
    Eigen::VectorXd dl = a1 * I_ + 2 * a2 * ds + 3 * a3 * ds_pow2;
    Eigen::VectorXd ddl = 2 * a2 * I_ + 6 * a3 * ds;
    Eigen::VectorXd dddl = 6 * a3 * I_;

    float cost_smooth = w_cost_smooth_dl * dl.squaredNorm() + w_cost_smooth_ddl * ddl.squaredNorm() + w_cost_smooth_dddl * dddl.squaredNorm();
    float cost_ref = w_cost_ref * l.squaredNorm();
    double cost_collision = 0;
    for (int i = 0; i < obstacle_list->obstacles.size(); i++)
    {
        if (obstacle_list->obstacles[i].is_dynamic_obs)
        {
            continue;
        }
        for (int j = 0; j < points_num; j++) // 0.1米一个点
        {
            cost_collision += CalcObstacleCost(obstacle_list->obstacles[i], ds[j], l[j]);
        }
    }

    cost_collision = cost_collision * w_cost_collision;
    double cost_all = 0;
    cost_all = cost_collision + cost_ref + cost_smooth;
    // cout<<"start_cost_collision:"<<cost_collision<<" start_cost_ref:"<<cost_ref<<" start_cost_smooth:"<<cost_smooth<<endl;
    return cost_all;
}


/**
 * @description: 计算在frenet坐标系下所有局部路径的点转化为XY坐标系
 * @param {Frenet_path_points} frenet_path_points
 * @param {car_path} path
 * @return {*}
 */
vector<Eigen::Vector2d> FrenetToXY_r(const Frenet_path_points &frenet_path_points, planning_msgs::car_path &path)
{
    // cout<<"FrenetToXY start"<<endl;
    vector<Eigen::Vector2d> points_XY;
    points_XY.reserve(frenet_path_points.s.size());
    int pre_index2s_id = index_middle_Car;
    for (int i = 0; i < frenet_path_points.s.size(); i++)
    {
        planning_msgs::path_point proj_point_;
        planning_msgs::path_point point_xy;

        proj_point_.absolute_s = frenet_path_points.s[i];
        // cout<<"proj_point_.absolute_s :"<<proj_point_.absolute_s <<endl;
        int index_match_points;
        index_match_points = index2s_r(path, proj_point_, pre_index2s_id);
        // cout<<"index_match_points:"<<index_match_points<<endl;
        proj_point_ = find_projected_point_Frenet(path, index_match_points, frenet_path_points.s[i], frenet_path_points.l[i]);
        Eigen::Vector2d match_point_xy(proj_point_.x, proj_point_.y);
        Eigen::Vector2d point_nor(proj_point_.nor.x, proj_point_.nor.y);   //法相量
        Eigen::Vector2d point_temp_xy = match_point_xy + frenet_path_points.l(i) * point_nor;
        // cout<<"match_point_xy:"<<match_point_xy(0)<<" "<<match_point_xy(1)<<";l:"<<frenet_path_points.l(i)<<" nor:"<<point_nor(0)<<", "<<point_nor(1)<<";real_points:"<<point_temp_xy(0)<<","<<point_temp_xy(1)<<endl;
        // cout<<"point_temp_xy:"<<point_temp_xy<<" ";
        pre_index2s_id = index_match_points;

        points_XY.push_back(point_temp_xy);
    }

    // std::cout << "FrenetToXY程序运行时间: " << time_diff << " 秒" << std::endl;
    return points_XY;
}
